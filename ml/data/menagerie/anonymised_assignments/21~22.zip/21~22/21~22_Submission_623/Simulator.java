import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import javax.swing.Box;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Wolves, Bears, Deer, Squirrels, Hares and Plants.
 *
 * @version 3.0
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a plant will be generated in any given grid position
    // any time during the simulation
    private static final double PLANT_GENERATION_PROBABILITY = 0.0005;
    // The probability that a plant will be created in any given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.01;
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.04;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.04;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.08;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.06;
    // The probability that a hare will be created in any given grid position.
    private static final double HARE_CREATION_PROBABILITY = 0.06;
    // If plants will be simulated (extension task)
    private boolean plantSimulate;
    // If wolves will be simulated (extension task)
    private boolean wolfSimulate;
    // If bears will be simulated (extension task)
    private boolean bearSimulate;
    // If deer will be simulated (extension task)
    private boolean deerSimulate;
    // If squirrels will be simulated (extension task)
    private boolean squirrelSimulate;
    // If hares will be simulated (extension task)
    private boolean hareSimulate;
    
    // Limit for clock, rolls over back to 0 once the clock value hits limit.
    // Full day cycle lasts 40 steps
    private final int limit1 = 10;
    // Current clock value
    private int value1;
    // Day cycle (int 0-3) 4 phases of day: Morning, Midday, Evening, Night
    public static int dayCycle;
    // Day cycle limit, rolls over once it hits 4: 0, 1, 2, 3
    private final int dayCycleLimit = 4;
    // Limit for clock for weather, rolls over back to 0 once clock value hits limit.
    // Full weather cycle lasts 30 steps
    private final int limit2 = 5;
    // Current clock value for weather
    private int value2;
    // Weather cycle (int 0-2) 3 phases of weather: Clear, Rainy, Foggy
    public static int weatherCycle;
    // Weather cycle limit, rolls over once it hits 3: 0, 1, 2
    private final int weatherCycleLimit = 3;
    
    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        // Simulation starts in the morning
        dayCycle = 0;
        // Starts with clear weather
        weatherCycle = 0;
        // Initialising clock values
        value1 = 0;
        value2 = 0;
        // For this simulation, all living organisms are simulated.
        plantSimulate = true;
        wolfSimulate = true;
        bearSimulate = true;
        deerSimulate = true;
        squirrelSimulate = true;
        hareSimulate = true;
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        // Simulation starts in the morning
        dayCycle = 0;
        // Starts with clear weather
        weatherCycle = 0;
        // Initialising clock values
        value1 = 0;
        value2 = 0;
        // For this simulation, all living organisms are simulated.
        plantSimulate = true;
        wolfSimulate = true;
        bearSimulate = true;
        deerSimulate = true;
        squirrelSimulate = true;
        hareSimulate = true;
        
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Deer.class, Color.MAGENTA);
        view.setColor(Squirrel.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.GRAY);
        view.setColor(Bear.class, Color.BLACK);
        view.setColor(Hare.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Create a simulation with whatever combination of organisms the user wants.
     * Simulation will simulate an organism as long as the organismsToSimulate string entered
     * contains the organsim name.
     * @param String organismsToSimulate, the organisms the user wants to simulate
     */
    public Simulator(String organismsToSimulate)
    {
        // Simulation starts in the morning
        dayCycle = 0;
        // Starts with clear weather
        weatherCycle = 0;
        // Initialising clock values
        value1 = 0;
        value2 = 0;
        // For this simulation, all living organisms are simulated.
        plantSimulate = true;
        wolfSimulate = true;
        bearSimulate = true;
        deerSimulate = true;
        squirrelSimulate = true;
        hareSimulate = true;
        selectSimulations(organismsToSimulate);
        
        int depth;
        int width;
        
        depth = DEFAULT_DEPTH;
        width = DEFAULT_WIDTH;
            
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Deer.class, Color.MAGENTA);
        view.setColor(Squirrel.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.GRAY);
        view.setColor(Bear.class, Color.BLACK);
        view.setColor(Hare.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }

    /**
     * Internal method used to select the species wanted to simulate.
     * Simulation will simulate an organism as long as the organismsToSimulate string entered
     * contains the organsim name.
     * @param String organismsToSimulate, the organisms the user wants to simulate
     */
    private void selectSimulations(String organismsToSimulate)
    {
        if(organismsToSimulate.contains("plant")) {
            plantSimulate = true;
        }
        else {
            plantSimulate = false;
        }
        if(organismsToSimulate.contains("wolf")) {
            wolfSimulate = true;
        }
        else {
            wolfSimulate = false;
        }
        if(organismsToSimulate.contains("bear")) {
            bearSimulate = true;
        }
        else {
            bearSimulate = false;
        }
        if(organismsToSimulate.contains("deer")) {
            deerSimulate = true;
        }
        else {
            deerSimulate = false;
        }
        if(organismsToSimulate.contains("squirrel")) {
            squirrelSimulate = true;
        }
        else {
            squirrelSimulate = false;
        }
        if(organismsToSimulate.contains("hare")) {
            hareSimulate = true;
        }
        else {
            hareSimulate = false;
        }
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * wolf, bear, deer, squirrel, hare.
     */
    public void simulateOneStep()
    {
        step++;
        // Incrementing time
        value1 = (value1 + 1) % limit1;
        if(value1 == 0) {
            dayCycle = (dayCycle + 1) % dayCycleLimit;
        }
        // Incrementing weather
        value2 = (value2 + 1) % limit2;
        if(value2 == 0) {
            weatherCycle = (weatherCycle + 1) % weatherCycleLimit;
        }
        
        // Provide space for newborn organisms.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms);
            if(! organism.isAlive()) {
                it.remove();
            }
        }
        
        // Random generation of plants if it's raining
        if(weatherCycle == 1) {
            generatePlants();
        }
               
        // Add the newly born/grown wolves, bears, deer, squirrels, hares, plantsto the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        organisms.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Random generation of plants if it's raining.
     */
    private void generatePlants()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANT_GENERATION_PROBABILITY && plantSimulate) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    organisms.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Randomly populate the field with wolves, bears, deer, squirrels, hares, plants.
     * boolean values of ______simulate (e.g. plantSimulate) decide whether the living organism is simulated.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY && plantSimulate) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    organisms.add(plant);
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY && bearSimulate) {
                    Location location = new Location(row, col);
                    Bear bear = new Bear(true, field, location, true);
                    organisms.add(bear);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY && wolfSimulate) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location, true);
                    organisms.add(wolf);
                }
                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY && deerSimulate) {
                    Location location = new Location(row, col);
                    Deer deer = new Deer(true, field, location, true);
                    organisms.add(deer);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY && squirrelSimulate) {
                    Location location = new Location(row, col);
                    Squirrel squirrel = new Squirrel(true, field, location, true);
                    organisms.add(squirrel);
                }
                else if(rand.nextDouble() <= HARE_CREATION_PROBABILITY && hareSimulate) {
                    Location location = new Location(row, col);
                    Hare hare = new Hare(true, field, location, true);
                    organisms.add(hare);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
