import java.util.List;
import java.util.Random;

/**
 * A simple model of a plants.
 * plants age, reproduce and die.
 *
 * @version 2016.02.29 (2)
 */
public class Plants extends Organism
{
    // Characteristics shared by all plants (class variables).

    // The age at which a plants can start to reproduce.
    private static final int REPRODUCTION_AGE = 0;
    // The age to which a plants can live.
    private static final int MAX_AGE = 600;
    //The likelihood of a plants reproducing.
    private static final double REPRODUCTION_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_OFFSPRING_SIZE = 16;
    // A shared random number generator to control reproducing.
    private static final Random rand = Randomizer.getRandom();
    
    
    // Individual characteristics (instance fields).
    // The plants's age.
    private int age;

    /**
     * Create new plants. A plant may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the plants will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plants(boolean randomAge, Field field, Location location)
    {
        super(field,location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    
    /**
     * This is what the plant does - it will reproduce or die of old age.
     * @param newPlants A list to return newly born plants.
     * @param time determine the actions of a plant at a specific time.
     */
    public void act(List<Organism> newPlants, int time)
    {
        if(time < 24){
            incrementAge();
            if(isAlive()) {
                giveBirth(newPlants);            
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation == null) {
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the plants's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this plants is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     */
    private void giveBirth(List<Organism> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = reproduce();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plants young = new Plants(false, field, loc);
            newPlants.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can reproduce.
     * @return The number of births (may be zero).
     */
    private int reproduce()
    {
        int births = 0;
        if(canReproduce() && rand.nextDouble() <= REPRODUCTION_PROBABILITY) {
            births = rand.nextInt(MAX_OFFSPRING_SIZE) + 1;
        }
        return births;
    }

    /**
     * A plants can reproduce if it has reached the reproducing age.
     * @return true if the plants can reproduce, false otherwise.
     */
    private boolean canReproduce()
    {
        return age >= REPRODUCTION_AGE;
    }
}