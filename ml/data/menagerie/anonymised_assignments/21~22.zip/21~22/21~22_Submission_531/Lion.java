import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a lion.
 * lions age, move, breed, eat zebras and giraffes and die.
 *
 * @version 2016.02.29 (2)
 */
public class Lion extends Organism
{
    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 0;
    // The age to which a lion can live.
    private static final int MAX_AGE = 300;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.99;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single zebra. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int Zebra_FOOD_VALUE = 20;
    // The food value of a single giraffe. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int Giraffe_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //The likelihood of a lion being a female.
    private static final double FEMALE_PROBABILITY = 0.50;
    //The likelihood of a lion catching a disease.
    private static final double DISEASE_PROBABILITY = 0.01;

    // Individual characteristics (instance fields).
    // The lion's age.
    private int age;
    // The lion's food level, which is increased by eating zebras and giraffes.
    private int foodLevel;
    //Whether a lion is female or not.
    private boolean isFemale;
    //Whether a lion has disease or not.
    private boolean hasDisease;

    //To randomly determine the food level at lion's creation.
    private Random random1;
    private ArrayList<Integer>foodValue;

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        random1= new Random();
        foodValue = new ArrayList<>();
        foodValue.add(Zebra_FOOD_VALUE);
        foodValue.add(Giraffe_FOOD_VALUE);
        int value = random1.nextInt(foodValue.size());
        int energy = foodValue.get(value);

        hasDisease = false;

        isFemale = rand.nextDouble() >= FEMALE_PROBABILITY;

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(energy);
        }
        else {
            age = 0;
            foodLevel = energy;
        }
    }

    /**
     * This is what the lion does most of the time: it hunts for
     * zebras and giraffes. In the process, it might breed, catch disease, die of hunger,
     * or die of old age.
     * @param newLions A list to return newly born lions.
     * @param time determine the actions of a lion at a specific time.
     */
    public void act(List<Organism> newLions, int time)
    {
        if(time % 24 == 12){
            incrementAge();
            incrementHunger();
            diseaseProbability();
            diseaseEffects();
            if(isAlive()) {
                meet(newLions);

                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Increase the age. This could result in the lion's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for zebras,hyenas and giraffes adjacent to the current location.
     * Only the first live zebra or giraffe is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Zebra && organism instanceof Giraffe && organism instanceof Hyena) {
                Giraffe giraffe = (Giraffe) organism;
                if(giraffe.isAlive()) { 
                    giraffe.setDead();
                    foodLevel = Giraffe_FOOD_VALUE;
                    return where;
                }
            }
            else if(organism instanceof Zebra && organism instanceof Giraffe) {
                Giraffe giraffe = (Giraffe) organism;
                if(giraffe.isAlive()) { 
                    giraffe.setDead();
                    foodLevel = Giraffe_FOOD_VALUE;
                    return where;
                }
            }
            else if(organism instanceof Giraffe && organism instanceof Hyena) {
                Giraffe giraffe = (Giraffe) organism;
                if(giraffe.isAlive()) {
                    giraffe.setDead();
                    foodLevel = Giraffe_FOOD_VALUE;
                    return where;
                }
            }
            else if(organism instanceof Zebra && organism instanceof Hyena) {
                incrementHunger();
            }
            else if(organism instanceof Zebra) {
                Zebra zebra = (Zebra) organism;
                if(zebra.isAlive()) { 
                    zebra.setDead();
                    foodLevel = Zebra_FOOD_VALUE;
                    return where;
                }
            }
            else if(organism instanceof Giraffe) {
                Giraffe giraffe = (Giraffe) organism;
                if(giraffe.isAlive()) { 
                    giraffe.setDead();
                    foodLevel = Giraffe_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLions A list to return newly born lions.
     * Only female lions give birth.
     */
    private void giveBirth(List<Organism> newLions)
    {
        // New lions are born into adjacent locations.
        // Get a list of adjacent free locations.
        if(isFemale){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed();
            for(int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Lion young = new Lion(false, field, loc);
                newLions.add(young);
            }
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A lion can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Check if a lion meets another lion of opposite gender and then give birth to new lions.
     * Check if the other lion has disease or not and infect the other lion if already not infected.
     * Check if a lion meets a hyena ,hyena has disease or not and infect the hyena if already not infected.
     * @param newLions A list to return newly born lions when male and female lions meet.
     */
    private void meet(List<Organism> newLions)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Lion) {
                Lion lion1 = (Lion) organism;
                if(lion1.isAlive() && isFemale != lion1.returnFemale()) { 
                    giveBirth(newLions);
                }
                
                if(lion1.isAlive() && hasDisease && !lion1.returnDisease()){
                    lion1.getInfected();  
                }
            } 

            if(organism instanceof Hyena) {
                Hyena hyena1 = (Hyena) organism;
                if(hyena1.isAlive() && hasDisease && !hyena1.returnDisease()) { 
                    hyena1.getInfected();
                }
            } 
        }
    }

    /**
     * Returns whether a lion is female or not;
     */
    private boolean returnFemale()
    {
        return isFemale;
    }

    /**
     * Check whether a lion is infected or not.
     */
    private void diseaseProbability()
    {
        hasDisease = rand.nextDouble() <= DISEASE_PROBABILITY; 
    }

    /**
     * If a lion is infected,the hunger increases.
     */
    private void diseaseEffects()
    {
        if(hasDisease){
            incrementHunger();
        }
    }

    /**
     * Returns whether a lion has disease or not.
     */
    public boolean returnDisease()
    {
        return hasDisease;
    }

    /**
     * Infects the lion with disease.
     */
    public void getInfected()
    {
        hasDisease = true;
    }
}