import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Butterfly.
 * Buttergly age, move, eat plants, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Butterfly extends Animal
{
    // Characteristics shared by all butterfly (class variables).
    // number of steps a butterfly can go before it has to eat again.
    private static final int BLUEBERRIES_FOOD_VALUE = 16;
    private static final int POKEBERRIES_FOOD_VALUE = 12;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Butterfly. A Butterfly can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Butterfly will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The gender of the Butterfly
     */
    public Butterfly(boolean randomAge, Field field, Location location, boolean gender)
    {
        super(field, location,7,18,0.11,4,gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(BLUEBERRIES_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = BLUEBERRIES_FOOD_VALUE + POKEBERRIES_FOOD_VALUE;
        }
        this.isFemale = gender;
    }
    
    /**
     * This is what the Butterfly does most of the time: it runs and eats plant.
     * In the process, it might breed, die of hunger, die due to poison
     * or die of old age.
     * @param field The field currently occupied.
     * @param newKingcobra A list to return newly born Kingcobra.
     */
    public void act(List<Animal> newButterfly)
    {
        incrementAge();
        incrementHunger();
        remainingDays();
        if(isAlive()) {
            hasMeet();
            giveBirth(newButterfly);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                overcrowded();
            }
        }
    }
    
    /**
     * Look for blueberries and pokeberries adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Pokeberries) {
                Pokeberries Pokeberries = (Pokeberries) plant;
                if(Pokeberries.isAlive()) { 
                    if (Pokeberries.isPoisoned()) {
                        this.days = 10;
                    }
                    Pokeberries.setDead();
                    foodLevel = POKEBERRIES_FOOD_VALUE;
                    return where;
                }
            }
            if(plant instanceof Blueberries) {
                Blueberries blueberries = (Blueberries) plant;
                if(blueberries.isAlive()) { 
                    blueberries.setDead();
                    foodLevel = BLUEBERRIES_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Butterfly is a female and have met a male Butterfly in adjacent
     * If have met, hasMeet = true, one of the conditions for a Butterfly to be able to breed (only female can breed)
     */
    private void hasMeet(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(this.getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Butterfly) {
                Butterfly butterfly = (Butterfly) animal;
                if(butterfly.isFemale && !this.isFemale) { 
                    butterfly.hasMeet = true;
                }
            }
        
        }
    }
    
    /**
     * Check whether or not this Butterfly is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newButterfly A list to return newly born Butterfly.
     */
    private void giveBirth(List<Animal> newButterfly)
    {
        // New butterfly are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gender = rand.nextInt(2) == 0 ? false : true;
            Butterfly young = new Butterfly(false, field, loc, gender);
            newButterfly.add(young);
        }
    }
}
