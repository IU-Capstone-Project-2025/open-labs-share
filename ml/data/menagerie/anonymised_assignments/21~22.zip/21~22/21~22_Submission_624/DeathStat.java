
/**
 * A Class that gets the count of the number of many animals that have died in different ways
 * This includes ageing, poison, being consumed, having a fight, starvation and overpopulation
 *
 * @version v1 
 */
public class DeathStat
{
    public static int oldAge;
    public static int poisoned;
    public static int consumed;
    public static int fought;
    public static int starved;
    public static int overpopulation;
    public static String deathResult;

    /**
     * Getter Method to get number of animal died caused by aging
     */
    public static int getOldAge(){
        return oldAge;
    }
    
    /**
     * Getter Method to get number of animal died caused by fighting
     */
    public static int getFought(){
        return fought;
    }

    /**
     * Getter Method to get number of animal died caused by poison
     */
    public static int getPoisoned(){
        return poisoned;
    }

    /**
     * Getter Method to get number of animal died caused by being consumed
     */
    public static int getConsumed(){
        return consumed;
    }

    /**
     * Getter Method to get number of animal died caused by starvation
     */
    public static int getStarved(){
        return starved;
    }

    /**
     * Getter Method to get number of animal died caused by overpopulation
     */
    public static int getOverpopulation(){
        return overpopulation;
    }

    /**
     * Updates the statistics every step and String deathResult is outputted
     */
    public static void updateStat() {
        deathResult = "Old age: " + getOldAge() + " Starved: " + getStarved() + " Poisoned: " + getPoisoned() + " Overpopulation: " + getOverpopulation()
        + " Was consumed: " + getConsumed() + " Fought: " + getFought();
    }

    /**
     * Clears the statistics when field resets
     */
    public static void clear(){
        oldAge = 0;
        poisoned = 0;
        consumed = 0;
        starved = 0;
        overpopulation = 0;
    }
}

