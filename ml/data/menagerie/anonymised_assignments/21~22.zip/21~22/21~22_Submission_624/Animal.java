import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    
    private final Random rand = Randomizer.getRandom();

    
    // The age at which animal can start to breed.
    protected final int BREEDING_AGE;
    // The age to which animal can live.
    protected final int MAX_AGE;
    // The likelihood of animal breeding.
    protected final double BREEDING_PROBABILITY;
    // The maximum number of births.
    protected final int MAX_LITTER_SIZE;
    // Current age of animal
    protected int age;
    // Increases as animal eat their food sources
    protected int foodLevel;
    // Whether the animal has meet same specie of opposite gender
    protected boolean hasMeet = false;
    // Whether animal is female;
    protected boolean isFemale;
    
    // Count down variable for days remaining after being poisoned
    protected int days = -1;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param BREEDING_AGE The breeding age of animal
     * @param MAX_AGE The max age of animal
     * @param BREEDING_PROBABILITY The breeding probability of animal
     * @param MAX_LITTER_SIZE The max litter size of animal
     * @param isFemale Whether animal is female
     */
    public Animal(Field field, Location location,int BREEDING_AGE, int MAX_AGE, double BREEDING_PROBABILITY, int MAX_LITTER_SIZE, boolean isFemale)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.BREEDING_AGE = BREEDING_AGE;
        this.MAX_AGE = MAX_AGE;
        this.BREEDING_PROBABILITY = BREEDING_PROBABILITY;
        this.MAX_LITTER_SIZE = MAX_LITTER_SIZE;
        this.isFemale = isFemale;
    } 
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Increase the hunger. This could result in the animal's death due to starvation
     * Increment death count by starving
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            DeathStat.starved++;
            setDead();
        }
    }
    
    /**
     * Increase the age. This could result in the animal's death.
     * Increment death count by ageing
     */
    protected void incrementAge()
    {
        this.age++;
        if(age > MAX_AGE) {
            DeathStat.oldAge++;
            setDead();
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Animal can breed if it has reached the breeding age and have meet
     */
    protected boolean canBreed()
    {
        return age >= BREEDING_AGE && hasMeet;
    }
    
    /**
     * Animal may have set steps remaining until they die due to poison
     * If not poisoned, return, nothing happens
     * If count down reaches 0 means animal died and is caused by poison
     * Increment death count by poison
     */
    protected void remainingDays(){
        if(this.days < 0){
            return;
        }
        if (this.days == 0) {
            this.setDead();
            DeathStat.poisoned++;
        }
        days--;
    }
    
    /**
     * Might overcrowd. This could result in the animal's death.
     * Increment death count by overcrowding
     */
    protected void overcrowded(){
        setDead();
        DeathStat.overpopulation++;
    }
    
    /**
     * Animal can get consumed. This could result in the animal's death.
     * Increment death count by consuming
     */
    protected void deathConsumed(){
        DeathStat.consumed++;
    }
    
    /**
     * Animal can get into fight. This could result in the animal's death.
     * Increment death count by fighting
     */
    protected void deathFought(){
        DeathStat.fought++;
    }

    
}
