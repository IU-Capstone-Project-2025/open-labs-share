import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a toad.
 * Toad's age, move, breed, eat butterfly and die.
 *
 * @version 2016.02.29 (2)
 */
public class Toad extends Animal
{
    // Characteristics shared by all toad (class variables).
    // number of steps a Toad can go before it has to eat again.
    private static final int BUTTERFLY_FOOD_VALUE = 29;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new toad. A toad may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the toad will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The gender of the Toad
     */
    public Toad(boolean randomAge, Field field, Location location, boolean gender)
    {
        super(field, location, 10, 60, 0.13,6, gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(BUTTERFLY_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = BUTTERFLY_FOOD_VALUE;
        }
        this.isFemale = gender;
    }
    
    /**
     * This is what the Toad does most of the time: it hunts for
     * butterfly. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newToad A list to return newly born Toad.
     */
    public void act(List<Animal> newToad)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            hasMeet();
            giveBirth(newToad);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                overcrowded();
            }
        }
    }
    
    /**
     * Look for butterfly's adjacent to the current location.
     * Only the first live butterfly is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Butterfly) {
                Butterfly butterfly = (Butterfly) animal;
                if(butterfly.isAlive()) { 
                    butterfly.setDead();
                    deathConsumed();
                    foodLevel = BUTTERFLY_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Toad is a female and have met a male Toad in adjacent
     * If have met, hasMeet = true, one of the conditions for a Toad to be able to breed (only female can breed)
     */
    private void hasMeet(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(this.getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Toad) {
                Toad toad = (Toad) animal;
                if(toad.isFemale && !this.isFemale) { 
                    toad.hasMeet = true;
                }
            }
        
        }
    }
    
    /**
     * Check whether or not this toad is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newToad A list to return newly born toad.
     */
    private void giveBirth(List<Animal> newToad)
    {
        // New toads are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gender = rand.nextInt(2) == 0 ? false : true;
            Toad young = new Toad(false, field, loc, gender);
            newToad.add(young);
        }
    }

}
