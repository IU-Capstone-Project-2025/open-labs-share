import java.util.List;

/**
 * Species of hares class which is a herbivore and in turn also an animal
 *
 * @version (v2)
 */
public class Hare extends Herbivore
{
    /**
     * Constructor for objects of class Hare
     * @param randomAge, whether the animal has to have a random age, field, a grid the Hare is added to  and location, which is the row and column in that field the Hare is set in
     */
    public Hare(boolean randomAge, Field field, Location location)
    {
        //super call that passes in all the raw numerical data that differentiates the bear from all other species in the simulation
        super(randomAge,field,location,Gender.produceGender(),40,40,100,4,0.2,3);
        
    }
    
    /**
     * Abstract method implementation which creates a new Hare, done here instead of super class
     * Location referes to the free location surrounding the female and male hare animals at time of mating 
     */
    public void giveBirth(List<Entity> newAnimals, Location location)
    {
            Hare hareYoung = new Hare(false, this.getField(), location);
            newAnimals.add(hareYoung);
    }
    
    /**
     * Checks the species attempted to breed with this animal is of type hare
     */
    protected boolean checkSpeciesToBreed(Object adjacentEntity)
    {
        return (adjacentEntity instanceof Hare);
    }

}
