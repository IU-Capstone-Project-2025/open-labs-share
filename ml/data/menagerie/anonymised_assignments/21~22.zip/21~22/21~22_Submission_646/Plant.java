import java.util.Random;
import java.util.*;

/**
 * Plants are entities that can photosynthesise depending if they have the required amounts of rain storage and sunlight storage, also extending/growing 
 * into adjacent cells if they have another threshold level of rain and sunlight to make new plant objects. The Gender of the plant has been set to NULL.
 * Plants are the main entities affected by weather as their attributes will be affected by the kind of weather present in the simulation. 
 * Furthermore, plants cannot photosynthesise during the NIGHT due to the lack of sunlight provided
 *
 * @version (v4)
 */
public abstract class Plant extends Entity
{
    private int plantHealth;
    //Health bar of the plant that depletes when an herbivore eats the full plant, meaning the amount they eat is greater than this attribute's value
    private int maxPlantHealth;
    //Max health bar of the plant, used in photosynthesis
    private int growthLevel;
    //What stage the plant is in (unbloomed, bloomed, mature)
    
    
    private int rainStorage; 
    //How much rain a plant can hold
    private int sunlightStorage;
    //How much sunlight a plant can store
    private boolean poisonous = false;
    //whether the plant is poisonous or not
    private int maxStorage;
    //the max storage for both sunlight and rain
    private int minimumSpawnEnergy;
    //Minimum energy required for a plant to extend
    private int minimumSynthesis;
    //Minimum energy for a plant to undergo photosynthesis
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Plant
     */
    public Plant(boolean randomGrowthLevel,Field field, Location location, Gender gender,
    int maxPlantHealth, int maxStorage, int minimumSpawnEnergy, int minimumSynthesis)
    {
        super(field, location, gender);
        
        if(randomGrowthLevel){
            growthLevel = rand.nextInt(4);
        }else{
            growthLevel = 1;
        }
        
        this.maxPlantHealth = maxPlantHealth;
        this.maxStorage = maxStorage;
        
        //plant health, rain storage and sunlight is set to a random of the max
        plantHealth = rand.nextInt(this.maxPlantHealth);
        rainStorage = rand.nextInt(this.maxStorage);
        sunlightStorage = rand.nextInt(this.maxStorage);
        //this.poisonous = poisonous;
         
        //Maximum amount of rain and sun storage a plant can have before it dies
        this.minimumSpawnEnergy = minimumSpawnEnergy;
        this.minimumSynthesis = minimumSynthesis;
    }
    
    /**
     * method that updates the plant health by receiving a passed value which is the amount of the plant that has been eaten and subtracting this amount from the
     * plant's health attribute
     * @param eatenPlantAmount, the amount of the plant which has been eaten
     */
    public void updatePlantHealth(int eatenPlantAmount)
    {
        //the animal ate the entire plant as the amount to be taken off is greater than that of the plant's current health 
        if(eatenPlantAmount >= plantHealth){
            setDead();
            EntityStatistics.addStatistic(this, "Plant Eaten Deaths");
        }else{
        plantHealth = plantHealth - eatenPlantAmount;
        }
    }
    
    /**
     * Photosynthesis method that makes the plant gain health if the plant has enough sunlight and rain 
     */
    private void photosynthesis() {
        
        if(sunlightStorage > minimumSynthesis && rainStorage > minimumSynthesis) {
            if (growthLevel < 3) {
                growthLevel += 1;
            }
            
            if(checkMaturity()){
                EntityStatistics.addStatistic(this,"Matured Plants");
            }
            
            int tempHealth = plantHealth + 10;
            
            if(tempHealth > maxPlantHealth) {
                //photosynthesis is the plant's equivalent to the animals findFood() method to generate energy, in this case their health increases
                int differenceHealth = maxPlantHealth - plantHealth;
                plantHealth = plantHealth + differenceHealth;
            
            }else{
                plantHealth = tempHealth;
            }
            
            sunlightStorage -= minimumSynthesis;
            rainStorage -= minimumSynthesis;
        }
    }
    
    /**
     * returns the plant's current health
     * @return plantHealth, the health of the plant
     */
    public int getPlantHealth() {
        return plantHealth;
    }
    
    /**
     * checks whether either storage levels of the plants have been depleted to 0, or if the rain amount is greater then the max which would cause the plant to wilt
     */
    private void checkStorage() {
        if(rainStorage == 0 || sunlightStorage == 0 || rainStorage > maxStorage ) {//unlightStorage > maxStorage) {
            setDead();
            EntityStatistics.addStatistic(this,"Depleted Storage Deaths");
        }
    }
    
    /**
     * Method that takes the simulation's current weather , and depending on what it is, the relevant plant attributes are updated
     */
    private void plantWeather(Weather seeWeather) {
        //the weather is sunny therefore the plant gains sunlight
        if(seeWeather.isSunny(seeWeather)) {
           sunlightStorage += 100;
        }
        //it is rainy therefore the plant gains water
       else if(seeWeather.isRainy(seeWeather)) {
            rainStorage += 100;
        }
        //it is windy therefore the plant gains sun but looses water
        else if(seeWeather.isWindy(seeWeather)) {
            sunlightStorage += 50;
            //wind blows water out of the plant
            rainStorage -= 50;
        }
    }
    
    /**
     * Implementation of act method from entity that combines all of the plant's behaviours into a single method call
     * @param newPlants, list of type Entity in case the plant extends/grows into an adjacent location, timeOfDDay whether it is NIGHT OR DAY, seeWeather, what the 
     * weather is either SUN or WIND or RAIN
     */
    public void act(List <Entity> newPlants, DayNight timeOfDay, Weather seeWeather)
    {
        if(isAlive()) {
            if(sunlightStorage >= minimumSpawnEnergy && rainStorage >= minimumSpawnEnergy) {
                 extendPlant(newPlants);   
                 //If the plant has the minimum amount of energy to undergo photosynthesis, the extendPlant method is called
            }
            
            plantWeather(seeWeather);
            //The sun and rain storage of the plant will change depending on the weather
            checkStorage();
            
            if(timeOfDay.isDay()) {
                    photosynthesis();
                    //A check to see if it is daytime, if it is then the method photosynthesis will be called
            }
        }
    }
   
    private void extendPlant(List<Entity> newPlants) {
      
     //produce a list of free locations adjacent to the plant
    List<Location> freeLocations = this.getField().getFreeAdjacentLocations(this.getLocation());
    
    if(!freeLocations.isEmpty() && (rand.nextDouble() <= 0.44)){
        Location loc = freeLocations.remove(0);
        spawnPlant(newPlants, loc);
        EntityStatistics.addStatistic(this,"Total Plants Grown");
        sunlightStorage -= minimumSpawnEnergy;
        rainStorage -= minimumSpawnEnergy;
    }
    }
    
    protected abstract void spawnPlant(List<Entity> newPlants, Location location);
    //abstract method that the specific plant can inherit which spawns that specific species of plant
    
    /**
     * method that returns a boolean of whether the plant is poisonous or not
     * @return boolean
     */
    public boolean isPoisonous()
    {
        return poisonous;
    }
    
    /**
     * Setter methods that sets the plant's poisonous attribute to true from the default false value
     */
    protected void setPoisonous()
    {
        poisonous = true;
    }
    
    /**
     * Checks that the plant is mature meaning its growth level is bigger than or equal to 2
     * @param boolean 
     */
    public boolean checkMaturity()
    {
        return (growthLevel >=2) ;
    }
}

