

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * Bar Chart Manager is simply used to override the start method and to open a thread on which multiple windows of a bar chart can be shown, this way a new thread
 * does not have to opened everytime the simulation is reset, simply a new bar chart is displayed on a new window on the same thread.
 *
 * @version (v2)
 */
public class BarChartManager extends Application
{

    /**
     * The start method is the main entry point for every JavaFX application. 
     * It is called after the init() method has returned and after 
     * the system is ready for the application to begin running.
     *
     * @param  stage the primary stage for this application.
     */
    @Override
    public void start(Stage stage)
    {
     //
    }
}
