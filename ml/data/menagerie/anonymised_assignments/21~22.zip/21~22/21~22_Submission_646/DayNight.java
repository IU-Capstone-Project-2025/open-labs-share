
/**
 * Enumeration class Day - write a description of the enum class here
 *
 * @version (version number or date here)
 */
public enum DayNight
{
    DAY,NIGHT;
    
    public boolean isDay()
    {
        return(this.equals(DayNight.DAY));
    }
    
    public boolean isNight()
    {
        return(this.equals(DayNight.NIGHT));
    }
    
    public static DayNight setDay()
    {
        return DAY;
    }
    
    public static DayNight setNight()
    {
        return NIGHT;
    }
    
    //MORNING(1), AFTERNOON(2), EVENING(3), NIGHT(4);
    
    //private final int timeOfDay;
    //private DayNight(int timeOfDay) {
    //    this.timeOfDay = timeOfDay;
   // }
    
   /**
    * 
    
    public DayNight findDay(int i) {
        DayNight[] daynights = DayNight.values();
        for (DayNight daynight : daynights) {
            if (daynight.timeOfDay == i) {
                return daynight;
            }
        }
        return null;
    }
    */
}
