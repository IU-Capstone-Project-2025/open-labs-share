import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class representing shared characteristics of disease.
 *
 * @version 2016.02.29 (2)
 */
public class Disease
{
    // The possibility that an animal may be infected by another animal.
    public static final double INFECTION_RATE = 0.4;
    // The possibility that a disease occurs at an animal.
    private static final double OCCURENCE_RATE = 0.02;
    // The possibility an animal may die of a disease.
    public static final double DEATH_PROBABILITY = 0.05;
    // After certain steps, the animal automatically get immuned from the disease.
    public static final double CURE_PROBABILITY = 0.15;
    
    private List<Creature> creatures;
    
    // Whether the disease is spreading.
    private boolean isHappening;

    public Disease()
    {
        isHappening = false;
        creatures = new ArrayList<>();
    }

    /**
     * Check whether the disease is spreading.
     */
    public boolean isDiseaseSpreading()
    {
        return isHappening;
    }
    
    public void setDiseaseSpreading()
    {
        isHappening = true;
    }
    
    public void setDiseaseStopped()
    {
        isHappening = false;
    }
    
    /**
     * Start to spread the disease from a randomly selected animal,
     * for each step there is a chance that the disease occurs.
     */
    public void startOfDisease(List<Creature> creatures)
    {
        if(Randomizer.getRandom().nextDouble() <= OCCURENCE_RATE) {
            ArrayList<Animal> allAnimals = new ArrayList<>();
            Iterator<Creature> it = creatures.iterator();
            while(it.hasNext()){
                Creature creature = it.next();
                if(creature instanceof Animal){
                    Animal animal = (Animal) creature;
                    allAnimals.add(animal);
                }
            }
            for(Animal animals : allAnimals) {
                if(Randomizer.getRandom().nextDouble() <= OCCURENCE_RATE) {
                    animals.setInfected();
                    setDiseaseSpreading();
                }
            }
        }
    }
}

