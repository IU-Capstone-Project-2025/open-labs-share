import java.util.List;

/**
 * A class representing shared characteristics of creatures.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Creature
{
    // The food value of a single creature. In effect, this is the
    // number of steps a panther can go before it has to eat again.
    protected static final int GRASS_FOOD_VALUE = 6;
    protected static final int RAT_FOOD_VALUE = 6;
    protected static final int DEER_FOOD_VALUE = 20;
    protected static final int HAYENA_FOOD_VALUE = 12;
    protected static final int WOLF_FOOD_VALUE = 12;
    
    // Whether the creature is alive or not.
    private boolean alive;
    // The creature's behaviour pattern during night.
    private boolean nightAnimal;
    // The creature's field.
    protected Field field;
    // The creature's position in the field.
    private Location location;

    /**
     * Create a new creature at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Creature(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this creature act - that is: make it do
     * whatever it wants/needs to do.
     * @param newCreatures A list to receive newly born creatures.
     */
    abstract public void act(List<Creature> newCreatures, Disease disease);

    /**
     * Check whether the creature is alive or not.
     * @return true if the creature is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the creature is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Check whether the animal is night animal.
     * @return true if the animal is night animal.
     */
    protected boolean isNightAnimal()
    {
        return nightAnimal;
    }
    
    /**
     * Assign the atrribute of night animal to an animal class.
     */
    protected void setNightBehaviour()
    {
        nightAnimal = true;
    }
    
    /**
     * Return the creature's location.
     * @return The creature's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the creature at the new location in the given field.
     * @param newLocation The creature's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the creature's field.
     * @return The creature's field.
     */
    protected Field getField()
    {
        return field;
    }
}
