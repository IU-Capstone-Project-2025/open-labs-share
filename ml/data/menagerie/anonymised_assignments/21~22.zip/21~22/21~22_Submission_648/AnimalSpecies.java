import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

/**
 * A model of an animal species.
 *
 * @version 2022.02.11
 */
public class AnimalSpecies extends Species
{
    // The maximum age of an animal of this species in steps.
    private int maxAge;
    // The maximum litter size for the animal.
    private int maxLitterSize;
    // The youngest that the animal can start breeding.
    private int minBreedingAge;
    // The probability that the animal breeds when an adjacent animal is nearby.
    private double breedingProbability;
    // The types of species that this animal species can eat.
    private List<Species> foodSources;
    // Whether the species can move at night.
    private Boolean canMoveAtNight;
    
    /**
     * Create a new animal species.
     * 
     * @param name The name of the species.
     * @param foodValue The food value to other species that eat an animal of this species.
     * @param creationProbability The chance that the species will be created on a given cell.
     * @param maxAge The max age for an animal within this species.
     * @param maxLitterSize The max litter size for an animal within this species.
     * @param minBreedingAge The min breeding age for an animal within this species.
     * @param breedingProbability The probability that opposite-sex animals of this species will mate when they meet.
     * @param canMoveAtNight Whether the animal species can move at night.
     */
    public AnimalSpecies(String name, int foodValue, double creationProbability, int maxAge, int maxLitterSize, int minBreedingAge, double breedingProbability, Boolean canMoveAtNight)
    {
        super(name, foodValue, creationProbability);
        this.maxAge = maxAge;
        this.maxLitterSize = maxLitterSize;
        this.minBreedingAge = minBreedingAge;
        this.breedingProbability = breedingProbability;
        this.canMoveAtNight = canMoveAtNight;
        
        foodSources = new ArrayList<>();
    }
    
    /*
     * Public methods
     */
    
    /**
     * Checks whether or not an animal belonging to this species can eat a species.
     * 
     * @param species Any type of species that the animal species may be able to eat.
     * @return Whether or not this species can eat the parsed species.
     */
    public Boolean canEat(Species species)
    {
        return foodSources.contains(species);
    }
    
    /*
     * Getters
     */
    
    /**
     * @return The max age of an animal belonging to this species.
     */
    public int getMaxAge() { return maxAge; }
    
    /**
     * @return The max litter size of an animal belonging to this species.
     */
    public int getMaxLitterSize() { return maxLitterSize; }
    
    /**
     * @return The min breeding age of an animal belonging to this species.
     */
    public int getMinBreedingAge() { return minBreedingAge; }
    
    /**
     * @return The breeding probability for an animal belonging to this species.
     */
    public double getBreedingProbability() { return breedingProbability; }
    
    /**
     * @return Whether the animal species can move at night.
     */
    public Boolean canMoveAtNight() { return canMoveAtNight; }
    
    /*
     * Setters
     */
    
    /**
     * @param foodSource A species that this animal species can eat.
     */
    public void setFoodSource(Species foodSource)
    {
        foodSources.add(foodSource);
    }
}
