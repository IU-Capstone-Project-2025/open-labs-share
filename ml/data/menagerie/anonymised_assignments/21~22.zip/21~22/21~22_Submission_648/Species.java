/**
 * A model of a species.
 * This could be either an Animal or Plant species.
 *
 * @version 2022.02.11
 */
public class Species
{
    // The name of the species.
    private String name;
    // The amount of hunger another species gets when this is eaten.
    private int foodValue;
    // The probability that this species will take up a cell when the grid is populated.
    private double creationProbability;

    /**
     * Create a new species.
     * 
     * @param name The name of the species.
     * @param foodValue The food value to an entity that eats a member of this species.
     */
    public Species(String name, int foodValue, double creationProbability)
    {
        this.name = name;
        this.foodValue = foodValue;
        this.creationProbability = creationProbability;
    }
    
    /*
     * Getters
     */
    
    /**
     * @return The probability that this species will take up any given cell during populating.
     */
    protected double getCreationProbability() { return creationProbability; }
    
    /**
     * @return The name of the species.
     */
    protected String getName() { return name; }
    
    /**
     * @return The food value of the species.
     */
    protected int getFoodValue() { return foodValue; }
}
