import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.AbstractMap;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.02.11
 */
public class Animal extends Entity
{    
    /*
     * Utlity attributes
     */
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food level of a newly born animal.
    private static final int BIRTH_FOOD_LEVEL = 30;
    
    /*
     * Attributes. 
     * Things that don't change within an animal's lifespan.
     */

    // The speices that the animal belongs to.
    private AnimalSpecies species;
    // The parents of this animal.
    private Map.Entry<Animal, Animal> parents;
    
    /*
     * Dynamic attributes
     */
    
    // The current hunger of the animal.
    private int foodLevel;
    // The current age of the animal in steps.
    private int age;
    // The sex of the animal.
    private Boolean sex; // T = Male, F = Female
    // Defines whether the animal has mated on this turn
    // Female animals cannot mate more than once per turn.
    private Boolean mated;
    
    /*
     * Constructor
     */
    
    /**
     * Create a new animal at location in field.
     * 
     * @param parents The parents of this animal. If null, no parents.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param species The species that the animal belongs to.
     */
    public Animal(Map.Entry<Animal, Animal> parents, Field field, Location location, AnimalSpecies species)
    {
        super(field, location);
        
        this.species = species;
        this.parents = parents;
        this.mated = false;
        setRandomSex();
 
        if (parents == null) 
        { 
            setRandomAge();
            setRandomFoodLevel();
        }
        else 
        { 
            age = 0;
            foodLevel = BIRTH_FOOD_LEVEL;
        }
    }

    /*
     * Overriden methods
     */
    
    /**
     * @return The species that this animal is a member of.
     */
    public AnimalSpecies getSpecies()
    {
        return species;
    }
    
    /**
     * This is what the animal does most of the time: it hunts for
     * prey / plants. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param clock The clock the simulation is running on.
     * @param newAnimals A list to return newly born animals.
     */
    public void act(List<Entity> newAnimals, Clock clock)
    {
        incrementAge();
        incrementHunger();        
  
        // Some animals cannot mate or move at night.
        if(isAlive() && canMove(clock))
        {
            // Animals cannot breed in the rain.
            if (clock.getWeatherManager().getCurrentWeather() != "Raining")
            {
                giveBirth(newAnimals);
            }
            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if(newLocation == null) 
            { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            
            // See if it was possible to move.
            if(newLocation != null)
            {
                setLocation(newLocation);
            }
            else 
            {
                // Overcrowding.
                setDead();
            }
            
        }
    }
    
    /**
     * Get eaten by another entity.
     * 
     * @return Whether the animal was successfully eaten. Always true
     */
    public Boolean beEaten()
    {
        // Animals simply die when they are eaten.
        setDead();
        return true;
    }
    
    /*
     * Public methods
     */
    
    /**
     * A animal can breed if it has reached the breeding age and is either male or a female who hasn't yet mated this turn.
     * 
     * @return Whether it is possible for this animal to mate on this turn.
     */
    public Boolean canBreed()
    {
        // Boolean definitions written out in full to increase readability.
        return (age >= species.getMinBreedingAge() && (((mated == false) && (sex == false)) || (sex == true)));
    }
    
    /*
     * Private methods
     */
    
    /**
     * Determines whether or not the animal can move at the current time.
     * 
     * @param clock The clock object that operates the simulation.
     * @return Whether this animal can move on this step.
     */
    private Boolean canMove(Clock clock)
    {
        if (species.canMoveAtNight())
        {
            return true;
        }
        else
        {
            if (clock.isDaytime())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    
    /**
     * Look for adjacent food sources that are capable of being eaten.
     * 
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        // Lambda functions checks which adjacent entities can be eaten and sorts them accordinging to their food value.
        List<Entity> availableFood = getAdjacentEntities().stream()
                            .filter(entity -> species.canEat(entity.getSpecies()))
                            .collect(Collectors.toList());
    
        if (!availableFood.isEmpty())
        {
            // Select entity randomly.
            Entity entity = availableFood.get(rand.nextInt(availableFood.size()));
            
            if (entity.isAlive())
            {
                // If animal, this animal moves into their location.
                // Animals only eat prey if they're food level is not high.
                if (entity instanceof Animal)
                {
                    // Calling eat method will set entities location to null, this prevents it.
                    Location tempLocation = entity.getLocation();
                    eat(entity);
                    
                    return tempLocation;
                }
                else
                {
                    eat(entity);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    private void giveBirth(List<Entity> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        
        Map.Entry<Integer, Animal> breedingResults = breed();
        int births = breedingResults.getKey();
        
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            // Stores the parents for the child created.
            // Parents will be this animal and the animal it mated with.
            Map.Entry<Animal, Animal> childParents = new AbstractMap.SimpleEntry<Animal, Animal>(this, breedingResults.getValue());
            Location loc = free.remove(0);
            newAnimals.add(new Animal(childParents, field, loc, species));
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (key) and the animal this mated with (value).
     */
    private Map.Entry<Integer, Animal> breed()
    {
        // Stores the results of breeding.
        // Key = amount of births, Value = animal that this bred with.
        // Doc: https://docs.oracle.com/javase/6/docs/api/java/util/AbstractMap.SimpleEntry.html
        Map.Entry<Integer, Animal> breedingResult;
        
        List<Animal> breedingPartners = getBreedingPartners();

        int births = 0;
        if(canBreed() && rand.nextDouble() <= species.getBreedingProbability() && breedingPartners.size() > 0) 
        {
            births = rand.nextInt(species.getMaxLitterSize() + 1);
            
            // This animal has mated this turn.
            mated = true;
            breedingPartners.get(0).setMated(true);
        }
        
        // If the animal has not mated, reflect that in the attributes.
        if (births == 0)
        {
            mated = false;
            breedingResult = new AbstractMap.SimpleEntry<Integer, Animal>(0, null);
            return breedingResult;
        }
        
        breedingResult = new AbstractMap.SimpleEntry<Integer, Animal>(births, breedingPartners.get(0));
        return breedingResult;
    }
    
    /**
     * Gets any adjacent animals that the animal could breed with.
     * 
     * @return A list of animals that could be bred with.
     */
    public List<Animal> getBreedingPartners()
    {
        // Lambda function returns all animals near by that are of same type and opposite gender.
        List<Animal> potentialPartners = getAdjacentAnimals().stream()
                    .filter(animal -> animal.getSex() == !this.sex)
                    .filter(animal -> species.equals(animal.getSpecies()))
                    .filter(animal -> animal.canBreed())
                    .collect(Collectors.toList());
                    
        return potentialPartners;
    }
    
    /**
     * Increase the age. This could result in the animal's death.
     */
    private void incrementAge()
    {
        this.age++;
        if(age > species.getMaxAge()) 
        {
            setDead();
        }
    }
    
    /**
     * Make this animal more hungry. This could result in the amimals's death.
     */
    private void incrementHunger()
    {
        foodLevel--;

        if(foodLevel < 0) 
        {
            setDead();
        }
    }
    
    /**
     * Eat a given entity and absorb its food value.
     * 
     * @param entity The entity getting eaten by the animal.
     */
    private void eat(Entity entity)
    {
        if (entity.beEaten())
        {
            // Hunger is decreased after an eating event (dependent on foodValue of entity).
            foodLevel = entity.getSpecies().getFoodValue();
        }
    }
    
    /**
     * Set the animal's hunger to a random number.
     * Highest food level they can recieve is their own food value to other entities.
     */
    private void setRandomHunger()
    {
        foodLevel = rand.nextInt(species.getFoodValue() + 1);
    }
    
    /*
     * Getters
     */
    
    /**
     * @return The sex of the animal, T for male and F for Female.
     */
    private boolean getSex()
    {
        return sex;
    }
    
    /**
     * @return The current age of the animal.
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * @return The current food level of the animal.
     */
    public int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * @return Whether the animal has mated this turn.
     */
    public Boolean getMated()
    {
        return mated;
    }
    
    /**
     * Gets the initial food level for this animal after it's been born.
     * Initial food level for a child is the average food level of the two parents.
     * 
     * @return The initial food level for this animal at birth.
     */
    public int getBirthFoodLevel()
    {
        // Cannot be 0.
        return ((parents.getKey().getFoodLevel() + parents.getValue().getFoodLevel()) / 2) + 1;
    }
    
    /*
     * Setters
     */
    
    /**
     * Identify that the animal has mated on this step of the simulation.
     * 
     * @param mated Whether the animal has mated this turn.
     */
    public void setMated(Boolean mated)
    {
        this.mated = mated;
    }
    
    /**
     * Assigns a sex randomly to the animal.
     * 50% chance of F, 50% chance of M.
     */
    public void setRandomSex()
    {
        Random randObject = Randomizer.getRandom();

        // Generate 0 or 1 randomly and assingn a boolean accordingly.
        sex = randObject.nextInt(2) == 0;
    }
    
    /**
     * Sets the age for the animal.
     * Ensures that the age is within the bounds of the maxAge attribute.
     * 
     * @param age The age of the animal.
     */
    public void setAge(int age)
    {
        if (age > species.getMaxAge())
        {
            this.age = species.getMaxAge();
        }
        else if (age < 0)
        {
            this.age = 0;
        }
        else
        {
            this.age = age;
        }
    }
    
    /**
     * Sets the age for the animal randomly within the confines of the maxAge attribute.
     */
    public void setRandomAge()
    {
        this.age = rand.nextInt(species.getMaxAge());
    } 

    /**
     * Set the food level of this animal randomly.
     * Maximum food level is that of the species' food value to other entities.
     */
    public void setRandomFoodLevel()
    {
        // Can't be set to 0.
        foodLevel = rand.nextInt(species.getFoodValue()) + 5;
    }
}
