import java.util.Random;

/**
 * A class representing the weather.
 *
 * @version 2022.02.13
 */
public class WeatherManager
{
    /*
     * Class variables
     */
    
    // Probability that it will be sunny.
    private static final double SUNNY_PROB = 0.8;
    // Probability that it will be raining.
    private static final double RAINING_PROB = 0.2;
    
    /*
     * Dynamic attributes
     */
    
    // The current weather.
    private String currentWeather;
    
    /**
     * Create a new weather manager object.
     */
    public WeatherManager()
    {
        currentWeather = "Overcast";
    }
    
    /*
     * Public methods.
     */

    /**
     * Update the weather.
     * 
     * @param isDaytime Whether or not it is daytime.
     */
    public void update(Boolean isDaytime)
    {
        Random rand = Randomizer.getRandom();
        
        if (isDaytime)
        {
            if (rand.nextDouble() <= SUNNY_PROB)
            {
                currentWeather = "Sunny";
            }
            else if (rand.nextDouble() <= RAINING_PROB)
            {
                currentWeather = "Raining";
            }
            else
            {
                currentWeather = "Overcast";
            }
        }
        else
        {
            if (rand.nextDouble() <= RAINING_PROB)
            {
                currentWeather = "Raining";
            }
            else
            {
                currentWeather = "Overcast";
            }
        }
    }
    
    /*
     * Getters
     */
    
    /**
     * Returns the current weather conditions.
     * 
     * @return The current weather.
     */
    public String getCurrentWeather() { return currentWeather; }
}
