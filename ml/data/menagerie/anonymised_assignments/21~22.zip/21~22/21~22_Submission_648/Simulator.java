import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.HashMap;
import java.util.stream.Stream;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing entities.
 *
 * @version 2022.02.13
 */
public class Simulator
{
    /*
     * Class variables
     * Constants representing configuration information for the simulation.
     */
 
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a plant variety will reseed.
    private static final double RESEED_PROB = 0.0005;
    
    /*
     * Attributes
     */
    
    // List of species available to the user to add.
    private List<Species> species;
    // List of entities in the field.
    private List<Entity> entities;
    // List entities waiting to be added to the field (e.g. user clicks)
    List<Entity> pendingEntities;
    // The current state of the field.
    private Field field;
    // The clock that keeps track of this simulation.
    private Clock clock;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Handles user interactions with the simulation.
    private EventHandler eventHandler;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH, true);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     * @param defaultSpecies Whether the simulator will use default species, or custom user-defined species.
     */
    public Simulator(int depth, int width, Boolean defaultSpecies)
    {
        if(width <= 0 || depth <= 0) 
        {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        species = new ArrayList<>();
        entities = new ArrayList<>();
        pendingEntities = new ArrayList<>();
        field = new Field(depth, width);
        clock = new Clock();
        
        // Define species
        if (defaultSpecies)
        {
            defineDefaultSpecies();
        }
        else
        {
            /*
             * Implementation of user-created species.
             * Outside of scope of assingment so not implemented.
             * If statement displayed to show where function call would've taken place.
             */             
        }
        
        // Sort mouseHandler.
        eventHandler = new EventHandler(this);
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, eventHandler, getColors());
        
        // Setup a valid starting point.
        reset(); 
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) 
        {
            simulateOneStep();
            delay(50);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each entity.
     */
    public void simulateOneStep()
    {
        clock.tick();

        // Provide space for newborn animals.
        List<Entity> newEntities = new ArrayList<>();
        
        int i = 0;

        // Let all animals act.
        for(Iterator<Entity> it = entities.iterator(); it.hasNext(); ) 
        {
            Entity entity = it.next();
 
            // Where the new animals list gets populated.
            entity.act(newEntities, clock);
                       
            if(!entity.isAlive()) 
            {
                it.remove();
            }
            
            i++;
        }
               
        // Add the newly born/grown entities to the main lists.
        entities.addAll(newEntities);
        entities.addAll(pendingEntities);
        pendingEntities.clear();
        reseed();
        
        view.showStatus(clock.getStatus(true, true, true, true, true), field);  
    }
    
    /**
     * Add an entity to the pending entities list.
     * 
     * @param entity The entity to be added to the pending entities list.
     */
    public void addPendingEntity(Entity entity)
    {
        pendingEntities.add(entity);
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        clock = new Clock();
        entities.clear();
        pendingEntities.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(clock.getStatus(true, true, true, true, true), field);
    }
    
    /*
     * Getters
     */
    
    /**
     * @return The list of species within this simulation.
     */
    public List<Species> getSpecies()
    {
        return species;
    }
    
    /**
     * Returns the view that the simulator is running on.
     * 
     * @return The view that the simulator is running on.
     */
    public SimulatorView getView()
    {
        return view;
    }
    
    /**
     * @return The simulation's field.
     */
    public Field getField() 
    { 
        return field; 
    }
    
    /*
     * Private methods
     */
    
    /**
     * Randomly replant plants that have died in free spaces on grid.
     */
    private void reseed()
    {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) 
        {
            for(int col = 0; col < field.getWidth(); col++) 
            {
                Location location = new Location(row, col);
                
                if (field.getObjectAt(location) == null)
                {
                    for (Iterator<Species> it = species.iterator(); it.hasNext(); )
                    {
                        Species currentSpecies = it.next();
                        
                        if (currentSpecies instanceof PlantSpecies && rand.nextDouble() <= RESEED_PROB)
                        {
                            // Grow new plant
                            entities.add(new Plant(field, location, (PlantSpecies)currentSpecies));
                            break;
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Randomly populate the field with entities.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) 
        {
            for(int col = 0; col < field.getWidth(); col++) 
            {
                Location location = new Location(row, col);
                for (Iterator<Species> it = species.iterator(); it.hasNext(); )
                {
                    Species currentSpecies = it.next();
                    
                    if (rand.nextDouble() <= currentSpecies.getCreationProbability()) 
                    {
                        Entity newEntity;
                        
                        if (currentSpecies instanceof AnimalSpecies)
                        {
                            newEntity = new Animal(null, field, location, (AnimalSpecies)currentSpecies);
                        }
                        else
                        {
                            newEntity = new Plant(field, location, (PlantSpecies)currentSpecies);
                        }
                        
                        entities.add(newEntity);
                        break;
                    }
                    
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Creates the default species objects.
     */
    private void defineDefaultSpecies()
    {
        // Define species.
        AnimalSpecies wolf = new AnimalSpecies("Wolf", 40, 0.02, 150, 4, 30, 0.7, true); // predator
        AnimalSpecies squirrel = new AnimalSpecies("Squirrel", 20, 0.04, 60, 8, 5, 0.9, true); // prey
        AnimalSpecies tiger = new AnimalSpecies("Tiger", 100, 0.01, 200, 3, 25, 0.8, true); // predator
        AnimalSpecies gull = new AnimalSpecies("Gull", 20, 0.03, 80, 7, 10, 0.9, true); // predator & prey
        AnimalSpecies ovis = new AnimalSpecies("Ovis", 20, 0.08, 100, 8, 6, 0.9, false); // prey
        AnimalSpecies bear = new AnimalSpecies("Bear", 100, 0.01, 200, 3, 25, 0.6, true); // prey
        
        PlantSpecies grass = new PlantSpecies("Grass", 60, 0.06, 100, 500);
        PlantSpecies berries = new PlantSpecies("Berries", 30, 0.08, 60, 500);
         
        // Define food sources.
        wolf.setFoodSource(squirrel);
        wolf.setFoodSource(ovis);
        wolf.setFoodSource(gull);
        
        squirrel.setFoodSource(berries);
        squirrel.setFoodSource(grass);
        
        bear.setFoodSource(tiger);
        bear.setFoodSource(wolf);
        
        tiger.setFoodSource(ovis);
        tiger.setFoodSource(wolf);
        tiger.setFoodSource(squirrel);
        tiger.setFoodSource(gull);
        
        gull.setFoodSource(squirrel);
        gull.setFoodSource(berries);
        
        ovis.setFoodSource(grass);
        ovis.setFoodSource(berries);
        
        // Add to list.
        species.add(wolf);
        species.add(squirrel);
        species.add(tiger);
        species.add(gull);
        species.add(ovis);
        species.add(grass);
        species.add(berries);
        species.add(bear);
    }
    
    /**
     * Returns a dictionary of Species - Color value pairs.
     * 
     * @return A hash map containing details of the colors for each species.
     */
    private HashMap<Species, Color> getColors()
    {
        // Stores the colors for each species.
        HashMap<Species, Color> colors = new HashMap<> ();
        
        for (Iterator<Species> it = species.iterator(); it.hasNext(); )
        {
            Species currentSpecies = it.next();
            
            colors.put(currentSpecies, Randomizer.getRandomColor());
        }
        
        return colors;
    }
}
