import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * A simple model of a zebra.
 * Zebras age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Zebra extends Animal
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a zebra can live but this can be reduced if a diseases is caught.
    private int max_age = 93;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.68;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // A shared random number generator to control disease spread.
    private static final Random randDisease = Randomizer.getRandom();
    // The time the zebras wake up
    private final int wakeUp = 4;
    // The time the zebras go to sleep
    private final int bedTime = 11; 

    // Individual characteristics (instance fields).

    // The zebra's age.
    private int age;

    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(max_age);
        }
    }

    /**
     * This is what the zebra does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newZebras A list to return newly born zebras.
     */
    public void act(List<Animal> newZebras)
    {
        incrementAge();

        if(isAlive()) {
            if (checkDisease()) {
                diseaseAffects();
                spread();
            }
            if ((getTime() >= wakeUp && getTime() < bedTime)  && isSun()){
                giveBirth(newZebras);            
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
            }
            else{
                Location sameLocation = getLocation();
                // Stay in the same location
                setLocation(sameLocation);
            }
        }

        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Increase the age.
     * This could result in the zebra's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > max_age) {
            setDead();
        }
    }

    /**
     * Check whether or not this zebra is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newZebras A list to return newly born zebras.
     */
    private void giveBirth(List<Animal> newZebras)
    {
        // New zebras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Zebra young = new Zebra(false, field, loc);
            newZebras.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if (mateNear() && canBreed() && (rand.nextDouble() <= BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A zebra can breed if it has reached the breeding age.
     * @return true if the zebra can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Check if the animal in the adjecent location is the opposite gender and the same animal
     * If they are the opposite gender and the same animal then allow them to breed
     * @return true if they are allowed to breed
     */
    private boolean mateNear() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        boolean mateFound = false;
        while (!mateFound && it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Zebra){
                if (((Zebra) animal).checkFemale() != this.checkFemale()) {
                    mateFound = true;
                }
            }
        }
        return mateFound;
    }

    /**
     * When the zebra contracts the disease it will lower its life span
     * Every zebra is affected differently by the disease
     * 
     */
    private void diseaseAffects()
    {
        max_age = rand.nextInt(max_age - age + 1) + age;
    }

    /**
     * When a zebra has a disease then its neighbouring zebras
     * also have a chance of catching the disease
     */
    private void spread() 
    {
        List <Animal> neighbours = new ArrayList <>();
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Zebra && randDisease.nextDouble() <= spreadProbability()) {
                ((Zebra) animal).diseaseAffects();
            }
        }
    }
}
