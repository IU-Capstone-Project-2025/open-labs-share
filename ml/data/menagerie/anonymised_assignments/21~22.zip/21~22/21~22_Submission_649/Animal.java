import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // Whether the animal is awake or not.
    private boolean awake;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // Gender of animal
    private boolean isFemale;
    // The current time in the simulation.
    private int time;
    // The current day in the simulation.
    private int day;
    // The type of weather 
    private String weather;
    // Whether the animal has a disease or not
    private boolean hasDisease; 
    // The probability the disease will spread to neighbouring animals 
    private double DISEASE_SPREAD_PROBABILITY; 

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        hasDisease = false;
        this.field = field;
        setLocation(location);
        this.isFemale = setGender();
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the animal is awake or not.
     * @return true if the animal is awake.
     */
    protected boolean isAwake()
    {
        return awake;
    }

    /**
     * Make the gender of the animal male
     */
    protected void makeMale()
    {
        this.isFemale = false;
    }

    /**
     * Check the gender of the animal
     * @return true if the gender is female
     * @return false if the gender is male
     */
    protected boolean checkFemale()
    {
        return isFemale; 
    }

    /**
     * Sets the gender of the animal 
     * @return true if the animal is female
     * @return false if the animal is male
     */
    protected boolean setGender()
    {
        Random random = new Random();

        int value = (Math.random() < 0.5) ? 1:2;

        if (value == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Set the time in the simulation
     * @param hour The time in the simulation
     */
    public void setTime(int hour)
    {
        time = hour;
    }

    /**
     * Return the time
     * @return the time it is in the simulation
     */
    protected int getTime()
    {
        return time;
    }

    /**
     * Set the day in the simulation
     * @param day The day in the simulation
     */
    public void setDay(int day)
    {
        day = day;
    }

    /**
     * Return the day
     * @return day The day it is in the simulation
     */
    protected int getDay()
    {
        return day;
    }
    
    /**
     * Set the weather in the simulation
     * @param dec The random probability of each weather occuring
     */
    public void setWeather(String currentWeather)
    {
       weather = currentWeather;
    }
    
    /**
     * Return the current weather of the simulation
     * @return weather The weather it is in the simulation
     */
    protected String getWeather()
    {
        return weather; 
    }
    
    /**
     * Check weather it is raining in the simulation or not
     * @return true if it is raining
     */
    protected boolean isRain()
    {
        return weather.equals("rain");
    }
    
    /**
     * Check weather it is sunny in the simulation or not
     * @return true if it is sunny
     */
    protected boolean isSun()
    {
        return weather.equals("sun");
    }
    
    /**
     * Give the disease to the animal
     * @return true 
     */
    protected void giveDisease()
    {
        hasDisease = true;
    }
    
    /**
     * Check weather the animal has the disease or not
     * @return true if the animal has the disease
     */
    protected boolean checkDisease()
    {
        return hasDisease; 
    }
    
    /**
     * Set the disease for the animal
     * @param length The duration of the disease
     * @param DISEASE_PROBABILITY The probability the disease will 
     * spread to neighbouring animals
     */
    public void setDisease(double DISEASE_PROBABILITY)
    {
        giveDisease();
        DISEASE_SPREAD_PROBABILITY = DISEASE_PROBABILITY;
    }
    
    /**
     * Get the probability that the disease will spread to neighbouring animals
     * @return DISEASE_SPREAD_PROBABILITY 
     */
    protected double spreadProbability()
    {
        return DISEASE_SPREAD_PROBABILITY;
    }
}
