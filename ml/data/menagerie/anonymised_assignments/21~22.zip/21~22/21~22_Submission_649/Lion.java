import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.lang.Math;
import java.util.ArrayList;

/**
 * A simple model of a lion.
 * Lions age, move, eat zebras and antelope, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Lion extends Animal {

    // Characteristics shared by all lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 35;
    // The age to which a lion can live but this can be reduced if a diseases is caught.
    private int max_age = 63;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.51;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single zebra and antelope. In effect, this is the
    // number of steps a lion can go before it has to eat again.
    private static final int ZEBRA_FOOD_VALUE = 8;
    private static final int ANTELOPE_FOOD_VALUE = 10;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // A shared random number generator to control disease spread.
    private static final Random randDisease = Randomizer.getRandom();
    // The time the lions wake up
    private final int wakeUp = 4;
    // The time the lions go to sleep
    private final int bedTime = 9; 
    
    // Individual characteristics (instance fields).
    // The lion's age.
    private int age;
    // The lion's food level, which is increased by eating zebras and antelopes.
    private int foodLevel;

    /**
     * Create a lion. A lion can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the lion will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(max_age);
            foodLevel = rand.nextInt((ZEBRA_FOOD_VALUE + ANTELOPE_FOOD_VALUE)/2);
        } else {
            age = 0;
            foodLevel = Math.round((ZEBRA_FOOD_VALUE + ANTELOPE_FOOD_VALUE)/2);
        }
    }

    
    /**
     * This is what the lion does most of the time: it hunts for
     * zebras and antelopes. In the process, it might breed, die of hunger,
     * or die of old age.
     *
     * @param newLions A list to return newly born lions.
     * @paramfield The field currently occupied.
     */
    public void act(List<Animal> newLions) {
        incrementAge();
        incrementHunger();
        if (isAlive()) {
            if (checkDisease()) {
                diseaseAffects();
                spread();
            }
            if ((getTime() >= wakeUp && getTime() < bedTime)  && isRain()){
                giveBirth(newLions);
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } 
                
                else {
                    // Overcrowding.
                    setDead();
                }
            }
            else {
                Location sameLocation = getLocation();
                // Stay in the same location
                setLocation(sameLocation);
                // to keep the hunger level the same
                foodLevel++; // to prevent lions dying of hunger while they are sleeping
            }
        }
    }

    /**
     * Increase the age. This could result in the lion's death.
     */
    private void incrementAge() {
        age++;
        if (age > max_age) {
            setDead();
        }
    }

    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    private void incrementHunger() {
        foodLevel--;
        if (foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for zebras and antelopes adjacent to the current location.
     * Only the first live zebra or antelope is eaten.
     *
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Zebra) {
                Zebra zebra = (Zebra) animal;
                if (zebra.isAlive()) {
                    zebra.setDead();
                    foodLevel = ZEBRA_FOOD_VALUE;
                    return where;
                }
            } 
            else {
                if (animal instanceof Antelope) {
                    Antelope antelope = (Antelope) animal;
                    if (antelope.isAlive()) {
                        antelope.setDead();
                        foodLevel = ANTELOPE_FOOD_VALUE;
                        return where;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this lion is to give birth at this step.
     * New births will be made into free adjacent locations.
     *
     * @param newLions A list to return newly born lions.
     */
    private void giveBirth(List<Animal> newLions) {
        // New lions are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lion young = new Lion(false, field, loc);
            newLions.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    private int breed() {
        int births = 0;
        if (mateNear() && canBreed() && (rand.nextDouble() <= BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A lion can breed if it has reached the breeding age.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }

    /**
     * Check if the animal in the adjecent location is the opposite gender and the same animal
     * If they are the opposite gender and the same animal then allow them to breed
     * @return true if they are allowed to breed
     */
    private boolean mateNear() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        boolean mateFound = false;
        while (!mateFound && it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Lion){
                if (((Lion) animal).checkFemale() != this.checkFemale()) {
                    mateFound = true;
                }
            }
        }
        return mateFound;
    }
    
     /**
     * When the lion contracts the disease it will lower its life span
     * Every lion is affected differently by the disease
     * 
     */
    private void diseaseAffects()
    {
        max_age = rand.nextInt(max_age - age + 1) + age;
    }

    /**
     * When a lion has a disease then its neighbouring lions
     * also have a chance of catching the disease
     */
    private void spread() 
    {
        List <Animal> neighbours = new ArrayList <>();
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Lion && randDisease.nextDouble() <= spreadProbability()) {
                ((Lion) animal).diseaseAffects();
            }
        }
    }
}
