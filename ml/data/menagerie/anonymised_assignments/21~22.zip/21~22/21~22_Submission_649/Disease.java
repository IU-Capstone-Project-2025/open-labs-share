import java.util.Random;
/**
 * A class representing a disease that may be contracted by 
 * the animals in the simulation
 *
 * @version 03/03/22
 */
public class Disease
{
    // The current animal
    private Animal animal;
    // The probability of contracting the disease
    private double DISEASE_PROBABILITY;
    // A random number generator to give the length of the disease.
    private static final Random randLength = Randomizer.getRandom(); 
    // A random number generator to give the probability of the disease.
    private static final Random randDiseaseProb = Randomizer.getRandom(); 

    
    /**
     * Create a new disease.
     * Set the duration of the disease 
     * And the likelihood of the animal catching the disease
     * 
     * @param animal The current animal
     */
    public Disease(Animal animal)
    {
        setDiseaseProbability();
        animal.setDisease(DISEASE_PROBABILITY);
    }
    
    /**
     * Set the probability of the animals contracting the disease
     * 
     */
    private void setDiseaseProbability(){
        DISEASE_PROBABILITY = randDiseaseProb.nextDouble();
    }
}

