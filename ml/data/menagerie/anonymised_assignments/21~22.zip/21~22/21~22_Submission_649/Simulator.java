import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing zebras, cheetahs, lions, antelopes and elephants.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.06;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.07;
    // The probability that a antelope will be created in any given grid position.
    private static final double ANTELOPE_CREATION_PROBABILITY = 0.16;
    // The probability that a elephant will be created in any given grid position.
    private static final double ELEPHANT_CREATION_PROBABILITY = 0.08;
    // The probability that a cheetah will be created in any given grid position.
    private static final double CHEETAH_CREATION_PROBABILITY = 0.06;
    // The probability that a disease will be created.
    private static final double DISEASE_CREATION_PROBABILITY = 0.002;
    
    // A random number generator for weather.
    private static final Random randWeather = Randomizer.getRandom();
    // A random number generator for disease.
    private static final Random randDisease = Randomizer.getRandom();


    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The current weather of the simulation.
    private String currentWeather; 
    // The current disease
    private Disease disease;

    public static void main(String[] args) {
        Simulator simulator = new Simulator();
        simulator.simulate(1000);
    }

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Zebra.class, Color.BLUE);
        view.setColor(Antelope.class, Color.GREEN);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Cheetah.class, Color.RED);
        view.setColor(Elephant.class, Color.GRAY);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Cheetahs, Zebras, Lions, Antelopes and Elephants.
     */
    public void simulateOneStep()
    {
        step++;
        setWeather();
   
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Let all zebras, antelope and elephants act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if (setDisease()) {
                disease = new Disease(animal);
            }
            animal.setTime(getHour());
            animal.setDay(getDay());
            animal.setWeather(currentWeather);
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born Cheetahs, Zebras, Liothen ns, Antelopes and Elephants to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field, getHour(), getDay(), currentWeather);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, getHour(), getDay(), currentWeather);
    }

    /**
     * Randomly populate the field with Cheetahs, Zebras, Lions, Antelopes and Elephants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    animals.add(zebra);
                }
                else if(rand.nextDouble() <= ANTELOPE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antelope antelope = new Antelope(true, field, location);
                    animals.add(antelope);
                }

                else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah = new Cheetah(true, field, location);
                    animals.add(cheetah);
                }

                else if(rand.nextDouble() <= ELEPHANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Elephant elephant = new Elephant(true, field, location);
                    animals.add(elephant);
                }
                // else leave the location empty.
            }
        }

    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Every step in the simulation is equivelent to two hours
     * Work out what hour in the day it is
     * @return the hour in day it is
     */
    public int getHour()
    {
        return (step % 12);
    }
    
    /**
     * Every 12 steps in the simulation is equivelent to one day
     * Work out what day it is
     * @return the day it is
     */
    public int getDay()
    {
        return (1 + (step / 12));
    }
    
    /**
     * Set the weather in the simulation
     * 
     */
    private void setWeather()
    {
        if (randWeather.nextDouble() < 0.5) {
            currentWeather = "rain";
        }
        else {
            currentWeather = "sun";
        }
    }
    
    /**
     * Create the disease in the simulation
     * 
     */
    private boolean setDisease(){
        return (randDisease.nextDouble() <= DISEASE_CREATION_PROBABILITY);
    }
    
}
