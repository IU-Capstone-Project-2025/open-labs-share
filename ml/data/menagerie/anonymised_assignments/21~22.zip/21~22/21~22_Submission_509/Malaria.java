import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a disease - Malaria.
 * Malaria infects animals and then die, 
 * however, animals keep spreading it when they meet.
 *
 * @version 2016.02.29 (2)
 */
public class Malaria 
{
    // Whether Malaria is alive or not.
    private boolean alive;
    // The Malaria's field.
    private Field field;
    // The Malaria's position in the field.
    private Location location;
    

    /**
     * Create Malaria.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Malaria(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Check whether the Malaria is alive or not.
     * @return true if the Malaria is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the Malaria is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the Malaria's location.
     * @return The Malaria's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the Malaria at the new location in the given field.
     * @param newLocation The Malaria's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the Malaria's field.
     * @return The Malaria's field.
     */
    protected Field getField()
    {
        return field;
    }
}
