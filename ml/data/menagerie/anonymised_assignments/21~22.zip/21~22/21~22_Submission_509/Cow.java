import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a cow.
 * Cow age, move, breed, meet, get infected, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Cow extends Animal
{
    // Characteristics shared by all cows (class variables).

    // The age at which a cow can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a cow can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a cow breeding.
    private static final double BREEDING_PROBABILITY = 0.12;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The cow's age.
    private int age;
    
    /**
     * Create a new cow. A cow may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the cow will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cow(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the cow does most of the time - it runs 
     * around. Sometimes it will breed, for that it will
     * need a partner, it might get infected by a disease,
     * or die of old age.
     * @param newCows A list to return newly born cows.
     */
    public void act(List<Animal> newCows)
    {
        incrementAge();
        if(isAlive()) {
            // checks the neighbouring cells for a disease.
            gotInfected();
            
            if(getInfectionStatus()){ // if it gets infected MAX_LITTER_SIZE decreases to 3.
                MAX_LITTER_SIZE = 3;
            }
            
            // seraches for a partner in the neighbouring cells to be able to give birth. 
            findPartner(newCows); 
            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age.
     * This could result in the cow's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Look for cows adjacent to the current location.
     * If it finds a cow that is alive, it will try to meet with it,
     * and only if they are both of opposite gender they will meet.
     * Then it will give birth to new cows. 
     * @param newCows A list to return newly born cows.
     */
    private void findPartner(List<Animal> newCows)
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cow) {
                Cow cow = (Cow) animal;
                if(cow.isAlive()) { 
                    meet(cow, newCows);
                }
            }
        }
    }
    
    /**
     * A cow can breed if its neighbour is of the opposite gender.
     * Change infection status if partner cow is infected. 
     * @return true if the cow can meet, false otherwise.
     */
    private void meet(Cow neighbourCow, List<Animal> newCows)
    {
        // checks for the partner cow's gender.
        if(! getGender().equals(neighbourCow.getGender())){
            // changes the infection status if partner cow is infected. 
            if(neighbourCow.getInfectionStatus()){
               setInfectionStatus();
            }
            // give birth to new cows. 
            giveBirth(newCows);
        }
    }
    
    /**
     * Check whether or not this cow is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCows A list to return newly born cows.
     */
    private void giveBirth(List<Animal> newCows)
    {
        // New cows are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cow young = new Cow(false, field, loc);
            newCows.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A cow can breed if it has reached the breeding age.
     * @return true if the cow can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
