import java.util.List;

/**
 * A simple model of orange tree.
 * Orange tree grow and die.
 *
 * @version 2016.02.29 (2)
 */
public class OrangeTree extends Plants
{
    // Characteristics shared by all orange trees (class variables).

    // The rate at which the orange tree grows.
    private static final int GROWING_RATE = 9;
    // The growth to which the orange tree can live.
    private static final int MAX_AGE = 2000;
    // The maximum number of oranges a tree can have.
    private static final int MAX_NUM_ORANGES = 20;
    
    // Individual characteristics (instance fields).
    
    // The orange tree's age.
    private int age;
    // The number of oranges on the tree.
    private int oranges;

    /**
     * Create a new orange tree. An orange tree is created with age zero,
     * and with zero oranges.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public OrangeTree(Field field, Location location)
    {
        super(field, location);
        age = 0;
        oranges = 0;
    }
    
    /**
     * This is what the orange tree does most of the time: it grows,
     * and it grows new oranges. 
     * @param newOrangeTrees A list to return new orange trees.
     * @param step to decide when the orange tree will grow,
     * depending on GROWING_RATE.
     */
    public void act(List<Plants> newOrangeTrees, int step)
    {
        if(step % GROWING_RATE == 0 ){
            incrementAge();
            incrementOranges();
        }
    }

    /**
     * Increase the age.
     * This could result in the orange tree's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Increase the number of oranges in a tree as it grows.
     */
    private void incrementOranges()
    {
        if(oranges <= MAX_NUM_ORANGES) {
             oranges++;
        }
    }
    
    /**
     * Decrease the number of oranges in a tree as a monkey picks them.
     */
    protected void pickOrange()
    {
        if(oranges > 0){
            oranges --;
        }
    }
    
    /**
     * Returns the number of oranges available in a tree.
     */
    protected int getNumOfOranges()
    {
        return oranges;
    }
}
