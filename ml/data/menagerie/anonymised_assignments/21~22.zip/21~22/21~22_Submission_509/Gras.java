import java.util.List;

/**
 * A simple model of grass.
 * Grass grow when it rains and die of old age.
 *
 * @version 2016.02.29 (2)
 */
public class Gras extends Plants
{
    // Characteristics shared by all grass (class variables).

    // The rate at which the grass grows.
    private static final int GROWING_RATE = 7;
    // The growth to which the grass can live.
    private static final int MAX_AGE = 20;
    
    // Individual characteristics (instance fields).
    
    // The gras age.
    private int age;

    /**
     * Create a new grass. A grass is created with age zero.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Gras(Field field, Location location)
    {
        super(field, location);
        age = 0;
    }
    
    /**
     * This is what the grass does most of the time: it only grows
     * @param newGras A list to return new grass.
     * @param step to decide when the gras will grow,
     * depending on GROWING_RATE.
     */
    public void act(List<Plants> newGras, int step)
    {
        if(step % GROWING_RATE == 0 ){
            incrementAge();
            //c ++;
            //System.out.println("GROW1 " + c);
            //reproduce(newGras);
        }
    }

    /**
     * Increase the age.
     * This could result in the gras's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
}
