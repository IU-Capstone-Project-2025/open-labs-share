import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of Cactus.
 * Cactus grow, reproduce and die.
 *
 * @version 2016.02.29 (2)
 */
public class Cactus extends Plants
{
    // Characteristics shared by all cacti (class variables).

    // The rate at which the Cactus grows.
    private static final int GROWING_RATE = 1;
    // The growth to which the Cactus can live.
    private static final int MAX_AGE = 500;
    // The age to which a catus can pollinate.
    private static final int POLLINATION_AGE = 500;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Cactus' age.
    private int age;

    /**
     * Create a new Cactus. A Cactus is created with age zero.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cactus(Field field, Location location)
    {
        super(field, location);
        age = 0;
    }
    
    /**
     * This is what the cactus does most of the time: it grows,
     * and it produces new cacti. 
     * @param newCactus A list to return new cacti.
     * @param step to decide when the cactus will grow,
     * depending on GROWING_RATE.
     */
    public void act(List<Plants> newCactus, int step)
    {
        //incrementAge();
        if(step % GROWING_RATE == 0 ){
            incrementAge();
            //c ++;
            //System.out.println("GROW1 " + c);
            //reproduce(newGras);
        }
        
        if(isAlive()){
            reproduce(newCactus); 
        }
    }

    /**
     * Increase the age.
     * This could result in the cactu's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Reproduce new cacti
     * @param newCactus A list to return new cacti.
     */
    protected void reproduce(List<Plants> newCactus)
    {
        // New cactus are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int Cactuses = pollination();
        for(int b = 0; b < Cactuses && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cactus small = new Cactus(field, loc);
            newCactus.add(small);
        }
    }
    
    /**
     * Generate a number representing the number of new cacti,
     * if it can pollinate.
     * @return The number of new cacti (may be zero).
     */
    private int pollination()
    {
        int Cactuses = 0;
        if(canPollinate() && rand.nextDouble() <= GROWING_RATE) {
            Cactuses = rand.nextInt(1) + 1;
        }
        return Cactuses;
    }
    
    /**
     * A cactus can pollinate if it has reached the pollination age.
     */
    private boolean canPollinate()
    {
        return age >= POLLINATION_AGE;
    }
}
