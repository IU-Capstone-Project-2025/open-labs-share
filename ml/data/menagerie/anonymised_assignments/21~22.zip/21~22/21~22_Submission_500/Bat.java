import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a bat.
 * Bats only act at night, and sleep during the day. They age, move, breed, check their environment,
 * eat mosquito, spread infection, get infected, and die.
 * 
 * @version 2022.03.02
 */
public class Bat extends Animal
{
    // Characteristics shared by all bats (class variables).
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The age at which a bat can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a bat can live.
    private static final int MAX_AGE = 85;
    // The likelihood of a bat breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a prey. In effect, this is the
    // number of steps a bat can go before it has to eat again.
    private static final int MOSQUITO_FOOD_VALUE = 9;
    // Chance of spreading infection
    private static final double INFECTION_CHANCE = 0.002;
    // Chance of contacting infection
    private static final double INFECTION_CONTACT_CHANCE = 0.025;
    
    // Individual characteristics (instance fields).
    // The bat's age.
    private int age;
    // The bat's food level, which is increased by eating mosquitoes.
    private int foodLevel;
    
    /**
     * Create a bat. A bat can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the bat will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bat(boolean randomAge, Field field, Location location, boolean infectionContact)
    {
        super(field, location, infectionContact);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MOSQUITO_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = MOSQUITO_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the bat does most of the time: it hunts for
     * bats. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newBats A list to return newly born bats.
     */
    public void act(List<Actor> newBats)
    {
        incrementAge();
        
        // Only increment hunger at daytime or if infected
        if(checkDay() || isInfected()) {
            incrementHunger();
        } else {
            checkDead();
        }
        
        if(isAlive()) {
            if(!checkDay()){
                // If the rabbit is mature, female and has a male mating partner nearby, it will reproduce
                if(canBreed() && findMate()){
                    giveBirth(newBats);       
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());  // check for instance of grass
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            } else {
                checkDead();
            }
        }
        
        // Get infected if contacted by the infection
        if(isContacted() && rand.nextDouble() <= INFECTION_CHANCE) {
            infect();
        }
    }

    /**
     * Increase the age.
     * This could result in the hare's death.
     */
    private void incrementAge()
    {
        age++;
        checkDead();
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        checkDead();
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void checkDead()
    {
        if(age > MAX_AGE || foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for bats adjacent to the current location.
     * Only the first live bat is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Mosquito) {
                Mosquito mosquito = (Mosquito) animal;
                if(mosquito.isAlive()) { 
                    mosquito.setDead();
                    foodLevel = MOSQUITO_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Look for bats adjacent to the current location.
     * Only the first male bat is chosen as partner. Infection can be spread.
     * @return Whether a suitable mating partner exists
     */
    private boolean findMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Bat) {
                Bat bat = (Bat) animal;
                // Spread the infection to the mating partner depending on the probability of spreading the infection
                if(isInfected() && rand.nextDouble() <= INFECTION_CONTACT_CHANCE){
                    bat.contactInfection();
                }
                if(!bat.isFemale()) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check whether or not this bat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBats A list to return newly born bats.
     */
    private void giveBirth(List<Actor> newBats)
    {
        // New bats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bat young = new Bat(false, field, loc, false);
            newBats.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A bat can breed if it has reached the breeding age and is female.
     * @return true if the bat can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && isFemale());
    }
}
