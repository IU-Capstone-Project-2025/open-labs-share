import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing hares, coyotes, wolves, grass, bats and mosquitoes.
 *
 * @version 2022.03.02 (3)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 180;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a coyote will be created in any given grid position.
    private static final double COYOTE_CREATION_PROBABILITY = 0.02;
    // The probability that a hare will be created in any given grid position.
    private static final double HARE_CREATION_PROBABILITY = 0.085;  
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.02;
    // The probability that a bat will be created in any given grid position.
    private static final double BAT_CREATION_PROBABILITY = 0.02;
    // The probability that a mosquito will be created in any given grid position.
    private static final double MOSQUITO_CREATION_PROBABILITY = 0.04;

    // List of animals in the field.
    private List<Actor> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private List<SimulatorView> views;
    
    // The number of steps in a full day
    private static final int DEFAULT_DAY_LENGTH = 24;
    
    // The number of steps in a day (without night)
    private static final int DAY_LENGTH = 12;
    
    // The number of days passed in the simulation
    private int day;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);
        
        views = new ArrayList<>();

        // Create a view of the state of each location in the field.
        SimulatorView view = new GridView(depth, width);
        view.setColor(Hare.class, Color.ORANGE);
        view.setColor(Coyote.class, Color.BLUE);
        view.setColor(Wolf.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Bat.class, Color.BLACK);
        view.setColor(Mosquito.class, Color.RED);
        
        views.add(view);
        
        // Create a view with the graph of populations
        view = new GraphView(500, 150, 500);
        view.setColor(Hare.class, Color.ORANGE);
        view.setColor(Coyote.class, Color.BLUE);
        view.setColor(Wolf.class, Color.GRAY);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Bat.class, Color.BLACK);
        view.setColor(Mosquito.class, Color.RED);
        
        views.add(view);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && views.get(0).isViable(field); step++) {
            simulateOneStep();
            delay(180);
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * actor.
     */
    public void simulateOneStep()
    {
        checkTime();
        field.updateWeather();
        
        step++;

        // Provide space for newborn animals.
        List<Actor> newActors = new ArrayList<>();        
        // Let all hares act.
        for(Iterator<Actor> it = animals.iterator(); it.hasNext(); ) {
            Actor animal = it.next();
            animal.act(newActors);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born coyotes and hares to the main lists.
        animals.addAll(newActors);

        updateViews();
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        day = 0;
        animals.clear();
        for (SimulatorView view : views) {
            view.reset();
        }

        populate();
        updateViews();
    }
    
    /**
     * Update all existing views.
     */
    private void updateViews()
    {
        for (SimulatorView view : views) {
            view.showStatus(step, field, field.getDay(), field.getWeather());
        }
    }
    
    /**
     * Randomly populate the field with actors.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= COYOTE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Coyote coyote = new Coyote(true, field, location, true);
                    animals.add(coyote);
                }
                else if(rand.nextDouble() <= HARE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hare hare = new Hare(true, field, location, true);
                    animals.add(hare);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location, true);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= BAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bat bat = new Bat(true, field, location, true);
                    animals.add(bat);
                }
                else if(rand.nextDouble() <= MOSQUITO_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mosquito mosquito = new Mosquito(true, field, location, true);
                    animals.add(mosquito);
                }
                else {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    animals.add(grass);
                }
                // else generate grass on the field
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    /**
     * Determine time by the number of steps taken in the simulation.
     * Set day or night state depending on the time.
     */
    public void checkTime()
    {
         int time = step % DEFAULT_DAY_LENGTH;
         if(time <= DAY_LENGTH) {
             if(!field.getDay()) {
                 field.toggleDay();
             }
         } else {
             if(field.getDay()) {
                 field.toggleDay();
             }
         }
    }
}
