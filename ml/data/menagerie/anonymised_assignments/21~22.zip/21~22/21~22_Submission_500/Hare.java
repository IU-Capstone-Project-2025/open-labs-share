import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a hare.
 * Hares age, move, breed, check their environment, eat grass,
 * spread infection, get infected, and die.
 * 
 * @version 2022.03.02
 */
public class Hare extends Animal
{
    // Characteristics shared by all hares (class variables).
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The age at which a hare can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a hare can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a hare breeding.
    private static final double BREEDING_PROBABILITY = 0.45;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a prey. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int GRASS_FOOD_VALUE = 6;
    // Chance of spreading infection
    private static final double INFECTION_CHANCE = 0.0085;
    // Chance of contacting infection
    private static final double INFECTION_CONTACT_CHANCE = 0.0085;
    
    // Individual characteristics (instance fields).
    // The hare's age.
    private int age;
    // The hare's food level, which is increased by eating grass.
    private int foodLevel;
    
    /**
     * Create a new hare. A hare may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the hare will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hare(boolean randomAge, Field field, Location location, boolean infectionContact)
    {
        super(field, location, infectionContact);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the hare does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newHares A list to return newly born hares.
     */
    public void act(List<Actor> newHares)
    {
        incrementAge();
        
        // Only increment hunger at daytime or if infected
        if(checkDay() || isInfected()) {
            incrementHunger();
        } else {
            checkDead();
        }
        
        if(isAlive()) {
            if(checkDay()){
                // If the hare is mature, female and has a male mating partner nearby, it will reproduce
                if(canBreed() && findMate()){
                    giveBirth(newHares);       
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());  // check for instance of grass
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            } else {
                checkDead();
            }
        }
        
        // Get infected if contacted by the infection
        if(isContacted() && rand.nextDouble() <= INFECTION_CHANCE) {
            infect();
        }
    }

    /**
     * Increase the age.
     * This could result in the hare's death.
     */
    private void incrementAge()
    {
        age++;
        checkDead();
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        checkDead();
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void checkDead()
    {
        if(age > MAX_AGE || foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for hares adjacent to the current location.
     * Only the first live hare is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Grass) {
                Grass grass = (Grass) animal;
                if(grass.isAlive() && grass.getEdible()) { 
                    grass.setDead();
                    foodLevel = GRASS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Look for hares adjacent to the current location.
     * Only the first male hare is chosen as partner. Infection can be spread.
     * @return Whether a suitable mating partner exists
     */
    private boolean findMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hare) {
                Hare hare = (Hare) animal;
                // Spread the infection to the mating partner depending on the probability of spreading the infection
                if(isInfected() && rand.nextDouble() <= INFECTION_CONTACT_CHANCE){
                    hare.contactInfection();
                }
                if(!hare.isFemale()) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check whether or not this hare is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHares A list to return newly born hares.
     */
    private void giveBirth(List<Actor> newHares)
    {
        // New hares are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hare young = new Hare(false, field, loc, false);
            newHares.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hare can breed if it has reached the breeding age and is female.
     * @return true if the hare can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && isFemale());
    }
}
