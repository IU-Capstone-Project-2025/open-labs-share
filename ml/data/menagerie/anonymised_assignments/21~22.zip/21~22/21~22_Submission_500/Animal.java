import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 * 
 * @version 2022.03.02
 */
public abstract class Animal extends Actor
{
    // A shared random number generator to determine whether an animal is female/male.
    private static final Random rand = Randomizer.getRandom();
    
    // Whether the animal is female or not
    private boolean female;
    
    // Whether the animal is infected
    private boolean infected;
    
    // Whether the animal contacted an infected animal
    private boolean infectionContact;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, boolean infectionContact)
    {
        super(field, location);
        setLocation(location);
        
        female = getGender();
        
        infectionContact = this.infectionContact;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newActors A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newAnimals);
    
    /**
     * Decide the animal's gender with a 50 percent chance to be male or female.
     * @return boolean where true means the animal is female.
     */
    protected boolean getGender()
    {
        return rand.nextBoolean();
    }
    
    /**
     * Check whether the animal is female or not.
     * @return true if the animal is female.
     */
    protected boolean isFemale()
    {
        return female;
    }
    
    /**
     * Check whether the animal is infected or not.
     * @return true if the animal is infected.
     */
    protected boolean isInfected()
    {
        return infected;
    }
    
    /**
     * Check whether the animal contacted another animal with an infection.
     * @return true if the animal has contacted the infection.
     */
    protected boolean isContacted()
    {
        return infectionContact;
    }
    
    /**
     * Set the state of the animal to infected.
     */
    protected void infect()
    {
        infected = true;
    }
    
    /**
     * Set the state of the animal to contacted the infection.
     */
    protected void contactInfection()
    {
        infectionContact = true;
    }
}
