import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a grass.
 * Grasses mature, propagate to nearby tiles in daylight or rain,
 * get trampled by other actors (disappear), and die.
 * 
 * @version 2022.03.02
 */
public class Grass extends Actor
{
    // Characteristics shared by all grasses (class variables).
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The age at which a grass can start to be a viable food source and propagate.
    private static final int MATURE_AGE = 2;
    
    // Individual characteristics (instance fields).
    // The grass' age.
    private int age;
    // Whether the grass is edible.
    private boolean edible;

    /**
     * Create a grass. A grass can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the grass will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MATURE_AGE);
        }
        else {
            age = 0;
        }
        
        // Young grass is never edible
        edible = false;
    }
    
    /**
     * This is what the grass does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newGrasses A list to return newly born grasses.
     */
    public void act(List<Actor> newGrasses)
    {
        if(isAlive()) {
            // Grow if it's sunny (daytime and no clouds)
            if(checkDay() && !checkCloud()) {
                incrementAge();
            }
            // Die if trampled on by other species
            if(!(getField().getObjectAt(getLocation()) instanceof Grass)) {
                setDead();
            }
            // Propagate to adjacent empty tiles if it's sunny or rainy
            if(isAlive() && ((age == MATURE_AGE && checkDay()) || checkRain())) {
                giveBirth(newGrasses);
            }
        }
    }

    /**
     * Increase the age. This could result in grass becoming mature and edible.
     */
    private void incrementAge()
    {
        if(age <= MATURE_AGE) {
            age++;
        }
        if(age == MATURE_AGE) {
            setEdible();
        }
    }
    
    /**
     * Check whether or not this grass is to propagate at this step.
     * New grasses will be placed into free adjacent locations.
     * @param newGrasses A list to return newly born grasses.
     */
    private void giveBirth(List<Actor> newGrasses)
    {
        // New grasses are placed into adjacent locations.
        // Get a list of adjacent empty locations.
        Field field = getField();
        List<Location> free = field.getEmptyAdjacentLocations(getLocation());
        int births = 9;
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrasses.add(young);
        }
    }

    
    /**
     * Set whether the grass is edible.
     */
    private void setEdible()
    {
        edible = !edible;
    }
    
    /**
     * Return if the grass is mature enough to be edible.
     * @return Whether the grass is edible.
     */
    public boolean getEdible()
    {
        return edible;
    }
}
