import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2022.03.02
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that an anaconda will be created in any given grid position.
    private static final double ANACONDA_CREATION_PROBABILITY = 0.01;
    // The probability that a caiman will be created in any given grid position.
    private static final double CAIMAN_CREATION_PROBABILITY = 0.015;
    // The probability that a capybara will be created in any given grid position.
    private static final double CAPYBARA_CREATION_PROBABILITY = 0.06;
    // The probability that a jaguar will be created in any given grid position.
    private static final double JAGUAR_CREATION_PROBABILITY = 0.0075;
    // The probability that a tapir will be created in any given grid position.
    private static final double TAPIR_CREATION_PROBABILITY = 0.06;
    // The probability that a fruit will be created in any given grid position.
    private static final double FRUIT_CREATION_PROBABILITY = 0.4;
    // The probability that a shrub will be created in any given grid position.
    private static final double SHRUB_CREATION_PROBABILITY = 0.5;
    // The probability that a weather object will be created in any grid position.
    private static final double WEATHER_CREATION_PROBABILITY = 0.25;
    // The probability that a weather object will spread in a given radius.
    private static final double WEATHER_SPREADING_PROBABILITY = 0.5;

    // List of animals in the field.
    private final List<Animal> animals;
    // List of plants in the field.
    private final List<Plant> plants;
    //List of weathers in the field.
    private final List<Weather> weathers;
    // The current state of the field.
    private final Field field;

    private final Field weatherField;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private final SimulatorView view;

    private final SimulatorView weatherView;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * Also create a simulation field for the weather.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        weathers = new ArrayList<>();
        field = new Field(depth, width);
        weatherField = new Field(depth, width);

        // Create a view of the state of each location in the field.
        weatherView = new SimulatorView(depth, width);
        view = new SimulatorView(depth, width);

        view.setColor(Anaconda.class, Color.MAGENTA);
        view.setColor(Jaguar.class, Color.YELLOW);
        view.setColor(Caiman.class, Color.CYAN);
        view.setColor(Tapir.class, Color.BLACK);
        view.setColor(Capybara.class, Color.ORANGE);
        view.setColor(Fruit.class, Color.RED);
        view.setColor(Shrub.class, Color.GREEN);

        weatherView.setColor(Sun.class, Color.YELLOW);
        weatherView.setColor(Rain.class, Color.BLUE);
        weatherView.setColor(Fog.class, Color.GRAY);
        weatherView.setColor(Thunder.class, Color.BLACK);

        // Setup a valid starting point.
        reset();
    }


    public static void main(String[] args) {
        Simulator sim = new Simulator();
        sim.runLongSimulation();
    }
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     *
     */
    public void simulateOneStep() {
        Random r = new Random();
        step++;

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        // Let all animals act.
        for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, getTimeOfDay(), weathers);
            if (!animal.isAlive()) {
                it.remove();
            }
        }
        for (Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.grow(newPlants, getTimeOfDay(), weathers);
            if (!plant.isAlive()) {
                it.remove();
            }
        }

        for (Iterator<Weather> it = weathers.iterator(); it.hasNext(); ) {
            Weather weather = it.next();
            weather.act(animals, plants);
            if (!weather.getActive()) {
                weatherField.clear(weather.getLocation());
                it.remove();
            }
        }

        for (Weather weath : weathers) {
            weatherField.place(weath, weath.getLocation().getRow(), weath.getLocation().getCol());
        }

        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        plants.addAll(newPlants);

        weatherView.showStatus(step, weatherField);
        view.showStatus(step, field);

        for (int i = 0; i < r.nextInt(29); i++) {
            if (r.nextDouble() < WEATHER_CREATION_PROBABILITY) {
                Location location;
                do {
                    location = new Location(r.nextInt(field.getDepth()), r.nextInt(field.getWidth()));
                } while (checkWeatherLocation(location));
                spreadWeather(location.getRow(), location.getCol(), createNewWeather(location));
            }
        }
    }


    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        weatherView.showStatus(step, field);
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     *
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= ANACONDA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Anaconda anaconda = new Anaconda(true, field, location);
                    animals.add(anaconda);
                } else if (rand.nextDouble() <= CAIMAN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Caiman caiman = new Caiman(true, field, location);
                    animals.add(caiman);
                } else if (rand.nextDouble() <= CAPYBARA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Capybara capybara = new Capybara(true, field, location);
                    animals.add(capybara);
                } else if (rand.nextDouble() <= JAGUAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Jaguar jaguar = new Jaguar(true, field, location);
                    animals.add(jaguar);
                } else if (rand.nextDouble() <= TAPIR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Tapir tapir = new Tapir(true, field, location);
                    animals.add(tapir);
                } else if (rand.nextDouble() <= FRUIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fruit fruit = new Fruit(true, field, location);
                    plants.add(fruit);
                } else if (rand.nextDouble() <= SHRUB_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shrub shrub = new Shrub(true, field, location);
                    plants.add(shrub);
                }

                // Not connected to if statement above since we need weathers to have same location
                // as other objects in order to affect their behaviours.
                if (rand.nextDouble() <= WEATHER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Weather weather = createNewWeather(location);
                    if (!checkWeatherLocation(location)) {
                        weathers.add(weather);
                        spreadWeather(row, col, weather);
                    }
                }

                // else leave the location empty.
            }
        }
    }

    /**
     * Checks if there is a weather object existing in the parsed
     * location.
     *
     * @param location The location of the weather to be checked.
     * @return true if there is a weather object with the location
     * provided.
     */
    private boolean checkWeatherLocation(Location location) {
        for (Weather weath : weathers) {
            if (weath.sameLocation(location)) {
                return true;
            }
        }
        return false;
    }

    /**
     * When a weather object is created, there's also a chance that
     * within a random radius, identical weather objects are also
     * created.
     *
     * @param row     the row of the initial weather object.
     * @param col     the col of the initial weather object.
     * @param weather the list of all the weathers on the field.
     */
    private void spreadWeather(int row, int col, Weather weather) {
        Random r = new Random();
        int radius = getWeatherRadius();
        for (int i = Math.max((row - radius), 0); i < Math.min(field.getDepth(), row + radius); i++) {
            for (int j = Math.max(col - radius, 0); j < Math.min(field.getWidth(), col + radius); j++) {
                if (r.nextDouble() <= WEATHER_SPREADING_PROBABILITY) {
                    Location location = new Location(i, j);
                    if (!checkWeatherLocation(location)) {
                        weathers.add(createNewWeather(location, weather));
                    }
                }
            }
        }
    }

    /**
     * @return The radius in which the initial weather objects
     * will spread to.
     */
    private int getWeatherRadius() {
        Random r = new Random();
        return r.nextInt(8);
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    public int getTimeOfDay() {
        return step % 24;
    }

    /**
     * @return A random type of weather.
     */
    private weatherTypes getRandomWeatherType() {
        Random r = new Random();
        switch (r.nextInt(4)) {
            case (0):
                return weatherTypes.RAIN;
            case (1):
                return weatherTypes.THUNDER;
            case (2):
                return weatherTypes.FOG;
            case (3):
                return weatherTypes.SUN;
            default:
                return null;
        }
    }

    /**
     * Crates a new weather object.
     *
     * @param location the location to create the weather object
     *                 at.
     * @param weather  the weather type the object should be.
     * @return The newly created weather object.
     */
    private Weather createNewWeather(Location location, Weather weather) {
        if (weather instanceof Rain) {
            weather = new Rain(location);
        } else if (weather instanceof Fog) {
            weather = new Fog(location);
        } else if (weather instanceof Thunder) {
            weather = new Thunder(location);
        } else {
            weather = new Sun(location);
        }
        return weather;
    }

    /**
     * Creates a radom new weather object.
     *
     * @param location the location to create the weather object
     *                 at.
     * @return The newly created weather object.
     */
    private Weather createNewWeather(Location location) {
        Weather weather;
        weatherTypes randomWeatherType = getRandomWeatherType();

        if (randomWeatherType == weatherTypes.RAIN) {
            weather = new Rain(location);
        } else if (randomWeatherType == weatherTypes.FOG) {
            weather = new Fog(location);
        } else if (randomWeatherType == weatherTypes.THUNDER) {
            weather = new Thunder(location);
        } else {
            weather = new Sun(location);
        }
        return weather;
    }

    /**
     * Simple enum to identify the different types of weather.
     *
     */
    enum weatherTypes {
        RAIN,
        SUN,
        FOG,
        THUNDER
    }
}
