import java.util.List;
import java.util.Random;

/**
 * A class which models the behaviour of a Tapir
 * <p>
 * Code adapted from Fox class of this project, by David J. Barnes and Michael KÃÂ¶lling.
 *
 * @version 2022.03.02
 */
public class Tapir extends Animal {
    //Characteristics shared by all tapirs

    // The age at which a tapir can start to breed.
    private static final int BREEDING_AGE = 25;
    // The age to which a tapir can live.
    private static final int MAX_AGE = 400;
    // The likelihood of a tapir breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // The food value of a capybara, this is the amount of steps
    // this is the number of steps a tapir can go without eating again.
    private static final int SHRUB_FOOD_VALUE = 8;
    // The food value of a tapir, this is the amount of steps
    // this is the number of steps a tapir can go without eating again.
    private static final int FRUIT_FOOD_VALUE = 10;
    // The probability that when a tapir is born it is diseased.
    private static final double DISEASED_PROBABILITY = 0.005;
    // The probability that the disease is spread to an adjacent tapir.
    private static final double DISEASE_SPREAD_PROBABILITY = 0.075;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Creates a new tapir, tapirs can be created in two different ways,
     * they may be born at age 0, or they may be created with a random age and hunger.
     * Each time a tapir is created they have a random chance of being diseased.
     *
     * @param randomAge if false they are born, if true they are randomly created
     * @param field     the field in which they are contained
     * @param location  the location within the field
     */
    public Tapir(boolean randomAge, Field field, Location location) {
        super(field, location);
        setDiseased(rand.nextDouble() <= DISEASED_PROBABILITY);
        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            //Capybara food value used as it gives more range
            setFoodLevel(rand.nextInt(FRUIT_FOOD_VALUE));
        } else {
            setAge(0);
            setFoodLevel(FRUIT_FOOD_VALUE);
        }
    }

    @Override
    public void act(List<Animal> newTapirs, int timeOfDay, List<Weather> weathers) {
        incrementAge();
        //If the time is between 7am and 5pm the tapir will perform normal function, otherwise sleeps.
        if (isAlive() && (timeOfDay >= 6 && timeOfDay <= 16)) {
            incrementHunger();
            if (isAlive()) {
                giveBirth(newTapirs, weathers);
                if (isDiseased()) {
                    spreadDisease();
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }


    @Override
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object plant = field.getObjectAt(where);
            if (plant instanceof Shrub) {
                Shrub shrub = (Shrub) plant;
                if (shrub.isRipe()) {
                    shrub.setDead();
                    setFoodLevel(getFoodLevel() + SHRUB_FOOD_VALUE);
                    return where;
                }
            } else if (plant instanceof Fruit) {
                Fruit fruit = (Fruit) plant;
                if (fruit.isRipe()) {
                    fruit.setDead();
                    setFoodLevel(getFoodLevel() + FRUIT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether this tapir is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the parent animal is diseased then the children will
     * also be born diseased.
     *
     * @param newTapirs A list to return newly born anacondas.
     */
    private void giveBirth(List<Animal> newTapirs, List<Weather> weathers) {
        // New tapirs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(weathers);
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tapir young = new Tapir(false, field, loc);
            if (isDiseased()) {
                young.setDiseased(true);
            }
            newTapirs.add(young);
        }
    }


    @Override
    protected int getBREEDING_AGE() {
        return BREEDING_AGE;
    }

    @Override
    protected double getBREEDING_PROBABILITY() {
        return BREEDING_PROBABILITY;
    }

    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected int getMAX_AGE() { return MAX_AGE; }

    @Override
    protected double getDISEASE_SPREAD_PROBABILITY() {return DISEASE_SPREAD_PROBABILITY; }
}