import java.util.List;
import java.util.Random;

/**
 * A class which models the behaviour of a Capybara
 * <p>
 * Code adapted from Fox class of this project, by David J. Barnes and Michael KÃÂ¶lling.
 *
 * @version 2022.03.02
 */
public class Capybara extends Animal {
    //Characteristics shared by all Capybaras


    // The age at which a Capybara can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a capybara can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a capybara breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    // The food value of a shrub,
    // this is the number of steps a capybara can go without eating again.
    private static final int SHRUB_FOOD_VALUE = 8;
    // The food value of a fruit, this is the number of steps
    // a capybara can go without eating again.
    private static final int FRUIT_FOOD_VALUE = 10;
    // The probability that when a capybara is born it is diseased.
    private static final double DISEASED_PROBABILITY = 0.02;
    // The probability that the disease is passed to an adjacent capybara.
    private static final double DISEASE_SPREAD_PROBABILITY = 0.075;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    /**
     * Creates a new capybara, capybaras can be created in two different ways,
     * they may be born at age 0, or they may be created with a random age and hunger.
     * Each time a capybara is created they have a random chance of being diseased.
     *
     * @param randomAge if false they are born, if true they are randomly created
     * @param field     the field in which they are contained
     * @param location  the location within the field
     */
    public Capybara(boolean randomAge, Field field, Location location) {
        super(field, location);
        setDiseased(rand.nextDouble() <= DISEASED_PROBABILITY);
        if (randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            //Fruit food value used as it gives more range
            setFoodLevel(rand.nextInt(FRUIT_FOOD_VALUE));
        } else {
            setAge(0);
            setFoodLevel(FRUIT_FOOD_VALUE);
        }
    }

    @Override
    public void act(List<Animal> newCapybaras, int timeOfDay, List<Weather> weathers) {
        incrementAge();
        //If the time is between 5am and 9pm the capybara will perform normal function, otherwise sleeps.
        if (isAlive() && (timeOfDay >= 4 && timeOfDay <= 20)) {
            incrementHunger();
            if (isAlive()) {
                giveBirth(newCapybaras, weathers);
                if (isDiseased()) {
                    spreadDisease();
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if (newLocation == null) {
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    @Override
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object plant = field.getObjectAt(where);
            if (plant instanceof Shrub) {
                Shrub shrub = (Shrub) plant;
                if (shrub.isRipe()) {
                    shrub.setDead();
                    setFoodLevel(getFoodLevel() + SHRUB_FOOD_VALUE);
                    return where;
                }
            } else if (plant instanceof Fruit) {
                Fruit fruit = (Fruit) plant;
                if (fruit.isRipe()) {
                    fruit.setDead();
                    setFoodLevel(getFoodLevel() + FRUIT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether this capybara is to give birth at this step.
     * New births will be made into free adjacent locations.
     * If the parent animal is diseased then the children will
     * also be born diseased.
     *
     * @param newCapybaras A list to return newly born caimans.
     */
    private void giveBirth(List<Animal> newCapybaras, List<Weather> weathers) {
        // New capybaras are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(weathers);
        for (int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Capybara young = new Capybara(false, field, loc);
            if (isDiseased()) {
                young.setDiseased(true);
            }
            newCapybaras.add(young);
        }
    }


    @Override
    protected int getBREEDING_AGE() {
        return BREEDING_AGE;
    }

    @Override
    protected double getBREEDING_PROBABILITY() {
        return BREEDING_PROBABILITY;
    }

    @Override
    protected int getMAX_LITTER_SIZE() {
        return MAX_LITTER_SIZE;
    }

    @Override
    protected int getMAX_AGE() { return MAX_AGE; }

    @Override
    protected double getDISEASE_SPREAD_PROBABILITY() {return DISEASE_SPREAD_PROBABILITY; }
}