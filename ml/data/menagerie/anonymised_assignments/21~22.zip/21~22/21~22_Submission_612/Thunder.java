import java.util.List;

/**
 * Subclass of Weather. This class imitates Thunder on the field.
 *
 * @version 2022.03.02
 */
public class Thunder extends Weather {
    public Thunder(Location location) {
        super(location);
        setMAX_DURATION(75);
    }

    /**
     * Increments thunder object, and alters active field if too old.
     *
     * @param animals The list of all active animals on the field.
     * @param plants  The list of all active plants on the field.
     */
    public void act(List<Animal> animals, List<Plant> plants) {
        incrementDuration();
        if (getCURRENT_DURATION() > getMAX_DURATION()) {
            setInactive();
        }
    }

    /**
     * Determines the additional probability a plant is affected
     * by thunder.
     *
     * @param plant The plant that is to be affected.
     * @return additional probability to add to breeding chance.
     */
    protected double getPlantBirthProbability(Plant plant) {
        return -0.275;
    }

    /**
     * Determines the additional probability an animal is affected
     * by thunder.
     *
     * @param animal The animal that is to be affected.
     * @return additional probability to add to breeding chance.
     */
    protected double getAnimalBirthProbability(Animal animal) {
        return -0.05;
    }

    /**
     * Determines which plants and animals are affected by thunder.
     *
     * @param plant  The plant being checked if affected.
     * @param animal The animal being checked if affected.
     * @return true if a specific type of animal/plant is
     * affected by thunder.
     */
    protected boolean weatherAffects(Plant plant, Animal animal) {
        if (plant != null) {
            return plant instanceof Fruit;
        } else {
            return animal instanceof Tapir || animal instanceof Capybara;
        }
    }
}
