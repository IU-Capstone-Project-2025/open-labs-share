public class Rainy extends Weather
{
}
