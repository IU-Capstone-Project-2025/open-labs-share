
public abstract class Weather
{
}
