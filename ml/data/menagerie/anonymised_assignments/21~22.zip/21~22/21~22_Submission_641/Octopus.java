import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of an octopus.
 * Octopuses age, move, eat crab,give birth and die.
 *
 * @version 28/02/2022
 */
public class Octopus extends Animal
{
    // Characteristics shared by all octopuses (class variables).
    // The age at which a octopus can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a octopus can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a octopus breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single crab. In effect, this is the
    // number of steps a octopus can go before it has to eat again.
    private static final int CRAB_FOOD_VALUE = 50;
    
    /**
     * Create a octopus. A octopus can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the octopus will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Octopus(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            setFoodLevel(getRandom().nextInt(CRAB_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(CRAB_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the octopus does most of the time: it hunts for
     * octopuses. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newTunas A list to return newly born octopuses.
     */
    public void act(List<Actor> newOctopuses)
    {
        if (hasInfection) {
            effectOfInfection();
        }
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(isFemale() && oppositeGender()){
                giveBirth(newOctopuses); 
            } 
                       
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this octopus more hungry. This could result in the octopus's death.
     */
    private void incrementHunger()
    {
        setFoodLevel(getFoodLevel() - 1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for octopuses adjacent to the current location.
     * Only the first live octopus is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Crab) {
                Crab crab = (Crab) animal;
                if(crab.isAlive()) { 
                    crab.setDead();
                    setFoodLevel(CRAB_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this octopus is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOctopuses A list to return newly born octopuses.
     */
    private void giveBirth(List<Actor> newOctopuses)
    {
        // New octopuses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Octopus young = new Octopus(false, field, loc);
            newOctopuses.add(young);
        }
    }

    /**
     * A octopus can breed if it has reached the breeding age.
     * @return whether an octopus has reached the breeding age.
     */
    public boolean getCanBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Returns the maximum age of a octopus.
     * @return the maximum age of a octopus
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Returns the proabablity an octopus will breed.
     * @return the proabablity an octopus will breed
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the litter size of an octopus .
     * @return the litter size of an octopus
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Returns true if adjacent octopuses are of opposite gender.
     * @return true if adjacent octopuses are of opposite gender
     */
    private boolean oppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Octopus) {
                Octopus octopus = (Octopus) animal;
                if(!octopus.isFemale()) { 
                    return true;
                }
            }
        }
        return false;
    }
}
