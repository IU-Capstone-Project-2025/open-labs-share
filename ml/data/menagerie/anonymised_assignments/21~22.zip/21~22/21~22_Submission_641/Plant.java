import java.util.Random;
import java.util.List;
/**
 * A class representing shared characteristics of all plants.
 *
 * @version 28/02/2022
 */
public abstract class Plant extends Actor
{
    // Random number generator.
    private Random rand = new Random();

    /**
     * Create a plant in a location in field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newPlants);
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(getCanBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getOffspringSize()) + 1;
        }
        return births;
    }
    
    /**
     * return the breeding probability of an plant
     * @return the breeding probability of an plant
     */
    protected abstract double getBreedingProbability();
    
    /**
     * return the maximum number of offsprings a plant can have at one time
     * @return the maximum number of offsprings of a plant
     */
    protected abstract int getOffspringSize();
    
    /**
     * return whether the plant can breed or not
     * @return true if plant can breed
     */
    protected abstract boolean getCanBreed();
    
    /**
     * gets a random number for all subclasses
     * @return a random number 
     */
    protected Random getRandom()
    {
        return rand;
    }
}
