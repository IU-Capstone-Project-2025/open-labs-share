import java.util.List;
import java.util.Iterator;
import java.util.Random;
/**
 * A simple model of a shark.
 * Shark age, move, eat tuna, give birth  and die.
 *
 * @version 28/02/2022
 */
public class Shark extends Animal
{
    // Characteristics shared by all sharks (class variables).
    // The age at which a shark can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a shark can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a shark breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births by a shark
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single tuna. In effect, this is the
    // number of steps a shark can go before it has to eat again.
    private static final int TUNA_FOOD_VALUE = 50; 
    
    /**
     * Create a shark. A shark can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the shark will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shark(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            setFoodLevel(getRandom().nextInt(TUNA_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(TUNA_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the shark does most of the time: it hunts for
     * sharks. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newSharks A list to return newly born sharks.
     */
    public void act(List<Actor> newSharks)
    {
        if (hasInfection) {
            effectOfInfection();
        }
        incrementAge();
        incrementHunger();
        if(isAlive() && Time.dayTime()) {
            if(isFemale() && oppositeGender()){
                giveBirth(newSharks); 
            } 
                       
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this shark more hungry. This could result in the shark's death.
     */
    private void incrementHunger()
    {
        setFoodLevel(getFoodLevel() - 1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for tunas adjacent to the current location.
     * Only the first live tuna is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Tuna) {
                Tuna tuna = (Tuna) animal;
                if(tuna.isAlive()) { 
                    tuna.setDead();
                    setFoodLevel(TUNA_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this shark is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newSharks A list to return newly born sharks.
     */
    private void giveBirth(List<Actor> newSharks)
    {
        // New sharks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Shark young = new Shark(false, field, loc);
            newSharks.add(young);
        }
    }

    /**
     * A shark can breed if it has reached the breeding age.
     * @return whether a shark has reached the breeding age.
     */
    public boolean getCanBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Returns the maximum age of a shark.
     * @return the maximum age of a shark
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Return the proabablity an shark will breed.
     * @return the proabablity an shark will breed
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the litter size of a shark.
     * @return the litter size of a shark
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Returns true if adjacent sharks are of opposite gender.
     * @return true if adjacent sharks are of opposite gender
     */
    private boolean oppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Shark) {
                Shark shark = (Shark) animal;
                if(!shark.isFemale()) { 
                    return true;
                }
            }
        }
        return false;
    }
}