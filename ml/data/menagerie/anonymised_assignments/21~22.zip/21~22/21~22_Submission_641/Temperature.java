import java.util.Random;
/**
 * Determines what temperature is experienced by all the actors in the simulation
 *
 * @version 28/02/2022
 */
public class Temperature
{
    // Temperature in C.
    private static int temperature;
    // Random number generator.
    private static Random rand = Randomizer.getRandom();
    // Stores weather type.
    private static String weather;

    /**
     * Constructor for objects of class Temperature.
     */
    public Temperature()
    {
        setTemperature();
    }

    /**
     * Set the temperature which is determined by the random number generator.
     * The temperature depends on the weather at that time.
     */
    private static void setTemperature()
    {
        weather = Weather.getWeather();
        if (weather.equals("Sunny")){
            temperature = rand.nextInt(5) + 30;
        }
        else if (weather.equals("Cloudy")){
            temperature = rand.nextInt(5) + 22;
        }
        else if (weather.equals("Windy")){
            temperature = rand.nextInt(5) + 10;
        }
        else if (weather.equals("Hurricane")){
            temperature = rand.nextInt(5) - 10;
        }
    }

    /**
     * Gets the correct temperature.
     * @return the current temperature
     */
    public static int getTemperature()
    {
        setTemperature();
        return temperature;
    }
}
