import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A class representing shared characteristics of all animals.
 *
 * @version 28/02/2022
 */
public abstract class Animal extends Actor
{
    // The animal's food level, which is increased by eating its prey.
    private int foodLevel;
    // The animal's gender.
    private boolean gender;
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    // True if animal has the infection.
    protected static boolean hasInfection;
    // Creates a disease object.
    protected Disease disease;
    // Probability of animals infecting others.
    private double SPREAD_PROBABILITY = 0.99;
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field,location);
        gender = rand.nextBoolean();
        hasInfection = false;
        disease = new Disease();
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newAnimals);
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(getCanBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Return the breeding probability of an animal.
     * @return the breeding probability of an animal
     */
    protected abstract double getBreedingProbability();
    
    /**
     * Returns the maximum number of kids an animal can have at one time.
     * @return the maximum litter of an animal
     */
    protected abstract int getMaxLitterSize();
    
    /**
     * Return whether the animal can breed or not.
     * @return true if animal can breed
     */
    protected abstract boolean getCanBreed();
    
    /**
     * Returns animal's current food level.
     * @return animal's current food level 
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * Set an animals current foodLevel.
     * @param foodlevel the animals current foodLevel
     */
    protected void setFoodLevel (int foodLevel)
    {
        this.foodLevel = foodLevel;
    }
    
    /**
     * Shows whether a selected animal is female or not.
     * @return true if animal is female
     */
    protected boolean isFemale()
    {
        return gender;
    }
    
    /**
     * Get a random number for all subclasses.
     * @return a random number 
     */
    protected Random getRandom()
    {
        return rand;
    }
    
    /**
     * Gives infection to the animal.
     */
    public void getInfection()
    {
       hasInfection = true;
       disease.setInfectionStart();
    }
    
    /**
     * Removes infection from animal.
     */
    public static void healInfection()
    {
        hasInfection = false;
    }

    /**
     * How an animal responds to the disease: heal, die and/or transmit the disease.
     */
    protected void effectOfInfection()
    {
        int step = Disease.getCurrentStep();
        int infectionStart = disease.getInfectionStart();
        int diseaseActs = disease.getHealOrDie() + infectionStart;
        
        if (step == diseaseActs){
            healInfection();
        }      
        else if (step == infectionStart + Disease.getInfectionRate()){
            transferDisease();
        }
        else if (step >= infectionStart + Disease.getDeathSteps()){
            setDead();
        }
    }
    
    /**
     * Transfers a disease from one animal to another.
     */
    protected void transferDisease()
    {
        if(getLocation() != null){
            Field field = getField(); 
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            Random rand = Randomizer.getRandom();
            
            while(it.hasNext()){
                Location where = it.next();
                Object actor = field.getObjectAt(where);
                if (actor instanceof Animal){
                    Animal animal = (Animal) actor;
                    if(isAlive() && rand.nextDouble() <= SPREAD_PROBABILITY && !hasInfection){
                        getInfection();
                    }
                }
            }
        }
    }
}