import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a crab.
 * Crab age, move, eat , and die.
 *
 * @version 28/02/2022
 */
public class Crab extends Animal
{
    // Characteristics shared by all crab (class variables).    
    // The age at which a crab can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a crab can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a crab breeding.
    private static final double BREEDING_PROBABILITY = 0.4;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single seaweed. In effect, this is the
    // number of steps a crab can go before it has to eat again.
    private static final int SEAWEED_FOOD_VALUE = 80;
    
    /**
     * Create a crab. A crab can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the crab will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Crab(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            setFoodLevel(getRandom().nextInt(SEAWEED_FOOD_VALUE));
        }
        else {
            setAge(0);
            setFoodLevel(SEAWEED_FOOD_VALUE);
        }
    }
    
    /**
     * This is what the crab does most of the time: it hunts for
     * seaweed. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newCrabs A list to return newly born crabs.
     */
    public void act(List<Actor> newCrabs)
    {
        if (hasInfection) {
            effectOfInfection();
        }
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            
            if(isFemale() && oppositeGender()){
                giveBirth(newCrabs);
            }          
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Make this crab more hungry. This could result in the crab's death.
     */
    private void incrementHunger()
    {
        setFoodLevel(getFoodLevel() - 1);
        if(getFoodLevel() <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for seaweed adjacent to the current location.
     * Only the first live seaweed is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Seaweed) {
                Seaweed seaweed = (Seaweed) animal;
                if(seaweed.isAlive()) { 
                    seaweed.setDead();
                    setFoodLevel(SEAWEED_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Returns true if adjacent crabs are of opposite gender.
     * @return true if adjacent crabs are of opposite gender
     */
    private boolean oppositeGender()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Crab) {
                Crab crab = (Crab) animal;
                if(!crab.isFemale()) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check whether or not this crab is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCrabs A list to return newly born crabs.
     */
    private void giveBirth(List<Actor> newCrabs)
    {
        // New crabs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Crab young = new Crab(false, field, loc);
            newCrabs.add(young);
        }
    }

    /**
     * A crab can breed if it has reached the breeding age.
     * @return whether the can has reached the breeding age.
     */
    public boolean getCanBreed()
    {
        return getAge() >= BREEDING_AGE;
    }
    
    /**
     * Returns the maximum age of a crab.
     * @return the maximum age of a crab
     */
    public int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * Returns the proabablity a crab will breed.
     * @return the proabablity a crab will breed
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Returns the litter size of an crab. 
     * @return the litter size of an crab
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
}
