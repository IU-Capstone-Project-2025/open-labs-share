import java.util.Random;
/**
 * Keep track of how many hours and days have passed.
 * The reset method used to reset time.
 *
 * @version 28/02/2022
 */
public class Time
{
    // Hours that have passed.
    private static int hours;
    // Whether it is day or not.
    private static boolean isDay;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        // Initialise instance variables.
        hours = 0;
        isDay = false;
    }

    /**
     * Returns whether it is day or not.
     * @return a boolean of whether it is day or not
     */
    public static boolean isDay()
    {
        return isDay;
    }
    
    /**
     * Returns hours passed in a day.
     * @return number of hours passed of a day
     */
    public static int getHours()
    {
        return hours;
    }
    
    /**
     * Increment the hours.
     */
    public void incrementHours()
    {
            hours++;
            hours = hours % 24;
            dayTime();
    }
    
    /**
     * Sets what times of day or considered to be day time and which are night.
     * @return a boolean of whether it is day or not
     */
    public static boolean dayTime()
    {
        if (hours >= 7 && hours <=19) {
            isDay = true;
            return isDay;
        }
        else {
            isDay = false;
            return isDay;
        }
    }
    
    /**
     * Resets the hours to 0.
     */
    public void setZero()
    {
        hours = 0;
    }
}
