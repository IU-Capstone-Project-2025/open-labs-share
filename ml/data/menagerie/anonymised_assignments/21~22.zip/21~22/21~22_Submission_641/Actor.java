import java.util.List;
import java.util.Random;
/**
 * An abstract superclass that shows all common methods of animals and plants.
 *
 * @version 28/02/2022
 */
public abstract class Actor
{
    // The actor's age.
    private int age;
    // Whether the actor is alive or not.
    private boolean alive;
    // The actor's field.
    private Field field;
    // The actor's position in the field.
    private Location location;

    /**
     * Create a new actor at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Actor(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Makes the actors do what they are supposed to do. 
     * @param newActors A list of newly born actors
     */
    abstract public void act(List<Actor> newActors);

    /**
     * Check whether the actor is alive or not.
     * @return true if actor is alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the actor is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the actor at the new location in the given field.
     * @param newLocation The actor's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the actor's location.
     * @return The actor's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Return the actor's field.
     * @return The actor's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Increase the age. This could result in the actors's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Returns the maximum age of an actor.
     * @return the maximum age of an actor
     */
    protected abstract int getMaxAge();

    /**
     * Returns an actors current age.
     * @return current age of actor
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Set an actor's current age.
     * @param age int set the current age
     */
    protected void setAge(int age)
    {
        this.age = age;
    }
}
