import java.util.Random;
import java.util.List;
import java.util.Iterator;
/**
 * A class that is able to introduce a disease into the simulation, start and end an epidemic.
 *
 * @version 28/02/2022
 */
public class Disease
{ 
    // Picks a random number.
    private static Random rand = Randomizer.getRandom();
    // Keeps track of steps where the infection started.
    private int infectionStart;
    // Number of steps the infection will last before it kills the animal.
    private static final int STEPS_TILL_DEATH = 2;
    // Number of steps until a new disease can start again, generated randomly.
    private static final int STEPS_TILL_DISEASE = 10;
    // Number of steps before a disease can start again.
    private static int stepsTillDisease;
    // Steps taken before the animal is healed from the disease.
    private int healProbability;
    // Current step number.
    private static int currentStep;
    // List of all the actors.
    private static List<Actor> allActors;
    // Track the step where the most recent disease started.
    private static int diseaseStart = 0;
    // Track the step where the most recent disease ended.
    private static int diseaseEnd = 0;
    // The number of steps it takes for an animal to infect another.
    private static int infectionRate;

    /**
     * Constructor for objects of class Disease
     */
    public Disease()
    {
        setHealOrDie();
        setStepsTillDisease();
    }

    /**
     * Randomly selects a number that determines whether the infected animal heals or dies.
     */
    private void setHealOrDie()
    {
        healProbability = rand.nextInt(STEPS_TILL_DEATH * 2);
        // There is half a chance that the animal dies.
    }

    /**
     * Randomly selects a number that determines how long before an animal infects others.
     */
    private void setInfectionRate()
    {
        infectionRate = rand.nextInt(getHealOrDie());
    }

    /**
     * Returns the number of steps before an animal can infect another.
     * @return number of steps before an animal can infect another
     */
    public static int getInfectionRate()
    {
        return infectionRate;
    }

    /**
     * Returns the number that decides whether an animal heals or not.
     * @return the number that decides whether an animal heals or not
     */
    public int getHealOrDie()
    {
        return healProbability;
    }

    /**
     * Returns how many steps an infected animal has to go through before dying.
     * @return steps an infected animal has to go through before dying
     */
    public static int getDeathSteps()
    {
        return STEPS_TILL_DEATH;
    }

    /**
     * Randomly selects a number that determines how long to wait before disease starts up again.
     */
    private void setStepsTillDisease()
    {
        stepsTillDisease = rand.nextInt(STEPS_TILL_DISEASE);
    }

    /**
     * Decides whether or not a disease epidemic should start.
     *
     * @param  step the current step
     * @param actors a list of all actors
     */
    public static void act (int step, List<Actor> actors)
    {
        currentStep = step;
        allActors = actors;

        if (currentStep == diseaseEnd + stepsTillDisease){
            startDisease();
            diseaseStart = currentStep;
        }   
    }

    /**
     * Decides which animal should start the epidemic.
     */
    public static void startDisease()
    {
        int size = allActors.size();
        Actor actor;

        for (int i=0; i< size; i++){
            //picking a random number of actors
            int index = rand.nextInt(size);
            actor = allActors.get(index);
            if (actor instanceof Animal){
                Animal animal = (Animal) actor;
                animal.getInfection();
            }
        }
    }

    /**
     * Gets the current step of the simulation.
     * @return the current step of the simulation
     */
    public static int getCurrentStep()
    {
        return currentStep;
    }

    /**
     * Store the step at which infection started.
     */
    public void setInfectionStart()
    {
        infectionStart = currentStep;
    }

    /**
     * Returns the step as which infection in an animal started.
     * @return step at which infection in animal starts
     */
    public int getInfectionStart()
    {
        return infectionStart;
    }
}
