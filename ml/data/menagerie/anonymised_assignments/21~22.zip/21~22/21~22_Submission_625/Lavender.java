import java.awt.*;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a grass
 * grass can breed and die.
 *
 * @version 2022.03.01
 */
public class Lavender extends Plant {

    // Characteristics shared by all lavender (class variables).
	//The age which a lavender can start to breed 
    private static final int BREEDING_AGE = 11;
    // The age the lavender could last for
    private static final int MAX_AGE = 500; 
    // The possibility of successful breeding 
    private static final double BREEDING_PROBABILITY = 0.55;
    // The maximum number the lavender can breed in its lifetime
    private static final int MAX_BREEDING_OUTCOME = 5;
    // The nutrition value that the predotor will gain form grass
    private static final int FOOD_VALUE = 25;
    
    private static final Random rand = Randomizer.getRandom();
    private Color color = new Color(183, 104, 229);
    
    // Individual characteristics (instance fields).	
    // The lavender' age 
    private int age;
    // The grass hydration level
    private int hydration_level = 50;
    
    /**
     *  Create a lavender. A lavender can be created as new plant (age zero) or
     *  with a random age 
     * 
     * @param randomAge If true, the lavender will have random age .
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lavender(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }

    }

    /**
     * This method is responsible for the plant age, breeding and hydration level.
     * In the process, it might die of dehydration, die of old age or breed
     * @param newPlants A list to receive new lavender
     * @param weather A sting that specifies the weather in the simulator
     */
    public void reproduce(List<Plant> newPlants, String weather) {
    	incrementAge();
        applyWeatherEffect(weather);
        if(isAlive() && hydration_level > 5 && canBreed()) {
            propagate(newPlants);
        }
    }

    /**
     * Randomly change the hydration level of the lavender depending on the weather 
     * @param weather A string that indicates the weather in the simulator 
     */
    protected void applyWeatherEffect(String weather )
    {
    	if(weather.equals("Rainy day")) {
            increment_hydration(10);
        }
        else if(weather.equals("Foggy day")) {
            increment_hydration(5);
        }
        else if(weather.equals("Snowy day")) {
            decrement_hydration(1);
        }
        else if(weather.equals("Windy day")) {
            increment_hydration(1);
        }
        else {
            decrement_hydration(2);
        }

    }


    /**
     * Check whether or not this grass is about to breed in this step 
     * New lavender will be made into free adjacent locations
     * @param newLavender	A list to return newly created grass
     */
    private void propagate(List<Plant> newLavender) {

    	Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lavender young = new Lavender(false, field, loc);
            newLavender.add(young);
        }

    }
    
    /**
     * Return the number of lavender have been created 
     * @return The number of Breeds (may be zero)
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_BREEDING_OUTCOME) + 1;
        }
        return births;
    }
    
    /**
     * A lavender can breed if it has reached the breeding age.
     * @return true if the lavender can breed, false otherwise.
     */
    private boolean canBreed() {
    	
    	int counter = 0;
        Field field = getField();
        List<Location> adjacent = field.furtherAdjacentLocations(getLocation(), 7);
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Creature creature = (Creature) field.getObjectAt(where);
            if (creature instanceof Lavender) {
                counter++;
            }
        }

        return age >= BREEDING_AGE && counter < 25;
    }

    /**
     * This method decreases the hydration of the lavender by a certain amount.
     * It could results the death of the lavender.
     * @param n The amount the lavender will be dehydrated  
     */
    protected void decrement_hydration(int n)
    {
        hydration_level -= n;
        if (hydration_level <= 0) {
            setDead();
        }
    }

    /**
     * This method increases the hydration level of the lavender by a certain amount
     * @param n The amount the lavender will be hydrated 
     */
    protected void increment_hydration(int n)
    {
        hydration_level += n;
    }

    /**
     * increases the age of the lavender.
     * This could results the death of the lavender
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * return the color of the lavender
     * @return An color object that holds the color of the lavender
     */
    public Color getColor()
    {
        return color;
    }
    
    /**
     * return the Food value of the lavender 
     * @return A int value that hold the food value
     */
    @Override
    public int getFoodValue() {
        return FOOD_VALUE;
    }
}
