import java.util.ArrayList;

/**
 * A class that is resposisable for number of days, season, weather condition
 * and whether is it day or night in the simulator.
 *
 * @version 2022.03.01
 */
public class Time {
	
	// The steps in the simulator 
    private static int steps;
    // The current season in the simulator 
    private static Weather currentSeason;
    // Count the number of days that passed
    private static int numDays;
    // Stores all the weather condition for each season in the year
    private static ArrayList<Weather> seasons;
    // The current weather condition in the simulation
    private static String currentWeather;

    /**
     * Create new seasons and weather condition once the simulator runs
     * @param initialStep The number of steps the simulator start with
     */
    public Time(int initialStep) {
        seasons = new ArrayList<>();
        createSeasons();
        currentSeason = seasons.get(0); //default season
        currentSeason.chooseWeather();
        currentWeather = currentSeason.getWeather();
        steps = initialStep;
        numDays = steps/10;
    }

    /**
     * Create new seasons and weather condition once the simulator runs
     */
    public Time()
    {
    	//Default constructor 
    }
    
    /**
     * increase the number of steps 
     */
    public void incrementSteps() {
        steps++;
    }

    /**
     * Return the number of steps stored 		
     * @return An int value that represent the number of steps taken in the simulator 
     */
    public int getSteps() {
        return steps;
    }

    /**
     * Return the weather condition that is currently in the simulator 
     * @return A string that represent the current weather condition 
     */
    public String getCurrentWeather() {
        return currentWeather;
    }

    /** 
     * Updates the weather condition only if a day have passed in the simulator
     */
    private void updateWeatherCondition() {
        if (steps % 10 == 0) {
            currentSeason.chooseWeather();
            currentWeather = currentSeason.getWeather();
        }
    }
	    
	/** 
	 * Return the number of days passed
	 * @return An int value that represent the number of days passed
	 */
    public int getNumberOfDays() {
        return numDays;
    }

    /**
     * Set the number of steps by a certain value 
     * @param num	the number of steps
     */
    public void setSteps(int num) {
        steps = num;
    }
    
    /** 
     * Return the current season in the simulator 
     * @return A weather object that holds information about weather
     */
    public Weather getSeason() {
        return currentSeason;
    }

    /**
     * Creates the seasons that will take place in the simulator and store it 
     */
    private void createSeasons()
    {
        Weather spring = new Weather("Spring", 0.24, 0.25, 0.30, 0.53 );
        Weather summer = new Weather("Summer", 0.10, 0.11, 0.14, 0.50);
        Weather fall = new Weather("Fall", 0.50, 0.53, 0.56, 0.89);
        Weather winter = new Weather("Winter", 0.30, 0.50, 0.55, 0.85);
        seasons.add(spring);
        seasons.add(summer);
        seasons.add(fall);
        seasons.add(winter);
    }

    /**
     * updates the current season 
     * @param season A Weather object that represent the season 
     */
    public void setSeason(Weather season) {
        currentSeason = season;
    }

    /**
     * return Day if the simulator in currently on day time. Night otherwise
     * @return A string 
     */
    public String getDayTime() {
        if (isDay()) {
            return "Day";
        }
        else {
            return "Night";
        }

    }

    /**
     * Determine if the simulator is currently at day time or night time
     * @return boolean value that determine day time and night time 
     */
    public boolean isDay() {
        if (steps % 10 < 5)
            return true;
        else
            return false;
    }

    /** 
     * Update the number of days based on steps
     */
    private void updateDays() {
        numDays = steps / 10;
    }

    /**
     * Update the current season based on number of days passed
     */
    private void updateSeason() {
        setSeason(seasons.get((numDays / 10) % 4));
    }

    /**
     * Updates the day value, season and weather condition 
     */
    public void update() {
        updateDays();
        updateSeason();
        updateWeatherCondition();
    }

}
