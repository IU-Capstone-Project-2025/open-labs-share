import javax.swing.*;
import java.awt.*;

/**
 * A graphical view of the simulation grid.
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 2022.03.01
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private static final Color EMPTY_COLOR = Color.white;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private final String DAYTIME_PREFIX = "Day time: ";
    private final String SEASON_PREFIX = "Current Season: ";
    private final String DAYS_PREFIX = "Days passed: ";
    private final String WEATHER_PREFIX = "Current weather: ";
    private JLabel weatherLabel, stepLabel, population, timeLabel, seasonLabel, daysLabel, photoLabel;
    private FieldView fieldView;


    // A statistics object computing and storing simulation information
    private FieldStats stats;

    private Time time = new Time(0);
    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width)
    {
        stats = new FieldStats();

        setTitle("Animals life Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        timeLabel = new JLabel(DAYTIME_PREFIX, JLabel.CENTER);
        seasonLabel = new JLabel(SEASON_PREFIX, JLabel.CENTER);
        daysLabel = new JLabel(DAYS_PREFIX, JLabel.CENTER);
        weatherLabel = new JLabel(WEATHER_PREFIX, JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        setLocation(100, 50);

        fieldView = new FieldView(height, width);

        //photo addition secion ---------------------
        String url = "foodWeb-01.jpg";
        ImageIcon icon = new ImageIcon(url);
        photoLabel = new JLabel();
        photoLabel.setIcon(icon);
        //-------------------------------------------

        Container contents = getContentPane();

        JPanel infoPane = new JPanel(new BorderLayout());
	        infoPane.add(stepLabel, BorderLayout.NORTH);
	        infoPane.add(timeLabel, BorderLayout.WEST);
	        infoPane.add(seasonLabel, BorderLayout.CENTER);
	        infoPane.add(daysLabel, BorderLayout.EAST);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);

        JPanel photoPane = new JPanel(new BorderLayout());
	        photoPane.add(photoLabel, BorderLayout.CENTER);
	        photoPane.add(weatherLabel, BorderLayout.NORTH);
        contents.add(photoPane, BorderLayout.WEST);
        pack();
        setVisible(true);
    }


    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        timeLabel.setText(text);
    }

    /**
     * Show the current status of the field.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(Field field)
    {
        if(!isVisible()) {
            setVisible(true);
        }
        stepLabel.setText(STEP_PREFIX + time.getSteps());
        timeLabel.setText(DAYTIME_PREFIX + time.getDayTime());
        daysLabel.setText(DAYS_PREFIX + time.getNumberOfDays());
        seasonLabel.setText(SEASON_PREFIX + (time.getSeason()).getSeasonName() );
        weatherLabel.setText(WEATHER_PREFIX + time.getCurrentWeather());

        stats.reset();


        fieldView.preparePaint();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Object creature = field.getObjectAt(row, col);
                if(creature instanceof Animal) {
                    Animal animal = (Animal) creature;
                    fieldView.drawMark(col, row, animal.getColor());
                }
                else if(creature instanceof Plant){
                    Plant plant = (Plant) creature;
                    fieldView.drawMark(col, row, plant.getColor());
                }
                else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
                if (creature!= null)
                    stats.incrementCount(creature.getClass());
            }
        }

        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }

    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                    gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}