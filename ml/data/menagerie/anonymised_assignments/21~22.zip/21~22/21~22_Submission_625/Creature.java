import java.awt.*;

/**
 * A class representing all shared characteristics of creature.
 *
 * @version 2022.03.01
 */
public abstract class Creature {

    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;

    /**
     * Create new creature at a location in field in the simulator 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Creature(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Return a color object that hold the creature color in the simulator 
     * @return A color object that holds creature's color
     */
    abstract public Color getColor();

    /**
     * Return the nutrition value of the creature 
     * @return A int value that hold the creature's value as a food. 
     */
    abstract public int getFoodValue();
    
    /**
     * Check whether the creature is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the creature is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the creature's location.
     * @return The creature's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the creature at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the creature's field.
     * @return The creature's field.
     */
    protected Field getField()
    {
        return field;
    }

}


