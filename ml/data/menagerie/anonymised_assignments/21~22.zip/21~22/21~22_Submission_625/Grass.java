import java.awt.*;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a grass
 * grass can breed and die.
 *
 * @version 2022.03.01
 *
 */
public class Grass extends Plant {

    // Characteristics shared by all grass (class variables).
	//The age which a grass can start to breed 
    private static final int BREEDING_AGE = 3;
    // The age to which a grass can live
    private static final int MAX_AGE = 500; 
    // The possibility of successful breeding 
    private static final double BREEDING_PROBABILITY = 0.55;
    // The maximum number the grass can breed in its lifetime
    private static final int MAX_BREEDING_OUTCOME = 5;
    // The nutrition value that the predotor will gain form grass
    private static final int FOOD_VALUE = 15;

    // The grass color 
    private Color color = new Color(76, 235, 52);

    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).	
    // The grass' age 
    private int age;
    // The grass hydration level
    private int hydration_level = 50;

    /**
     * Create a grass. A grass  can be created as new plant (age zero) or
     * with a random age 
     * 
     * @param randomAge If true, the grass will have random age .
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }

    }

    /**
     * This method is responsible for the plant age, breeding and hydration level.
     * In the process, it might die of dehydration, die of old age or breed 
     * @param newPlants A list to receive new lavender
     * @param weather A sting that specifies the weather in the simulator
     */
    @Override
    public void reproduce(List<Plant> newPlants, String weather) {
        incrementAge();
        applyWeatherEffect(weather);
        if(isAlive() && hydration_level > 5 && canBreed()) {

            propagate(newPlants);
        }
    }

    /**
     * Randomly change the hydration level of the grass depending on the weather 
     * @param weather A string that indicates the weather in the simulator 
     * 
     */
    protected void applyWeatherEffect(String weather )
    {
    	if(weather.equals("Rainy day")) {
            increment_hydration(10);
        }
        else if(weather.equals("Foggy day")) {
            increment_hydration(5);
        }
        else if(weather.equals("Snowy day") ) {
            decrement_hydration(1);
        }
        else if(weather.equals("Windy day")) {
            increment_hydration(1);
        }
        else {
            decrement_hydration(2);
        }

    }

    /**
     * Check whether or not this grass is about to breed in this step 
     * New lavender will be made into free adjacent locations
     * @param newGrass	A list to return newly created grass
     * 
     */
    private void propagate(List<Plant> newGrass) {

    	Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }

    }

    /**
     * Return the number of grass have been created 
     * @return The number of Breeds (may be zero)
     */
    private int breed()
    {
        int reproduced = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            reproduced = rand.nextInt(MAX_BREEDING_OUTCOME) + 1;
        }
        return reproduced;
    }
    
    /**
     * This method decreases the hydration of the grass by a certain amount.
     * It could results the death of the grass
     * @param n The amount the grass will be dehydrated  
     */
    protected void decrement_hydration(int n)
    {
        hydration_level -= n;
        if (hydration_level <= 0) {
            setDead();
        }
    }

    /**
     * This method increases the hydration level of the grass by a certain amount
     * @param n The amount the grass will be hydrated 
     */
    protected void increment_hydration(int n)
    {
        hydration_level += n;
    }

    /**
     * A grass can breed if it has reached the breeding age and have space to breed.
     * @return true if the grass can breed, false otherwise.
     */
    private boolean canBreed() {
    	
    	int counter = 0;
        Field field = getField();
        List<Location> adjacent = field.furtherAdjacentLocations(getLocation(), 5);
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Creature creature = (Creature) field.getObjectAt(where);
            if (creature instanceof Grass) {
                counter++;
            }
        }

        return age >= BREEDING_AGE && counter < 10;
    }
    
    /**
     * increases the age of the grass.
     * This could results the death of the grass
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * return the color of the grass
     * @return An color object that holds the color of the grass
     */
    public Color getColor()
    {
        return color;
    }

    /**
     * return the Food value of the grass 
     * @return A int value that hold the food value
     */
    @Override
    public int getFoodValue() {
        return FOOD_VALUE;
    }
}