import java.util.List;
import java.util.Iterator;
import java.util.Random;

public abstract class Prey extends Animal
{
    // value of plant when prey eat it
    public static final int Plant_FOOD_VALUE = 30;
    
    /**
     * contructor of prey class
     */
    public Prey(Field field, Location location)
    {
        // initialise instance variables
        super(field,location);
        ismale = revealGender();
        
        weather=weather.nothing;
    }

    abstract public void act(List<Animal> newAnimals);
    
    /**
     * method for preys to find and eat plants 
     * also when plants eaten it decreases 
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant.isAlive()) { 
                    
                    foodLevel = 45;
                    plant.plantEaten();
                    return where;
                }
            }
        }
        return null;
    }



    /**
     * Make this prey more hungry. This could result in the prey's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

   


}
