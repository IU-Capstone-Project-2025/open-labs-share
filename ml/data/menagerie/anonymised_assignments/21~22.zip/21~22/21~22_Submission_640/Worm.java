
import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a squirrel.
 * Rabbits age, move, breed,eat and die.
 *
 * @version 2016.02.29 (2)
 */
public class Worm extends Prey
{
    // Characteristics shared by all worm (class variables).

    // The age at which a worm can start to breed.
    private static final int BREEDING_AGE = 2;
    // The age to which a worm can live.
    private static final int MAX_AGE = 30;
    // The likelihood of a worm breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The worm's age.
    private int age;
    
  

    /**
     * Create a new worm. A squirrel may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the squirrel will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Worm(boolean randomAge, Field field, Location location)
    { 
        
        super(field, location);
        ismale = revealGender();
        isDay= false;
        weather=weather.nothing;
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(Plant_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = Plant_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the worm does most of the time - it runs 
     * around. Sometimes it will finds a mate or sleep or both or die of old age.
     * @param newWorm A list to return newly born worm.
     */
    public void act(List<Animal> newWorms)
    {        incrementAge();
        incrementHunger();
        if(isAlive()) {if(isDay==true){
            giveBirth(newWorms);            
            // eats the plants .
            findFood();
            //finds a place to move to 
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            
            //sets new location to free location
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
        else{
            //if night it only reproduces and does not move 
           giveBirth(newWorms); 
        }
    }
        
    }
    
    
    
    
    
    /**
     * Increase the age.
     * This could result in the worms's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this worm is to give birth at this step if it has found a mate.
     * New births will be made into free adjacent locations.
     * @param newsworms A list to return newly born squirrel.
     */
    private void giveBirth(List<Animal> newWorms)
    {
        // New worms are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            
            Worm young = new Worm(false, field, loc);
            newWorms.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && foundMate()) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A warm can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * This looks at the surrounding area of the warm to see if there is a 
     * potential warm to mate with which must be of the differnt gender and 
     * that can breed , if found it would return true 
     */
    protected boolean foundMate()
    {
        boolean foundMate=false;
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
         if(animal instanceof Worm) {
                Worm worm = (Worm) animal;
            if(worm.isAlive()&& ismale!=worm.getGender()&&worm.canBreed()) { 
                    
                    foundMate=true; ;
                }
            
           else{
                    foundMate= false;
                }
            
            
              
            }
        }
        return foundMate;
    }
    



}