import java.util.List;
import java.util.Random;

/**
 * Plants get eaten,grow with rain,and die if they do not get enough rain 
 *
 * 
 */
 public class Plant extends Animal
{
    
    
    
  
    // The age at which a plant can start to breed.
    private static final int Growing_AGE = 40;
     // The maximum number of places it can grow.
    private static final int MAX_LITTER_SIZE = 2;
    //probability it grows
    private static final double Growing_PROBABILITY = 0.01;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    //value of water it holds
    public static final int Plant_Water_VALUE = 150;
    
    
    
    // The plants's age.
    private int age;
    //level of food it holds if eaten
    public int levelOfFood;
    //level of water it has inisde
    private int levelOfwater;   
    
  

    /**
     * Create a new plant.
     * 
     
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location)
    { 
       
        super(field, location);
        ismale = revealGender();
        weather=weather.nothing;
        isDay=false;
        
        if(randomAge) {
            age = 20;
            levelOfFood = 50;
            levelOfwater =rand.nextInt(Plant_Water_VALUE)+120;
        }
        else {
            age = 1;
            levelOfFood = 50;
            levelOfwater = 50;
        }
    }
    
    /**
     * This is what the plant does most of the time - is get eaten 
     *  Sometimes it will grow if rain or die of dehydration.
     * @param newplants A list to return newlygrown plants.
     */
    public void act(List<Animal> newPlants)
    {
        
        if(isAlive()) {
            levelOfFood++;
            age++;
            
            if(weather == weather.rain){
                 //if it is raining grow 
                 grow(newPlants);
                 //and increase water inisde 
                 levelOfwater=levelOfwater+3;
               
            
            }
            
            else{
                //transipiration and water is evaporated 
                reductionWater();
            }
                       
            
            
            
        }
    }

    //return current level of food inside
    public int getLevelOfFood(){
        
        return levelOfFood;
    }
    //when eaten by prey current food goes down
    public void plantEaten(){
        this.levelOfFood= levelOfFood-1;
        if(levelOfFood <= 0) {
            setDead();
        }
        
        
    }
    

    
    
    /**
     * Check whether or not this rabbit is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newplants A list to return newly born plants.
     */
    private void grow(List<Animal> newPlants)
    {
        // New rabbits are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            
            Plant young = new Plant(false, field, loc);
            newPlants.add(young);
        }
    }
        
    /**
     * Generate a number representing how big it can grow 
     * if it is old enough to grow
     * @return how much it can grow (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= Growing_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A plant can grow if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= Growing_AGE;
    }

     
    
    
    private void reductionWater(){
        levelOfwater=levelOfwater-1;
        if(levelOfwater <= 0) {
            setDead();
        }
        
    }
    
    
    
    

    

    


}
