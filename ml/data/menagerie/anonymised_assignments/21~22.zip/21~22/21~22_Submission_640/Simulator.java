import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 125;
    // The probability that a wolf will be created in any given grid position.
    private static final double Wolf_CREATION_PROBABILITY = 0.03;
    // The probability that a hare will be created in any given grid position.
    private static final double Hare_CREATION_PROBABILITY = 0.20;    
    // The probability that a hawk will be created in any given grid position.
    private static final double Hawk_CREATION_PROBABILITY = 0.03;
   // The probability that a plant will be created in any given grid position.
    private static final double Plant_CREATION_PROBABILITY = 0.22;
    // The probability that a squirrel will be created in any given grid position.
    private static final double Squirrel_CREATION_PROBABILITY = 0.20;
    // The probability that a worm will be created in any given grid position.
    private static final double Worm_CREATION_PROBABILITY = 0.20;
   
    private Random rand = Randomizer.getRandom();
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    //create the time for stimulation
    private ClockDisplay time;
    //create the weather for stimulation
    private GetWeather weathers;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    private Animal animal ;
  
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);
        step=0;
        time = new ClockDisplay();
        weathers = new GetWeather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Hare.class, Color.ORANGE);
        view.setColor(Wolf.class, Color.PINK);
        view.setColor(Hawk.class, Color.magenta);
        view.setColor(Squirrel.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);
        view.setColor(Worm.class, Color.BLACK);
        view.changeDefaultcolor(Color.white);
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {        
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
             delay(60);   // uncomment this to run more slowly
        }
     
    
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep()
    {
        step++;
        time.timeTick();
        time.updateDisplay();
        
        
        if(step % 30 == 0){
            weathers.changeWeather();
            view.changeDefaultcolor(changeWeather());
            
            
        }
        
       // Provide space for newborn animals.
        
        
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            
            Animal animal = it.next();
            
            if(time.getMinutevalue()>30){
                animal.isDay=false;
            }
            else{
              animal.isDay=true;  
            }
            animal.weather=weathers.weather;
            animal.act(newAnimals);
            
            if(! animal.isAlive()) {
                it.remove();
            }
        }
          
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        
        view.showStatus(step,time.getTime(),field,weathers.getWeather());
    
        
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        time = new ClockDisplay();
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step,time.getTime(), field,weathers.getWeather());
    }
    
    /**
     * Randomly populate the field with wolfs,hares,plants,hawks,worms,squirells.
     */
    private void populate()
    {
        
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= Wolf_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);

                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= Hare_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                   
                    Hare hare  = new Hare(true, field, location);
                    animals.add(hare);
                }
                // else leave the location empty.
            else if(rand.nextDouble() <= Hawk_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    
                    Hawk hawk = new Hawk(true, field, location);
                    animals.add(hawk);
                }
            else if(rand.nextDouble() <= Squirrel_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    
                    Squirrel squirrel = new Squirrel(true, field, location);
                    animals.add(squirrel);
                }
             
            else if(rand.nextDouble() <= Plant_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    
                    Plant plant = new Plant(true, field, location);
                    animals.add(plant);
                }
               
            else if(rand.nextDouble() <= Worm_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    
                    Worm worm = new Worm(true, field, location);
                    animals.add(worm);
                }
            
            
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    /**
     * @returns the color to the associated weather 
     * rain=blue
     * fog=gray
     */
    
    public Color changeWeather(){
        Color weathercolor = Color.white;
        if(getWeather() == weathers.weather.rain){
             weathercolor = Color.blue;
        }
                 
        if(getWeather() == weathers.weather.fog){
            weathercolor = Color.lightGray;
        }
        return weathercolor;
        
        
        
        
    }
     
     /**
     * @returns current weather
     */
     public Weather getWeather(){
         return weathers.weather();
     }
    
    
    
    
    
    
    }












