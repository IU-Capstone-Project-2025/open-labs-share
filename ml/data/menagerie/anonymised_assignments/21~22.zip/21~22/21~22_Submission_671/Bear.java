import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A simple model of a bear.
 * Beaars age, move, eat berries, foxes, rabbits, pigeons, and pigeons, they also die.
 *
 * @version 2022.03.02
 */
public class Bear extends Animal
{
    // The age at which a bear can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a bear breeding.
    private static final double BREEDING_PROBABILITY = 0.47;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // Number of steps a bear can take before it eats again. 
    // Value affected by presence of heat wave.
    private static int FOOD_VALUE = 16;
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a bear. A bear can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the bear will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Bear(boolean randomAge,Field field, Location location, int age) 
    { 
        super(field, location);
        setDefaultAge(age);
        setGender(); 
        setDisease();
        setMaxAge(MAX_AGE); 
        setFoodLevel(FOOD_VALUE); 
        
        if(randomAge) {
            setDefaultAge(rand.nextInt(MAX_AGE));
            setFoodLevel(rand.nextInt(FOOD_VALUE));
        } 
        else {
            setDefaultAge(0); 
            setFoodLevel(FOOD_VALUE);
        } 
    }
    
    /**
     * This is what the bear does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newBears A list to return newly born bear.
     */
    protected void act(List<Animal> newBears, int maxAge, boolean daytime) {
        if(environment.getSeason().equals("Winter")) {
            sleepingBehaviour(maxAge);
            setFoodLevel(FOOD_VALUE); // Bears sleep instead of hunt.
        }
        else {
            if(daytime) {
                commonBehaviour(newBears, maxAge);    
            }
            else {
                sleepingBehaviour(maxAge);
            }    
        }
    } 
    
    /**
     * Look for food adjacent to the current location.
     * Only the first food is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood() {
        if (environment.getWeather().equals("Heat Wave")) {
            FOOD_VALUE = 12;
        }
        else {
            FOOD_VALUE = 16;
        }
        
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        while(it.hasNext() && !environment.getWeather().equals("Fog")) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            Object plant = field.getObjectAt(where);
            
            if (animal instanceof Wolf) {
                Wolf wolf = (Wolf) animal; 
                if(wolf.isAlive()) {
                    wolf.setDead(); 
                    setFoodLevel(FOOD_VALUE);
                    
                    if(wolf.isPoisoned()) {
                        setPoison();
                    }
                    
                    return where;
                }
            } 
            else if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) {
                    squirrel.setDead(); 
                    setFoodLevel(FOOD_VALUE);
                    
                    if(squirrel.isPoisoned()) {
                        setPoison();
                    }
                    
                    return where;
                }
             } 
            else if(plant instanceof PoisonBerry) {
                PoisonBerry berry = (PoisonBerry) plant;
                if(berry.isAlive()) { 
                    berry.setDead(); 
                    setFoodLevel(FOOD_VALUE);
                    setPoison();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Look for mating partner adjacent to the current location.
     * Only the first mating partner will be mated with.
     */
    protected Location findMate(List<Animal> newBears) {
        Field field = getField(); 
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where); 
            if (animal instanceof Bear) {
                Bear bear = (Bear) animal; 
                boolean isFemale = bear.getGender(); 
                if(bear.isAlive() && isFemale && !isPoisoned()) {
                    giveBirth(newBears);
                    
                }
            }
        }
        return null;
    }  
    
    /**
     * Check whether or not this bear is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBears A list to return newly born bears.
     */
    protected void giveBirth(List<Animal> newBears)
    {
        // New bears are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(BREEDING_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, rand);
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bear young = new Bear(false, field, loc, 0);
            newBears.add(young);
        }
    } 
}
