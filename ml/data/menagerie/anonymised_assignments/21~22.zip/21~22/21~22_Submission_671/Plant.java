import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of all plants.
 *
 * @version 2022.03.02
 */
public abstract class Plant extends Species
{
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location); 
    } 
    
    /**
     * Common behaviour between plants.
     * @param newPlants A list to receive newly created plants, and their age limit.
     */
    protected void commonBehaviour(List<Plant> newPlants, int maxAge) {
        updateAge(maxAge);
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly born plants, their age limit, and time period.
     */
    abstract protected void act(List<Plant> newPlants, int maxAge, boolean dayTime); 
}