import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of all species within the simulator.
 * This mosdtly includes the aging mechanics and location setting.
 *
 * @version 2022.03.02
 */
public class Species
{
    Random rand = new Random();
    
    // Determines whether the organism is alive or not.
    private boolean alive;
    
    // The species' field.
    private Field field;
    // The species' position in the field.
    private Location location;
    
    // Holds the age of the species
    private int age;
    // Determines the max age of an organism
    private int maxAge;
    
    // Allows access to the methods in the Environment class.
    protected static Environment environment = new Environment();
    
    /**
     * Create a new species at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Species(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location); 
    } 
    
    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null && !alive) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Sets the organism's age to zero.
     */
    protected void setDefaultAge(int num) {
        age = num;
    }
    
    /**
     * Sets the age of a species.
     */
    protected void setMaxAge(int num) {
        maxAge = num;
    } 
    
    /**
     * @return the organism's age.
     */
    protected int getMaxAge() {
        return maxAge;
    }
    
    /**
     * Ages the organism. This could result in the organism's death.
     */
    protected void updateAge(int maxAge) {
        age++;
        if (age > maxAge) {
            setDead();
        }
    } 
    
    /**
     * @returns organism's age.
     */
    protected int getAge() {
        return age;
    } 
    
    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
}
