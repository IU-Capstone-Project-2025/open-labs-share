import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;

/**
 * This class is responsible for the continuously changing 
 * environment of the simulation, such as weather, seasons, and time of day.
 *
 * @version 2022.03.02
 */
public class Environment
{
    Random rand = new Random();
    
    // Tracks the current step count.
    private int currentStep; 
    // How long the day/ night lasts.
    private int lengthOfDaytime;
    // Checks if it is day time.
    private boolean isDay;
    // Time of day as a string.
    private String day;
    
    // List of all possible seasons.
    private static ArrayList<String> seasons;
    // Next season after the current one in the array list.
    private int nextSeason;
    // Current season
    private String currentSeason;
    // Keeps track of a season's length.
    private int lengthOfSeason;
    
    // List of all possible weather.
    private static ArrayList<String> weather;
    // Current weather
    private String currentWeather;
    // Length of current weather
    private int lengthOfWeather;
    
    // A graphical view of the simulation.
    private SimulatorView view;

    /**
     * Creates the potential environment of the simulation.
     */
    public Environment()
    {   
        resetEnvironment();
        
        // All Seasons
        seasons = new ArrayList<>();
            seasons.add("Spring ");
            seasons.add("Summer ");
            seasons.add("Autumn ");
            seasons.add("Winter ");
        nextSeason = rand.nextInt(4); // Randomly decides inital season.
        
        // All potential weather
        weather = new ArrayList<>();
            // Doesn't effect environment
            weather.add("Clear");
            weather.add("Sunny");
            weather.add("Cloudy");
            weather.add("Overcast");
            weather.add("Windy");
        
            // Effects environment
            weather.add("Rain");
            weather.add("Acid Rain");
            weather.add("Fog");
            weather.add("Heat Wave");
            weather.add("Thunderstorm");
    } 
    
    /**
     * Reset the environment of the simulation.
     */
    public void resetEnvironment() {
        lengthOfDaytime = 5;
        lengthOfSeason = 50;
        currentStep = 0; 
        isDay = true;
    }
    
    /**
     * Updates the step counter and checks the influence on the time of day.
     */
    public void incrementSteps() {
        currentStep++;
        getTimeOfDay();
    }
    
    /**
     * Checks whether the time period changes.
     * @return Whether it's day or not.
     */
    public boolean getTimeOfDay() {
        if (currentStep == lengthOfDaytime) {
            currentStep = 0;
            if(isDay) {
                isDay = false; // Time period changes from day to night.
            }
            else {
                isDay = true; // Time period changes from night to day.
            }  
        }
        return isDay;
    }
    
    /**
     * @return currentStep The step the simulation is currently on.
     */
    public int getCurrentStep() {
        return currentStep; 
    }
    
    /**
     * @return lengthOfDaytime Number of steps needed to change day status.
     */
    public int getLengthOfDaytime() {
        return lengthOfDaytime;
    }
    
    /**
     * Changes the simulation's season after a certain amount of steps.
     * @return currentSeason The simulation's current season.
     */
    public String getSeason() {
        if (currentStep % lengthOfSeason == 0) {
            currentSeason = seasons.get(nextSeason);
            nextSeason++;
            if (nextSeason == seasons.size()) {
                nextSeason = 0; // Ensures season loops back on itself (Winter -> Spring).
            }
        }
        return currentSeason;
    }
    
    /**
     * Changes the simulation's weather after a random amount of steps.
     * @return currentWeather The simulation's current weather.
     */
    public String getWeather() {
        if (lengthOfWeather == 0) {
            // Randomly choose weather and the weather's length.
            lengthOfWeather = rand.nextInt(10) + 1;
            int weatherIndex = rand.nextInt(weather.size());
            currentWeather = weather.get(weatherIndex);    
        }
        lengthOfWeather--; // Once the weather's length is 0, choose new weather type.
        return currentWeather;
    }
}
