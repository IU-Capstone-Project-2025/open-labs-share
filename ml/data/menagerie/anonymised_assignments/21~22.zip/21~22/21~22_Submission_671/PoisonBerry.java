import java.util.List;
import java.util.Random;

/**
 * Simple model of berries.
 * Berries can grow, die, and be eaten by prey.
 *
 * @version 2022.03.02
 */
public class PoisonBerry extends Plant
{
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom(); 
    // The age to which a berry bush can live.
    private static final int MAX_AGE = 5;
    
    /**
     * Create a berry bush. Berries are created with a random age.
     * 
     * @param randomAge If true, the berry will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public PoisonBerry(boolean randomAge, Field field, Location location, int age)
    {
        super(field, location);
        setDefaultAge(0); 
        setMaxAge(MAX_AGE); 
        
        if (randomAge) {
            setDefaultAge(rand.nextInt(MAX_AGE));
        }
    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newGrass A list to receive newly created plants, their age limit, and time period.
     */
    protected void act(List<Plant> newBerry, int maxAge, boolean daytime) {
        if (!environment.getTimeOfDay()) {
            commonBehaviour(newBerry, maxAge); // Only grows during the night    
        }
    }
}
