import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing squirrels, woolves, possums, bears, and pigeons. Alongside,
 * various other plants.
 *
 * @version 2022.03.02
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 140;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 100; 
    
    // The probability a specie that is spawned is female. 
    private static final double FEMALE_PROBABILITY = 0.5;
    
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.04;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.04;
    // The probability that a possum will be created in any given grid position.
    private static final double POSSUM_CREATION_PROBABILITY = 0.055;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.06;  
    // The probability that a pigeon will be created in any given grid position.    
    private static final double PIGEON_CREATION_PROBABILITY = 0.07;
    
    // The probability that grass will be created.
    // Value is decided within the populate species method.
    private static double GRASS_CREATION_PROBABILITY = 0.1; 
    // Probability that a poison berry spawns.
    private static double BERRY_CREATION_PROBABILITY = 0.004;
    
    // Allows access to the methods in the Environment class.
    private static Environment environment = new Environment();
    
    // List of animals in the field.
    private List<Animal> animal;
    // List of plants in the fiel.
    private List<Plant> plant;
    
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    // Animal's colour.
    public static final Color SQUIRREL_COLOUR = new Color(160,160,160); // Grey.
    public static final Color WOLF_COLOUR = new Color(255,128,0); // Orange.
    public static final Color BEAR_COLOUR = new Color(153,76,0); // Brown.
    public static final Color POSSUM_COLOUR = new Color(255,0,0); // Red.
    public static final Color PIGEON_COLOUR = new Color(51,153,255); // Blue.
    
    // Plant's colour.
    public static final Color GRASS_COLOUR = new Color(51,255,51); // Green.
    private static final Color BERRY_COLOUR = new Color(153,51,255); // Purple.
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // Initialising arrayLists.
        animal = new ArrayList<>();
        plant = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Squirrel.class, SQUIRREL_COLOUR);
        view.setColor(Wolf.class, WOLF_COLOUR);
        view.setColor(Bear.class, BEAR_COLOUR); 
        view.setColor(Possum.class, POSSUM_COLOUR); 
        view.setColor(Pigeon.class, PIGEON_COLOUR);
        view.setColor(Grass.class, GRASS_COLOUR);
        view.setColor(PoisonBerry.class, BERRY_COLOUR);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (500 steps).
     */
    public void runLongSimulation()
    {
        simulate(500, 0);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     * @param delayNumber How slow each step progresses.
     */
    public void simulate(int numSteps, int delayNumber)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(delayNumber);
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * species.
     */
    public void simulateOneStep()
    {
        step++;
        environment.incrementSteps(); 
        environment.getSeason();
        environment.getWeather();
        if (Simulator.environment.getTimeOfDay()) {
            populatePlants(); // Continuosly update plants per step during the day.
            
            // Changes plant spawn rate depending on weather conditions.
            if(Simulator.environment.getWeather().equals("Rain") || environment.getWeather().equals("Thunderstorm")) {
                GRASS_CREATION_PROBABILITY = 0.2;
                BERRY_CREATION_PROBABILITY = 0.006;
            }
            else if(environment.getWeather().equals("Acid Rain")) {
                GRASS_CREATION_PROBABILITY = 0;
                BERRY_CREATION_PROBABILITY = 0;
            }
            else {
                GRASS_CREATION_PROBABILITY = 0.1;
                BERRY_CREATION_PROBABILITY = 0.005;
            }
        }
        else {
            GRASS_CREATION_PROBABILITY = 0; // Plants can't photosynthesize without the sun.
            BERRY_CREATION_PROBABILITY = 0;
        }
        
        // Provide space for newly added species.
        List<Animal> newAnimals = new ArrayList<>();  
        List<Plant> newPlants = new ArrayList<>();         
        
        // Let all animals act.
        for(Iterator<Animal> it = animal.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, animal.getMaxAge(), environment.getTimeOfDay());
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        
        // Let all plants act.
        for(Iterator<Plant> it = plant.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants, plant.getMaxAge(), environment.getTimeOfDay());
            if(! plant.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animal.addAll(newAnimals);
        // Add the new plants to the main lists.
        plant.addAll(newPlants);

        view.showStatus(step, field);
        view.showTimeOfDay(environment.getTimeOfDay());
        view.showSeason(environment.getSeason());
        view.showWeather(environment.getWeather());
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        environment.resetEnvironment();
        animal.clear();
        plant.clear();
        populateAnimals();
        populatePlants();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
        view.showTimeOfDay(environment.getTimeOfDay());
        view.showSeason(environment.getSeason());
        view.showWeather(environment.getWeather());
    }
    
    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populateAnimals()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Wolf wolf = new Wolf(true, field, location, 0);
                    animal.add(wolf);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Squirrel squirrel = new Squirrel(true, field, location, 0);
                    animal.add(squirrel);
                }
                else if(rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Bear bear = new Bear(true, field, location, 0);
                    animal.add(bear);
                } 
                else if(rand.nextDouble() <= POSSUM_CREATION_PROBABILITY) {
                    Possum possum = new Possum(true, field, location, 0); 
                    animal.add(possum);
                } 
                else if(rand.nextDouble() <= PIGEON_CREATION_PROBABILITY) {
                    Pigeon pigeon = new Pigeon(true, field, location, 0); 
                    animal.add(pigeon);
                }
                // else leave the location empty.
            }
        }
    } 
    
    /**
     * Randomly populate the field with plants.
     */
    private void populatePlants() {
        Random rand = Randomizer.getRandom();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                Location location = new Location(row, col);
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Grass grass = new Grass(true, field, location, 0);
                    plant.add(grass);
                }
                else if(rand.nextDouble() <= BERRY_CREATION_PROBABILITY) {
                    PoisonBerry berry = new PoisonBerry(true, field, location, 0);
                    plant.add(berry);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
