import java.util.List;
import java.util.Random;

/**
 * A simple model of a plant.
 * Plants age, growup or die.
 * 
 */
public class Plant extends Creature {
    private boolean alive;
    private Field field;
    private Location location;
    private int age;

    // The age to which a plant can live til
    private static final int MAX_AGE = 150;

    // A shared random number generator to control functions of the plant such as growth and spread
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a plant with a random age, at a random location on the field
     *
     * @param randomAge If true, the plant will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location) {
        alive = true;
        this.field = field;
        setLocation(location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else {
            age = 0;
        }
    }

    // How the plant acts whilst it's alive
    public void act(List<Creature> newPlants) {
        incrementAge();
        if(isAlive()) {
            growUp(newPlants);
        }
    }

    // Ages the plant, risk of plant dying
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    // Method called when an animal eats a plant
    public void beEaten() {
        setDead();
    }

    // Plants can only grow/ spread if it is raining
    private void growUp(List<Creature> newPlants) {
        if(field.getWeather() == Weather.RAINY) {
            Location free = field.freeAdjacentLocation(location);
            if(free != null) {
                Plant p = new Plant(false, field, free);
                newPlants.add(p);
            }
        }
    }

    // Chooses a random location for any new plants being spawned
    private void setLocation(Location newLocation) {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    // Removes plant after death
    private void setDead() {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    public boolean isAlive() {
        return alive;
    }

    public Location getLocation() {
        return location;
    }

    public Field getField() {
        return field;
    }
}
