import java.util.List;
import java.util.Random;

/**
 * A simple model of an owl.
 * owls age, move, eat food, breed and die.
 *  
 */
public class Owl extends Animal
{
    // Characteristics shared by all Owls (class variables).

    // The age at which a owl can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a owl can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a owl breeding.
    private static final double BREEDING_PROBABILITY = 0.24;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a prey. In effect, this is the
    // number of steps a owl can go before it has to eat again.
    private static final int FOOD_VALUE = 3;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The owl's age.
    private int age;
    // The owl's food level, which is increased by eating food.
    private int foodLevel;

    /**
     * Create a owl. A owl can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the owl will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Owl(boolean randomAge, Field field, Location location)
    {

        super(field, location, rand.nextBoolean());
        setNocturnal();
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * Increase the age. This could result in the owl's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this owl more hungry. This could result in the owl's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for food adjacent to the current location.
     * Can found if the weather of the field is not foggy
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        if(field.getWeather() == Weather.FOGGY) {
            return null;
        }
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Chicken || animal instanceof Mouse) {
                Animal prey = (Animal) animal;
                if (prey.isAlive()) {
                    prey.setDead();
                    foodLevel = FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this owl is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOwls A list to return newly born Owls.
     */
    protected void giveBirth(List<Creature> newOwls)
    {
        // New Owls are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Owl young = new Owl(false, field, loc);
            newOwls.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * An owl can breed if it is  of breeding age and
     * weather of the field is not foggy and
     * has an adjacent opposite gender mate who is also of breeding age.
     * @return true if the owl can breed, false otherwise.
     */
    private boolean canBreed()
    {
        if(age < BREEDING_AGE) {return false;}
        Field field = getField();
        if(field.getWeather() == Weather.FOGGY) {return false;}
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location location : adjacent) {
            Object animal = field.getObjectAt(location);
            if (animal instanceof Owl) {
                Owl mate = (Owl) animal;
                if (isMale() != mate.isMale() && mate.age >= BREEDING_AGE) {
                    return true;
                }
            }
        }
        return false;
    }

}

