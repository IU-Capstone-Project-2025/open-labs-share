/**
 * Three states of weather present in the simulation
 *  
 */

public enum Weather 
{
    SUNNY,
    RAINY,
    FOGGY
}
