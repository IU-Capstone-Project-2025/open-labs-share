import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing different animals.
 *  
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    //increased constraints to balance the sim with more animals
    private static final int DEFAULT_WIDTH = 300;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;

    private static final int PLANT_CREATION_PROBABILITY = 3;
    // The probability that a snail will be created in any given grid position.
    private static final int SNAIL_CREATION_PROBABILITY = 5;
    // The probability that a chicken will be created in any given grid position.
    private static final int CHICKEN_CREATION_PROBABILITY = 35;
    // The probability that a mouse will be created in any given grid position.
    private static final int MOUSE_CREATION_PROBABILITY = 65;
    // The probability that a snake will be created in any given grid position.
    private static final int SNAKE_CREATION_PROBABILITY = 81;
    // The probability that a owl will be created in any given grid position.
    private static final int OWL_CREATION_PROBABILITY = 97;

    // List of animals in the field.
    private final List<Creature> creatures;
    // The current state of the field.
    private final Field field;
    // The current step of the simulation.
    private int step;
    //Whether it is night or day
    private final Time time;
    // A graphical view of the simulation.
    private final SimulatorView view;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        creatures = new ArrayList<>();
        field = new Field(depth, width);
        time = new Time(true);
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Snail.class, Color.BLACK);
        view.setColor(Chicken.class, Color.ORANGE);
        view.setColor(Snake.class, Color.BLUE);
        view.setColor(Owl.class, Color.CYAN);
        view.setColor(Mouse.class, Color.RED);
        view.setColor(Plant.class, Color.GREEN);

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(450);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Change weather of the field
     * Iterate over the whole field updating the state of each animal
     */
    public void simulateOneStep() {
        step++;
        field.setWeather();
        // Provide space for newborn animals.
        List<Creature> newCreatures = new ArrayList<>();

        //how many steps before the time of day changes(night/day)
        if ((step % 10) == 0) {
            time.timeChange();

        }

        // Let all animals act.

        for (Iterator<Creature> it = creatures.iterator(); it.hasNext(); ) {

            Creature creature = it.next();
            if (creature instanceof Animal) {
                //prevents nocturnal animals moving at night and vice versa
                Animal animal = (Animal) creature;
                if ((time.isDay() && animal.isNocturnal()) || (!time.isDay() && animal.isDiurnal())) {

                } else {
                    animal.act(newCreatures);
                    if (!animal.isAlive()) {
                        it.remove();
                    }
                }
            } else {
                Plant plant = (Plant) creature;
                if (false) {

                } else {
                    plant.act(newCreatures);
                    if (!plant.isAlive()) {
                        it.remove();
                    }
                }
            }
        }

        // Add the newly born animals to the main lists.
        creatures.addAll(newCreatures);

        view.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        creatures.clear();
        //start of sim as daytime
        time.timeDay();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with animals.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                int roll = rand.nextInt(175);
                Location location = new Location(row, col);
                if (roll < PLANT_CREATION_PROBABILITY) {
                    creatures.add(new Plant(true, field, location));
                } else if (roll < SNAIL_CREATION_PROBABILITY) {
                    creatures.add(new Snail(true, field, location));
                } else if (roll < CHICKEN_CREATION_PROBABILITY) {
                    creatures.add(new Chicken(true, field, location));
                } else if (roll < MOUSE_CREATION_PROBABILITY) {
                    creatures.add(new Mouse(true, field, location));
                } else if (roll < SNAKE_CREATION_PROBABILITY) {
                    creatures.add(new Snake(true, field, location));
                } else if (roll < OWL_CREATION_PROBABILITY) {
                    creatures.add(new Owl(true, field, location));
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }

    public static void main(String[] args) {
        Simulator sim = new Simulator();
        sim.runLongSimulation();
    }
}
