/**
 * A simple timekeeper. It, based on the number of steps (decided in the 
 * simulator), determines whether it is day or night
 * and can change/return it
 *
 * 
 **/
public class Time
{
    // instance variables 
    private boolean day;

    /**
     * Constructor for objects of class Time
     */
    public Time(boolean day)
    {
        // initialise instance variables
        this.day = day;
    }

    /**
     * changes it to daytime
     *
     */

    public void timeDay()
    {
        day = true;
    }

    /**
     * returns whether it is daytime or not
     *
     */
    public boolean isDay()
    {

        return day;
    }

    /**
     * changes day to night or night to day
     *
     */

    public void timeChange()
    {
        day = !day;
    }
}
