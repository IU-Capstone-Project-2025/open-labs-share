import java.util.ArrayList;

/**
 * Model of a hyena
 * They can move, eat, reproduce, get infected, and die
 * they eat warthogs
 * they all share one genetic value : 1
 *
 * @version 2022.03.01
 */
public class Hyena extends Animal
{

    //An array of classes that the animal eats
    private static ArrayList<Class<?>> ANIMAL_EATS = new ArrayList<Class<?>>();
    static{
        ArrayList<Class<?>> tmp = new ArrayList<Class<?>>();
        tmp.add(Warthog.class);
        ANIMAL_EATS = tmp;
    }

    // The animals own genetic values
    // always contains one value specific to this particular animal
    private ArrayList<Integer> genetics = new ArrayList<>();

    /**
     * Constructor
     * Creates a hyena with random values
     * adds genetic code 1
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(Field field, Location location)
    {
        super(field, location,Hyena.class);
        genetics.add(1);
    }

    /**
     * second Constructor: needed as it takes
     * parents as parameters
     * Creates a hyena as offspring
     * adds genetic code 1
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    public Hyena(Field field, Location location, Animal parent1, Animal parent2)
    {
        super(field, location,Hyena.class, parent1, parent2);
        genetics.add(1);
    }

    /**
     * Creates and returns hyena as offspring
     * needed to create specific animals in Animal class
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    protected Animal newAnimal(Field field,Location loc, Animal parent1, Animal parent2)
    {
        return new Hyena(field, loc, parent1, parent2);
    }

    /**
     * gets the arraylist of classes the hyena eats
     * @return arraylist of type class
     */
    protected ArrayList<Class<?>> getEats()
    {
        return ANIMAL_EATS;
    }

    /**
     * adds inputted number into genetics list
     * @param number the value that is added
     */
    protected void addGenetics(int number)
    {
        genetics.add(number);
    }

    /**
     * gets the arraylist of genetics for this animal
     * each value in genetics is an integer
     */
    protected ArrayList<Integer> getGenetics()
    {
        return genetics;
    }
}
