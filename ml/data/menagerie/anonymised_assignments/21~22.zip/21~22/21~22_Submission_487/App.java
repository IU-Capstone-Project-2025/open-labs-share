//imports
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;


/**
 * this class is an extension abstract of the settings gui which gives the inputs
 * the inputs are mapped to function given here and shown on the map screen
 *
 * @version 2022.03.01
 */
public class App extends Settings {

    private SimulatorView map;
    private JFrame GUI;
    private Simulator Data;
    private Field Update;
    private int step;

    public App(int sqrsize) {


        super();

        // make gui
        GUI = new JFrame();
        GUI.setLayout(new BorderLayout());
        map = new SimulatorView(sqrsize,sqrsize);

        //panel that all the stuff is on
       JPanel mainPanel = new JPanel();
       mainPanel.setLayout(new GridBagLayout());
       GridBagConstraints c = new GridBagConstraints();


       //constraints for the map
       c.gridx=0;
       c.gridy=0;
       c.weightx = 1.0;
       c.weighty = 1.0;
       //c.gridwidth = 9;
       c.fill = GridBagConstraints.BOTH;

        mainPanel.add(map, c);

    //constraints for settings
       c.gridx=1;
       c.gridy=0;
       c.weightx = 0.2;
       c.weighty = 1.0;
       c.fill = GridBagConstraints.BOTH;

        mainPanel.add(getPanel(),c);


        Config.ConfigSet();


        GUI.add(mainPanel,BorderLayout.CENTER);
        GUI.pack();

        GUI.setDefaultCloseOperation(GUI.EXIT_ON_CLOSE);

        //make intitial data
        // give in feild data intial too
        Data = new Simulator(sqrsize,sqrsize); 

      

        // set initial data

        Update = Data.reset();
        map.showStatus(0, Update);

        GUI.pack();
        GUI.setVisible(true);


    }






    //functions for buttons from settings

    public void runlong(){

        Simulate(100);

    }

    public void step(){

        step++;

        // if you change screen ratio
        GUI.pack();

        Update = Data.simulateOneStep();
        map.showStatus(step, Update);
        

    }

    public void Reset(Config changes){
        step = 0;
        //COMMIT ALL THE mofdifer panes changes
        changes.commit();
             // if you change screen ratio
            GUI.pack();

        Update = Data.reset();
        map.showStatus(0, Update);

    }

    public void ToggleField(int Tochange){

        // if you change screen ratio
        GUI.pack();

        map.ToggleField(Tochange, step, Update);
    }



    // function of its own
    private void Simulate(int numSteps)
    {

        for(int temp = 1; temp <= numSteps && map.isViable(Update); temp++) {
            if(!getThreadRunning()){
                return;
            }
            step++;
            Update = Data.simulateOneStep();
            // delay(500);   // uncomment this to run more slowly
            GUI.pack();
            map.showStatus(step,Update);
            
        }
    }





}
