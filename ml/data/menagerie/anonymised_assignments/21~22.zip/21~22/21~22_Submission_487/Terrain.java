
/**
 * A class representing the terrain of each coordinate
 * including light level, elevation, snow and water requirements
 *
 * @version 2022.03.02
 */

public class Terrain {

    // season for all terrain
    private static int season = 0;
    // time for all terrain
    private static int time = 0;
    // [] is the seson, the second [] is the time of the day and the third[] is the light level
    // so in summer all is bright but in winter all is dark ext
    // 0 is the brightest
    private static int season_light[][][] = {{{0,0,1,1},{1,0,0,1},{1,1,0,0},{3,2,2,3}},// spring
    {{3,2,2,3},{0,0,1,2},{2,1,0,0},{3,2,2,3}},// summer
    {{3,2,2,3},{1,1,2,3},{3,2,1,1},{4,3,3,4}}};//autum
    //{{3,3,3,4},{3,2,2,3},{2,1,1,2},{4,3,3,3}}};//winter

    private static int Repeat = 1;

    // this is the offset to decide what sector of light the terrein sqr is in
    int offset;
    int elevation;
    int waterToGrow;
    boolean snow;


    /**
     * creates a terrain object
     * with an inputted offset and amount of 
     * water needed for a plant to grow
     * @param offset
     * @param waterToGrow
     */
    public Terrain(int offset, int waterToGrow){

        this.offset = offset;
        elevation = 0;
        this.waterToGrow = waterToGrow;

    }

    /**
     * @return get the light level of the particular terrain location
     */
    public int getLight()
    {
        return season_light[season][time][offset];
    }

    /**
     * set the initial light levels for the class
     * @param season_m the starting season
     * @param time_m the starting time
     */
    public static void changeStartingLight(int season_m, int time_m){
        season = season_m;
        time = time_m;

    }

    /**
     * increments the viewed light, based on the season
     * and amount of days per season
     * @param DaysPersSeason the days set per season
     */
    public static void changeStartingLight(int DaysPersSeason){
        time++;
        if (time > 3){
            time -= 4;
            if (Repeat >=DaysPersSeason){
                season++;
                if (season > season_light.length-1){
                    season = 0;
                }
                Repeat = 1;
            }
            else{
                Repeat++;
            }

        }

    }

    /**
     * @return the elevation integer
     */
    public int getElevation(){

        return elevation;
    }
 
    /**
     * @return the amount of water needed to grow integer
     */
    public int getWaterToGrow(){

        return waterToGrow;
    }

    /**
     * @return the current time
     */
    public static int getTime()
    {
        return time;
    }


    /**
     * @return the current season
     */
    public static int getSeason()
    {
        return season;
    }

    /**
     * Set the elevation
     * @param elevation the integer elevation
     */
    public void setElevation( int elevation){

        this.elevation = elevation;
    }

    /**
     * adds amount of water needed to grow
     * @param x the amount more water is needed
     */
    public void editWaterToGrow(int x){

        waterToGrow += x;
    }

    /**
     * clears the elevation and snow
     */
    public void clear(){
        elevation = 0;
        snow = false;
    }

    /**
     * sets snow to true
     */
    public void putSnow(){
        snow = true;
    }

    /**
     * sets snow to false
     */
    public void takeAwaySnow(){
        snow = false;
    }

    /**
     * @return true if there is snow
     */
    public boolean getSnow(){
        return snow;
    }
    
}
