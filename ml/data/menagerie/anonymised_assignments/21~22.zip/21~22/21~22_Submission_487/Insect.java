import java.util.ArrayList;

/**
 * Model of an insect
 * They can move, eat, reproduce, get infected, and die
 * they eat berries and mountain flowers
 * they all share one genetic value : 2
 *
 * @version 2022.03.01
 */public class Insect extends Animal
{

    //An array of classes that the animal eats
    private static ArrayList<Class<?>> ANIMAL_EATS = new ArrayList<Class<?>>();
    static{
        ArrayList<Class<?>> tmp = new ArrayList<Class<?>>();
        tmp.add(BerryPlant.class);
        tmp.add(MountainFlower.class);
        ANIMAL_EATS = tmp;
    }

    // The animals own genetic values
    // always contains one value specific to this particular animal
    private ArrayList<Integer> genetics = new ArrayList<>();

    /**
     * Constructor
     * Creates an insect with random values
     * adds genetic code 2
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Insect(Field field, Location location)
    {
        super(field, location,Insect.class);
        genetics.add(2);

    }

    /**
     * second Constructor: needed as it takes
     * parents as parameters
     * Creates a insect as offspring
     * adds genetic code 2
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    public Insect(Field field, Location location, Animal parent1, Animal parent2)
    {
        super(field, location,Insect.class, parent1, parent2);
        genetics.add(2);

    }

    /**
     * Creates and returns insect as offspring
     * needed to create specific animals in Animal class
     * @param field The field currently occupied.
     * @param location The location within the field
     * @param parent1 one parent of the offspring
     * @param parent2 second parent of the offspring
     */
    protected Animal newAnimal(Field field,Location loc, Animal parent1, Animal parent2)
    {
        return new Insect(field, loc, parent1, parent2);
    }

    /**
     * gets the arraylist of classes the Insect eats
     * @return arraylist of type class
     */
    protected ArrayList<Class<?>> getEats()
    {
        return ANIMAL_EATS;
    }

    /**
     * adds inputted number into genetics list
     * @param number the value that is added
     */
    protected void addGenetics(int number)
    {
        genetics.add(number);
    }
    
    /**
     * gets the arraylist of genetics for this animal
     * each value in genetics is an integer
     */
    protected ArrayList<Integer> getGenetics()
    {
        return genetics;
    }
}
