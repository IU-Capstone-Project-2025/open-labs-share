//imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.FieldView;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Holds all the user buttons, modifiers and interface
 * @version 2022.03.01
 */
abstract class Settings {

    // Entities on the settings screen

    //Simultion controls
    JPanel MainPanel;
    private JButton Runlong,step,reset;
    private JToggleButton Animal,Plant,Terrain;
    //for the thread
    boolean ThreadRunning= false;
    // for changing modifiers
    Config changes;
    // for changing modifiers part 2
    //all the animal modifier panes
    List<AnimalPane> animalChanges;
    //all the plant modifer panes
    List<PlantPane> plantChanges;
    //the earth modifier pane
    EarthPane earthChanges;


    public Settings(){

        //config and changes
        //first set all the configs to default
        Config.ConfigSet();
        changes = new Config();
        List<AnimalPane> animalChanges = new ArrayList<AnimalPane>();
        List<PlantPane> plantChanges = new ArrayList<PlantPane>();
        //layout management 

        MainPanel = new JPanel(new BorderLayout());


        //set size of frame
        //MainPanel.setSize(400,400);

        //map controls
        JPanel Controls = new JPanel(new GridBagLayout()); 
        //testing
        Controls.setBackground(Color.PINK);
        GridBagConstraints c = new GridBagConstraints();      
        // buttons to do simulate func 

        // to get pic for buttons
        ImageIcon Icon = new ImageIcon(Settings.class.getResource("Pics/Step.png"));
        Image img = Icon.getImage();
        Image newimg = img.getScaledInstance( 40, 40,  java.awt.Image.SCALE_SMOOTH ) ;
        Icon = new ImageIcon(newimg);
        
        step = new JButton(Icon);
        step.setBorderPainted(false);
        step.setBorder(null);
       

        step.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(ThreadRunning){
                    return;
                }
                step();
            }
        });
        // set on panel
        //c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        Controls.add(step, c);


        // runlong button

        // to get pic for buttons
        Icon = new ImageIcon(Settings.class.getResource("Pics/Play.png"));
        img = Icon.getImage();
        newimg = img.getScaledInstance( 40, 40,  java.awt.Image.SCALE_SMOOTH ) ;
        Icon = new ImageIcon(newimg);

        Runlong = new JButton( Icon);
        Runlong.setBorderPainted(false);
        Runlong.setBorder(null);
        Runlong.addActionListener(new ActionListener() {
           
            @Override // in another thread so not to cause lag
            public void actionPerformed(ActionEvent e) {
                
                Runnable runnable = new Runnable(){

                    @Override
                    public void run(){
                        //see if thread already running

                        if(getThreadRunning()){
                            ThreadRunning = false;
                            return;
                        }

                        // run thread
                        ThreadRunning = true;
                        runlong();
                        ThreadRunning = false;

                    };
           
                };
                Thread thread = new Thread(runnable);
                thread.start();
            };
        
        });

        // set on panel
        //c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        Controls.add(Runlong, c);        
      




        // The reset button


        // to get pic for buttons
        Icon = new ImageIcon(Settings.class.getResource("Pics/Reset.png"));
        img = Icon.getImage();
        newimg = img.getScaledInstance( 40, 40,  java.awt.Image.SCALE_SMOOTH ) ;
        Icon = new ImageIcon(newimg);


        reset = new JButton( Icon);
        reset.setBorderPainted(false);
        reset.setBorder(null);

        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //set changes
                for(AnimalPane x : animalChanges){
                    x.addChanges();
                }
                for(PlantPane x : plantChanges){
                    x.addChanges();
                }
                earthChanges.addChanges();
                Reset(changes);
            }
        });
        // set on panel
        //c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 2;
        Controls.add(reset, c); 







        //toggle buttons 

        //Animal toggle
        Animal = new JToggleButton("Animals");
        ItemListener itemListener = new ItemListener() {
 
            // itemStateChanged() method is nvoked automatically
            // whenever you click or unlick on the Button.
            public void itemStateChanged(ItemEvent itemEvent)
            {
                // toggle field(if true set false if false set true don in func
                ToggleField(1);
            }
 
        };

        Animal.addItemListener(itemListener);
        c.gridx = 2;
        c.gridy = 0;
        Controls.add(Animal, c);




        //plant toggle
        Plant = new JToggleButton("Plants");
        itemListener = new ItemListener() {
 
            // itemStateChanged() method is nvoked automatically
            // whenever you click or unlick on the Button.
            public void itemStateChanged(ItemEvent itemEvent)
            {
                // toggle field(if true set false if false set true don in func
                ToggleField(3);
            }
 
        };

        Plant.addItemListener(itemListener);
        c.gridx = 2;
        c.gridy = 1;
        Controls.add(Plant, c);



        //plant toggle
        Terrain = new JToggleButton("Terrain");
        itemListener = new ItemListener() {
         
            // itemStateChanged() method is nvoked automatically
            // whenever you click or unlick on the Button.
            public void itemStateChanged(ItemEvent itemEvent)
            {
                // toggle field(if true set false if false set true don in func
                 ToggleField(2);
            }
         
        };
        
        Terrain.addItemListener(itemListener);
        c.gridx = 2;
        c.gridy = 2;
        Controls.add(Terrain, c);








        //for editing the breedeblity ext
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setTabPlacement(JTabbedPane.LEFT);
        //tabbedPane.setPreferredSize(new Dimension(250,400));

        //earth pane used as it hass all the slider in
        earthChanges = new EarthPane(changes);
        tabbedPane.addTab("E", null, earthChanges,"Earth Modifiers");
        tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);




        //plant modifiers
        JPanel PlantBack = new JPanel(new GridBagLayout());
        JPanel Plant = new JPanel(new CardLayout());
        PlantBack.setBackground(Color.YELLOW);
        //cards for plants

        PlantPane Plantcard;
        String[] PlantString = new String[Config.getPlantClasses().size()];
        int count =0;

        //add a pane for each class available Plant
        for(Class<? extends Plants> type : Config.getPlantClasses()){
            
            Plantcard = new PlantPane(type,changes);
            Plant.add(Plantcard,Config.getPlantNames(type));
            PlantString[count] = Config.getPlantNames(type);
            plantChanges.add(Plantcard);
            count++;

        }

        // combobx to control what panle seen
        JComboBox PlantList = new JComboBox(PlantString);
        PlantList.setEditable(false);

        PlantList.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent evt) {

                CardLayout c2 = (CardLayout)(Plant.getLayout());
                c2.show(Plant,(String)evt.getItem());

            }
        });

        c.gridx =0;
        c.gridy = 0;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.HORIZONTAL;

        PlantBack.add(PlantList,c);

        c.gridy = 1;
        PlantBack.add(Plant,c);

        tabbedPane.addTab("P", null, PlantBack,"Plant Modifiers");
        tabbedPane.setMnemonicAt(1, KeyEvent.VK_2);



        //animals modifiers

        JPanel AnimalBack = new JPanel(new GridBagLayout());
        JPanel Animals = new JPanel(new CardLayout());
        AnimalBack.setBackground(Color.GREEN);
        //cards for animals

        AnimalPane card;
        String[] AnimalString = new String[Config.getAnimalClasses().size()];
        count =0;

        //add a pane for each class available animal
        for(Class<? extends Animal> type : Config.getAnimalClasses()){
            card = new AnimalPane(type,changes);
            Animals.add(card,Config.getAnimalNames(type));
            AnimalString[count] = Config.getAnimalNames(type);
            animalChanges.add(card);
            count++;

        }
        // combobx to control what pane seen
        JComboBox AnimalList = new JComboBox(AnimalString);
        AnimalList.setEditable(false);
        AnimalList.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent evt) {

                CardLayout cl = (CardLayout)(Animals.getLayout());
                cl.show(Animals,(String)evt.getItem());

            }
        });

        c.gridx =0;
        c.gridy = 0;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.HORIZONTAL;

        AnimalBack.add(AnimalList,c);

        c.gridy =1;
        AnimalBack.add(Animals,c);


        tabbedPane.addTab("A", null, AnimalBack,"Animal Modifiers");
        tabbedPane.setMnemonicAt(2, KeyEvent.VK_3);


        //constraints for tabbed panel
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 3;
        c.fill = GridBagConstraints.BOTH;
        c.weightx =1;
        c.weighty = 1;

        Controls.add(tabbedPane,c);          



        MainPanel.add(Controls,BorderLayout.CENTER);
        



    }

    private class AnimalPane extends JPanel{

        //the Jsliders
        JSlider AgeSlider, Slider1 ,Slider2 ,Slider3 ,Slider4 ,Slider5 ,Slider6;
        // the class this pane for
        Class<? extends Animal> classToGet;
        // for the color chooer
        JComboBox colorchooser;
        private Color[] colors={Color.red,Color.blue,Color.green,Color.ORANGE,Color.MAGENTA,Color.BLACK,Color.PINK,Color.YELLOW};
        // to allow us to add changes to a profile 
        Config changes;

        public AnimalPane(Class<? extends Animal> AnimalType, Config changes_m){

            classToGet = AnimalType;
            changes = changes_m;

            setBackground(Color.GREEN);
            setLayout(new GridBagLayout());
            GridBagConstraints c = new GridBagConstraints();  
    
            c.gridx =0;
            c.gridy = 0;
            c.weightx = 1.0;
            c.weighty = 1.0;
            c.fill = GridBagConstraints.HORIZONTAL;
    
            // all the sliders, named differently 
            //The jlabal with what it does
            //The jslider
            //adding to the panel
            JLabel label1 = new JLabel("Max age");
            c.gridy = 0;
            add(label1,c);
    
            AgeSlider = new JSlider(JSlider.HORIZONTAL,5,100,Config.getMaxAge(classToGet));
            AgeSlider.setMajorTickSpacing(10);
            AgeSlider.setPaintTicks(true);
            AgeSlider.setPaintLabels(true);
            c.gridy = 1;
            add(AgeSlider,c);
    
    
            JLabel label2 = new JLabel("Breeding age");
            c.gridy = 2;
            add(label2,c);
            Slider1 = new JSlider(JSlider.HORIZONTAL,0,100,Config.getBreedingAge(classToGet));
            Slider1.setMajorTickSpacing(10);
            Slider1.setPaintTicks(true);
            Slider1.setPaintLabels(true);
            c.gridy = 3;
            add(Slider1,c);
    
            JLabel label3 = new JLabel("Breeding probability");
            c.gridy = 4;
            add(label3,c);
            Slider2 = new JSlider(JSlider.HORIZONTAL,0,100,(int)(Config.getBreedingProability(classToGet)*100));
            Slider2.setMajorTickSpacing(10);
            Slider2.setMinorTickSpacing(5);
            Slider2.setPaintTicks(true);
            Slider2.setPaintLabels(true);
            c.gridy = 5;
            add(Slider2,c);
    
            JLabel label4 = new JLabel("Max Babies Produced");
            c.gridy = 6;
            add(label4,c);
            Slider3 = new JSlider(JSlider.HORIZONTAL,0,10,Config.getMaxLitterSize(classToGet));
            Slider3.setMajorTickSpacing(1);
            Slider3.setPaintTicks(true);
            Slider3.setPaintLabels(true);
            c.gridy = 7;
            add(Slider3,c);
    
            JLabel label5 = new JLabel("Sleep Time");
            c.gridy = 8;
            add(label5,c);
            Slider4 = new JSlider(JSlider.HORIZONTAL,0,3,Config.getSleepTime(classToGet));
            Slider4.setMajorTickSpacing(1);
            Slider4.setPaintTicks(true);
            Slider4.setPaintLabels(true);
            c.gridy = 9;
            add(Slider4,c);
    
            JLabel label6 = new JLabel("Food Value");
            c.gridy = 10;
            add(label6,c);
            Slider5 = new JSlider(JSlider.HORIZONTAL,0,100,Config.getAnimalFoodValue(classToGet));
            Slider5.setMajorTickSpacing(10);
            Slider5.setPaintTicks(true);
            Slider5.setPaintLabels(true);
            c.gridy = 11;
            add(Slider5,c);
    
            JLabel label7 = new JLabel("max Hunger");
            c.gridy = 12;
            add(label7,c);
            Slider6 = new JSlider(JSlider.HORIZONTAL,0,100,Config.getHungerValue(classToGet));
            Slider6.setMajorTickSpacing(10);
            Slider6.setPaintTicks(true);
            Slider6.setPaintLabels(true);
            c.gridy = 13;
            add(Slider6,c);

            JLabel Plantlabel10 = new JLabel("Colour");
            c.gridy=14;
            add(Plantlabel10,c);


            // for the colour chooser
            colorchooser = new JComboBox<>(colors);
            colorchooser.setSelectedItem(Config.getColor(classToGet));
            colorchooser.setRenderer(new MyCellRenderer());

            c.gridy = 15;
            add(colorchooser,c);


        }

        // this is to add the pane changes to the cofig profile so it can be changed
        public void addChanges(){
            double[] temp ={(double)Slider1.getValue(), (double)AgeSlider.getValue() ,(double)Slider2.getValue()/100 ,(double)Slider3.getValue() ,(double)Slider4.getValue()
                 ,(double)Slider5.getValue() ,(double)Slider6.getValue()};
            changes.animalChange(classToGet, temp);
            changes.colorChange(classToGet, (Color)colorchooser.getSelectedItem());
        }
    }


    private class PlantPane extends JPanel{

        //the Jsliders
        JSlider PlantSlider7, PlantSlider10 ,PlantSlider2 ,PlantSlider3 ,PlantSlider4 ,PlantSlider5 ,PlantSlider6;
        //class the pane is for
        Class<? extends Plants> classToGet;
        //for color chooser
        JComboBox colorchooser;
        private Color[] colors={Color.red,Color.blue,Color.green,Color.ORANGE,Color.MAGENTA,Color.BLACK,Color.PINK,Color.YELLOW};
        //config so we know what profile to put changes too
        Config changes;

        public PlantPane(Class<? extends Plants> PlantType, Config changes_m){
            classToGet = PlantType;
            changes = changes_m;


            setBackground(Color.YELLOW);
            setLayout(new GridBagLayout());
            GridBagConstraints c = new GridBagConstraints();  

            c.gridx =0;
            c.gridy = 0;
            c.weightx = 1.0;
            c.weighty = 1.0;
            c.fill = GridBagConstraints.HORIZONTAL;

            
            // slider named odd
            //jlable indiacae what slider for
            //jslider
            //put on pane
            JLabel Plantlabel3 = new JLabel("Min Light to Grow");
            c.gridy = 4;
            add(Plantlabel3,c);
             PlantSlider2 = new JSlider(JSlider.HORIZONTAL,1,5,Config.getLightToGrow(classToGet));
            PlantSlider2.setMajorTickSpacing(1);
            PlantSlider2.setPaintTicks(true);
            PlantSlider2.setPaintLabels(true);
            c.gridy = 5;
            add(PlantSlider2,c);
    
            JLabel Plantlabel4 = new JLabel("Min Water to Grow");
            c.gridy = 6;
            add(Plantlabel4,c);
             PlantSlider3 = new JSlider(JSlider.HORIZONTAL,0,10,Config.getWaterToGrow(classToGet));
            PlantSlider3.setMajorTickSpacing(1);
            PlantSlider3.setPaintTicks(true);
            PlantSlider3.setPaintLabels(true);
            c.gridy = 7;
            add(PlantSlider3,c);
    
            JLabel Plantlabel5 = new JLabel("resilience points");
            c.gridy = 8;
            add(Plantlabel5,c);
             PlantSlider4 = new JSlider(JSlider.HORIZONTAL,1,10,Config.getResiliencePoints(classToGet));
            PlantSlider4.setMajorTickSpacing(1);
            PlantSlider4.setPaintTicks(true);
            PlantSlider4.setPaintLabels(true);
            c.gridy = 9;
            add(PlantSlider4,c);
    
            JLabel Plantlabel6 = new JLabel("Food Value");
            c.gridy = 10;
            add(Plantlabel6,c);
             PlantSlider5 = new JSlider(JSlider.HORIZONTAL,0,100,Config.getPlantFoodValue(classToGet));
            PlantSlider5.setMajorTickSpacing(10);
            PlantSlider5.setMinorTickSpacing(5);
            PlantSlider5.setPaintTicks(true);
            PlantSlider5.setPaintLabels(true);
            c.gridy = 11;
            add(PlantSlider5,c);
    
            JLabel Plantlabel7 = new JLabel("Radius of seed spread");
            c.gridy = 12;
            add(Plantlabel7,c);
             PlantSlider6 = new JSlider(JSlider.HORIZONTAL,3,10,Config.getRadius(classToGet));
            PlantSlider6.setMajorTickSpacing(1);
            PlantSlider6.setPaintTicks(true);
            PlantSlider6.setPaintLabels(true);
            c.gridy = 13;
            add(PlantSlider6,c);
    
            JLabel Plantlabel8 = new JLabel("Seed chance");
            c.gridy = 14;
            add(Plantlabel8,c);
             PlantSlider7 = new JSlider(JSlider.HORIZONTAL,0,100,(int)(Config.getChanceToGrow(classToGet)*100));
            PlantSlider7.setMajorTickSpacing(10);
            PlantSlider7.setMinorTickSpacing(5);
            PlantSlider7.setPaintTicks(true);
            PlantSlider7.setPaintLabels(true);
            c.gridy = 15;
            add(PlantSlider7,c);
    
            JLabel Plantlabel9 = new JLabel("Steps to grow");
            c.gridy = 16;
            add(Plantlabel9,c);
             PlantSlider10 = new JSlider(JSlider.HORIZONTAL,1,5,Config.getGrowthSteps(classToGet));
            PlantSlider10.setMajorTickSpacing(1);
            PlantSlider10.setPaintTicks(true);
            PlantSlider10.setPaintLabels(true);
            c.gridy = 17;
            add(PlantSlider10,c);


            JLabel Plantlabel10 = new JLabel("Colour");
            c.gridy=18;
            add(Plantlabel10,c);


            //for color choose
            colorchooser = new JComboBox<>(colors);
            colorchooser.setSelectedItem(Config.getColor(classToGet));
            colorchooser.setRenderer(new MyCellRenderer());

            c.gridy = 19;
            add(colorchooser,c);
    

        }

        ///function to push all slider data to config profile
        public void addChanges(){
            double[] temp ={(double)PlantSlider10.getValue(),(double)Config.getMinElevation(classToGet),(double)Config.getMaxElevation(classToGet),(double)(5-PlantSlider2.getValue()), 
                (double)PlantSlider3.getValue() ,(double)PlantSlider4.getValue(),(double)PlantSlider6.getValue() ,(double)PlantSlider7.getValue()/100 ,(double)PlantSlider5.getValue() };
            changes.plantChange(classToGet, temp);
            changes.colorChange(classToGet, (Color)colorchooser.getSelectedItem());
        }


    }


    private class EarthPane extends JPanel{

        //the Jsliders
        JSlider Slider1,Slider2,Slider3, Slider4;
        //config profile to push to
        Config changes;

        public EarthPane( Config changes_m){
            changes = changes_m;


            setBackground(Color.RED);
            setLayout(new GridBagLayout());
            GridBagConstraints c = new GridBagConstraints();  

            c.gridx =0;
            c.gridy = 0;
            c.weightx = 1.0;
            c.weighty = 1.0;
            c.fill = GridBagConstraints.HORIZONTAL;

            
    
            //Jalbel says what it sis#
            //the jslider
            //put on pane
            JLabel label3 = new JLabel("Days per season");
            c.gridy = 0;
            add(label3,c);
            Slider2 = new JSlider(JSlider.HORIZONTAL,1,91,5);
            Slider2.setMajorTickSpacing(10);
            Slider2.setMinorTickSpacing(5);
            Slider2.setPaintTicks(true);
            Slider2.setPaintLabels(true);
            c.gridy = 1;
            add(Slider2,c);
    
            JLabel label4 = new JLabel("Mountain creation chance");
            c.gridy = 2;
            add(label4,c);
            Slider3 = new JSlider(JSlider.HORIZONTAL,0,100,(int)(Config.getMaxCliffChance()*100));
            Slider3.setMajorTickSpacing(10);
            Slider3.setMinorTickSpacing(5);
            Slider3.setPaintTicks(true);
            Slider3.setPaintLabels(true);
            c.gridy = 3;
            add(Slider3,c);

            JLabel label1 = new JLabel("Snow chance");
            c.gridy = 4;
            add(label1,c);
            Slider1 = new JSlider(JSlider.HORIZONTAL,0,100,(int)(Config.getSnowChance()*100));
            Slider1.setMajorTickSpacing(10);
            Slider1.setMinorTickSpacing(5);
            Slider1.setPaintTicks(true);
            Slider1.setPaintLabels(true);
            c.gridy = 5;
            add(Slider1,c);

            JLabel label5 = new JLabel("Water loss chance");
            c.gridy = 6;
            add(label5,c);
            Slider4 = new JSlider(JSlider.HORIZONTAL,0,100,(int)(Config.getWaterChance()*100));
            Slider4.setMajorTickSpacing(10);
            Slider4.setMinorTickSpacing(5);
            Slider4.setPaintTicks(true);
            Slider4.setPaintLabels(true);
            c.gridy = 7;
            add(Slider4,c);
        }

        // add changes to the config profile
        public void addChanges(){
            double[] temp ={(double)Slider2.getValue(),(double)Slider1.getValue()/100,Config.getGetMaxEarthElevation(),
            (double)Slider3.getValue()/100,(double)Slider4.getValue()/100};
            changes.earthChange(temp);
        }
    }


    //this class is for the color chooser to show the colours instead of the word version
    private class MyCellRenderer extends JButton implements ListCellRenderer {  
        public MyCellRenderer() {  
            setOpaque(true); 
   
        }
        boolean b=false;
       @Override
       public void setBackground(Color bg) {
           // TODO Auto-generated method stub
            if(!b)
            {
                return;
            }
   
           super.setBackground(bg);
       }
        public Component getListCellRendererComponent(  
            JList list,  
            Object value,  
            int index,  
   
            boolean isSelected,  
            boolean cellHasFocus)  
        {  
   
            b=true;
            setText(" ");           
            setBackground((Color)value);        
            b=false;
            return this;  
        }  
   }


   /**
    * 
    * @return the Jpanle of settings
    */
    public JPanel getPanel(){

        return MainPanel;
    }

    /**
    * 
    * @return A boolean value to see if a thread is running
    */
    public boolean getThreadRunning(){

        return ThreadRunning;
    }

    //button functions

    public abstract void runlong();

    public abstract void step();

    /**
     * 
     * @param num to indicate wich feild to toggle
     */
    public abstract void ToggleField(int num);

    /**
     * 
     * @param Config to send what profile is used
     */
    public abstract void Reset(Config changes);
}



