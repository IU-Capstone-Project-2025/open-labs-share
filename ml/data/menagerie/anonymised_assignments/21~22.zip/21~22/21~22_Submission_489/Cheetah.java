import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Cheetah.
 * Cheetahs age, move, breed, and die.
 *  
 * @version 2016.02.29 (2)
 */
public class Cheetah extends Organism
{
    // Characteristics shared by all rabbits (class variables).

    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 3;
    // food value of zebra.
    private static final int ZEBRA_FOOD_VALUE = 25;
    // Food value of wildebeest
    private static final int WILDEBEEST_FOOD_VALUE = 15;

    // A shared random number generator to control breeding
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    private int foodLevel;

    /**
     * Create a new Cheetah. A Cheetah may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Cheetah will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Cheetah(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        setIsMale(rand.nextBoolean()); 

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE);
        }
        else {
            foodLevel = ZEBRA_FOOD_VALUE;
        }
    }

    /**
     * This is what the Cheetah does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * Cheetah does not move at night but feeds
     * @param newCheetah A list to return newly born Cheetah.
     */
    @Override

    public void act(List newCheetah)
    {
        Field field = getField();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(!getIsMale()){ // checks if it is female
                mate(newCheetah);   
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();

            if(field.getDay()){
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     *Checks if there is adjecent cheetah and it is of 
     * opposite gender.
     * @param newCheetah Reproduced cheetahs
     */
    private void mate(List newCheetah){
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent. iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object organism = getField().getObjectAt(where);
            if((organism instanceof Cheetah)&& !getIsMale()){ 
                giveBirth(newCheetah);
                return;
            }
        }
    }

    /**
     * Get the food level of a cheetah
     * @return foodLevel The food level of a particular Cheetah.
     */
    public int getFoodLevel(){
        return foodLevel;
    }

    /**
     * Make this cheetah more hungry. This could result in the cheetah's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * get the maximum age of cheetah.
     * @return The maximum age of Cheetah.
     */
    @Override
    
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Look for wildebeests and zebras adjacent to the current location.
     * Only the first zebra or wildebeest is eaten.
     * If there is adjecent cheetah, the one with greater
     * food level gets to feed.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Zebra) {
                Zebra zebra = (Zebra) organism;
                if(zebra.isAlive()) {
                    zebra.setDead();
                    Object actor = field.getObjectAt(where); 
                    // check if there is a Cheetah around
                    if(actor instanceof Cheetah){
                        Cheetah Cheetah = (Cheetah) actor;
                        if(Cheetah.getFoodLevel() < foodLevel){ //compare food levels
                            foodLevel = ZEBRA_FOOD_VALUE;
                            return where;
                        }
                    }
                    else{
                        foodLevel = ZEBRA_FOOD_VALUE;
                        return where;
                    }
                } 
            }
            if(organism instanceof Wildebeest) {
                Wildebeest wildebeest = (Wildebeest) organism;
                if(wildebeest.isAlive()) {
                    wildebeest.setDead();
                    Object actor = field.getObjectAt(where); 
                    // check if there is a Cheetah around
                    if(actor instanceof Cheetah){
                        Cheetah Cheetah = (Cheetah) actor;
                        if(Cheetah.getFoodLevel() < foodLevel){ //compare food levels
                            foodLevel = WILDEBEEST_FOOD_VALUE;
                            return where;
                        }
                    }
                    else{
                        foodLevel = WILDEBEEST_FOOD_VALUE;
                        return where;
                    }
                } 
            }
        }
        return null;
    }

    /**
     * Initialise the new cheetah
     * @param randomAge True if cheetah will have a random age.
     * @param field The field currently occupied.
     * @param location The location in field.
     */
    @Override
    
    protected Organism createInfant(boolean randomAge, Field field, Location loc){
        return new Cheetah(randomAge, field, loc);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    @Override
    
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Get the breeding age of cheetah
     * @return The breeding age of a cheetah.
     */
    @Override
    
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
}
