import java.util.List;
import java.util.Iterator;

/**
 * A class representing shared characteristics of organisms
 * (both plants and animals). 
 *  
 * @version 2016.02.29 (2)
 */
public abstract class Organism implements Actor
{
    // Whether the organism is alive or not.
    private boolean alive;
    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // The organism's age.
    private int age;
    // Whether an animal is male or not.
    private boolean isMale;

    /**
     * Create a new organism at a location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
        alive = true;
        age = 0;
        this.isMale = isMale;
    }

    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born organisms.
     */
    @Override
    abstract public void act(List<Actor> newOrganisms);

    /**
     * Get the breeding age of an organism
     * @return The breeding age of this organism.
     */
    protected abstract int getBreedingAge();

    /**
     * Get the maximum age of this organism.
     * @return The maximum age of this organism.
     */
    protected abstract int getMaxAge();

    /**
     * Initialise the new organism
     * @param randomAge True if organism will have a random age.
     * @param field The field currently occupied.
     * @param location The location in field.
     */
    protected abstract Organism createInfant(boolean randomAge, Field field,Location loc);

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected abstract int breed();

    /**
     * Check if organism if male or not.
     * @return true if organism is male or false if not.
     */
    public boolean getIsMale(){
        return isMale;
    }

    /**
     * Sets the truth value of the isMale field.
     *@param RandomGender The value of the boolean 
     */
    public void setIsMale(boolean RandomGender){
        isMale = RandomGender;
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the organism is active.
     * @return true if the organism is active/alive 
     * and false if otherwise.
     */
    public boolean isActive(){
        return isAlive();
    }

    /**
     * The current age of the organism.
     * @return The age of this organism.
     */
    protected int getAge(){
        return age;
    }

    /**
     * Assign a new age to the organism.
     * @param Sets a new age.
     */
    protected void setAge(int newAge){
        age = newAge;
    }

    /**
     * Check whether or not this organism is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOrganisms A list to return reproduced organims.
     */
    protected void giveBirth(List<Organism> newOrganisms)
    {
        // New organism are born into adjacent locations.
        // Get a list of adjacent free locations.
        int births = breed();
        List<Location> free = getField().getFreeAdjacentLocations(getLocation());
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Organism young = createInfant(false, getField(), loc);
            newOrganisms.add(young);
        }
    }

    /**
     * Increase the age.
     * This could result in the organims death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Check if the organism can breed.
     * @return true if the organism can breed
     */
    protected boolean canBreed(){

        return age >= getBreedingAge();
    }

    /**
     * Get the field of the organism
     * @return The field of the organism
     */
    protected Field getField(){
        return field;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

}
