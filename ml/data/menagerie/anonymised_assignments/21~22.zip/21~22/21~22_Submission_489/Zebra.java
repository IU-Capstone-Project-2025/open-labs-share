import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a zebra.
 * zebras age, move, breed, and die.
 *  
 * @version 2016.02.29 (2)
 */
public class Zebra extends Organism
{
    // Characteristics shared by all zebras (class variables).

    // The age at which a zebra can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a zebra can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 5;
    // food value of grass
    private static final int GRASS_FOOD_VALUE = 7;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    private int foodLevel;

    /**
     * Create a new zebra. A zebra may be created with age
     * zero (a new born) or with a random age.
     * Sets random gender for zebra
     * 
     * @param randomAge If true, the zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        setIsMale(rand.nextBoolean()); 

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
        }
        else {
            foodLevel = GRASS_FOOD_VALUE;
        }
    }

    /**
     * This is what the zebra does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * Zebra does not move at night but feeds
     * @param newZebra A list to return newly born zebra.
     */
    @Override
    public void act(List newZebra)
    {
        Field field = getField();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(!getIsMale()){ // checks if it is female
                mate(newZebra);   
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();

            if(field.getDay()){
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Checks if there is adjecent zebra and it is of 
     * opposite gender.
     * @param newZebra Reproduced zebra
     */
    private void mate(List newZebra){
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent. iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object organism = getField().getObjectAt(where);
            if((organism instanceof Zebra)&& !getIsMale()){ 
                giveBirth(newZebra);
                return;
            }
        }
    }

    /**
     * Access the food level of a zebra.
     * @return foodLevel The food level of a particular zebra.
     */
    public int getFoodLevel(){
        return foodLevel;
    }

    /**
     * Sets the food level to a new value
     * @param newFoodLevel 
     */
    public void setFoodLevel(int NewFoodLevel){
        foodLevel = NewFoodLevel;
    }

    /**
     * Make this zebra more hungry. This could result in the zebra's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Get the maximum age of zebra.
     * @return The maximum age of Zebra.
     */
    @Override
    
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first grass is eaten.
     * If there is adjecent zebra, the one with greater
     * food level gets to feed.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Grass) {
                Grass grass = (Grass) organism;
                if(grass.isAlive()) {
                    grass.setDead();
                    Object actor = field.getObjectAt(where);
                    // check if there is a zebra around
                    if(actor instanceof Wildebeest){
                        Zebra zebra= (Zebra) actor;
                        if(zebra.getFoodLevel() < foodLevel){ //compare food levels
                            foodLevel = GRASS_FOOD_VALUE;
                            return where;
                        }
                    }
                    else{
                        foodLevel = GRASS_FOOD_VALUE;
                        return where;
                    }
                } 
            }
        }
        return null;
    }

    /**
     * Initialise the new zebra
     * @param randomAge True if zebra will have a random age.
     * @param field The field currently occupied.
     * @param location The location in field.
     */
    @Override
    
    protected Organism createInfant(boolean randomAge, Field field, Location loc){
        return new Zebra(randomAge, field, loc);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    @Override
    
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Access the breeding age of the zebra.
     * @return The breeding age of a zebra.
     */
    @Override
    
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
}
