import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a Lion.
 * Lions age, move, breed, and die.
 *  
 * @version 2016.02.29 (2)
 */
public class Lion extends Organism
{
    // Characteristics shared by all Lions (class variables).

    // The age at which a lion can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a lion can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a lion breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static int MAX_LITTER_SIZE = 2;
    // food value of zebra
    private static final int ZEBRA_FOOD_VALUE = 20;
    // food value of wildebeest
    private static final int WILDEBEEST_FOOD_VALUE = 15;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    private int foodLevel;

    /**
     * Create a new Lion. A Lion may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Lion will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lion(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        setIsMale(rand.nextBoolean()); 

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE);
        }
        else {
            foodLevel = ZEBRA_FOOD_VALUE;
        }
    }

    /**
     * This is what the Lion does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * Lion does not move at night but feeds
     * @param newLion A list to return newly born Lion.
     */
    @Override
    
    public void act(List newLion)
    {
        Field field = getField();
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            if(!getIsMale()){ // checks if it is female
                mate(newLion);   
            }
            // Move towards a source of food if found.
            Location newLocation = findFood();

            if(field.getDay()){
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }

    /**
     * Checks if there is adjecent lion and it is of 
     * opposite gender.
     * @param newLion Reproduced lions
     */
    private void mate(List newLion){
        List<Location> adjacent = getField().adjacentLocations(getLocation());
        Iterator<Location> it = adjacent. iterator();
        while(it.hasNext()){
            Location where = it.next();
            Object organism = getField().getObjectAt(where);
            if((organism instanceof Lion)&& !getIsMale()){ 
                giveBirth(newLion);
                return;
            }
        }
    }

    /**
     * Get the food level of lion
     * @return foodLevel The food level of a particular Lion.
     */
    public int getFoodLevel(){
        return foodLevel;
    }

    /**
     * Sets the food level to a new value
     * @param newFoodLevel 
     */
    public void setFoodLevel(int NewFoodLevel){
        foodLevel = NewFoodLevel;
    }

    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Get the maximum age of lion.
     * @return The maximum age of Lion.
     */
    @Override 
    
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Look for zebras and wildebeests adjacent to the current location.
     * Only the first zebra or wildebeest is eaten.
     * If there is adjecent lion, the one with greater
     * food level gets to feed.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Zebra) {
                Zebra zebra = (Zebra) organism;
                if(zebra.isAlive()) {
                    zebra.setDead();
                    Object actor = field.getObjectAt(where); 
                    // check if there is a Lion around
                    if(actor instanceof Lion){
                        Lion Lion = (Lion) actor;
                        if(Lion.getFoodLevel() < foodLevel){ //compare food levels
                            foodLevel = ZEBRA_FOOD_VALUE;
                            return where;
                        }
                    }
                    else{
                        foodLevel = ZEBRA_FOOD_VALUE;
                        return where;
                    }
                } 
            }
            if(organism instanceof Wildebeest) {
                Wildebeest wildebeest = (Wildebeest) organism;
                if(wildebeest.isAlive()) {
                    wildebeest.setDead();
                    Object actor = field.getObjectAt(where); 
                    // check if there is a Lion around
                    if(actor instanceof Lion){
                        Lion Lion = (Lion) actor;
                        if(Lion.getFoodLevel() < foodLevel){ //compare food levels
                            foodLevel = WILDEBEEST_FOOD_VALUE;
                            return where;
                        }
                    }
                    else{
                        foodLevel = WILDEBEEST_FOOD_VALUE;
                        return where;
                    }
                } 
            }
        }
        return null;
    }

    /**
     * Initialise the new lions
     * @param randomAge True if lion will have a random age.
     * @param field The field currently occupied.
     * @param location The location in field.
     */
    @Override
    
    protected Organism createInfant(boolean randomAge, Field field, Location loc){
        return new Lion(randomAge, field, loc);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    @Override
    
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Get the breeding age of lion
     * @return The breeding age of a lion.
     */
    @Override
    
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
}
