import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A carnivore that eats other smaller dinosaurs.
 *
 * @version 2022.03.09
 */
public class Tyrannosaurus extends Dinosaur
{
    // Characteristics shared by all tyrannosaurusses (class variables).
    // The age at which a tyrannosaurus can start to breed.
    private static final int BREEDING_AGE_TYRANNOSAURUS = 20;
    // The age to which a tyrannosaurus can live.
    private static final int MAX_AGE_TYRANNOSAURUS = 100;
    // The likelihood of a tyrannosaurus breeding.
    private static final double BREEDING_PROBABILITY_TYRANNOSAURUS = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE_TYRANNOSAURUS = 3;
    // The food value of a single kayentatherium. In effect, this is the number of steps a tyrannosaurus can go before it has to eat again.
    private static final int KAYENTATHERIUM_FOOD_VALUE = 9;
    // The food value of a single edmontosaurus. In effect, this is the number of steps a tyrannosaurus can go before it has to eat again.
    private static final int EDMONTOSAURUS_FOOD_VALUE = 12;
    //Probability of catching a disease
    private static final double DISEASE_PROBABILITY = 0.05;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomiser.getRandom();
    
    // Individual characteristics (instance fields).
    // The tyrannosaurus's age.
    private int age;
    // The tyrannosaurus's food level, which is increased by eating prey.
    private int foodLevel;
    // Gender
    private boolean isFemale;
    //are they infected
    private boolean hasDisease;
    
    /**
     * Constructor for class Tyrannosaurus
     */
    public Tyrannosaurus(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE_TYRANNOSAURUS);
            foodLevel = rand.nextInt(EDMONTOSAURUS_FOOD_VALUE);
            isFemale = findGender();
            hasDisease = rand.nextDouble() <= DISEASE_PROBABILITY;
        }
        else
        {
            age = 0;
            foodLevel = EDMONTOSAURUS_FOOD_VALUE;
            isFemale = findGender();
        }
    }
    
    /**
     * This is what the tyrannosaurus does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newTyrannosauruses A list to return newly born tyrannosaurus.
     */
    public void act(List<Organism> newTyrannosauruses)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) 
        {
            possibleTransmission();
            giveBirth(newTyrannosauruses);            
            // Move towards a source of food if found.
            Location newLocation = findFood(); 
            
            if(newLocation == null) 
            { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) 
            {
                setLocation(newLocation);
            }
            else 
            {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    
    /**
     * Increase the age based on whether they have a disease or not.
     * This could result in the predators death.
     */
    protected void incrementAge()
    {
        if(hasDisease)
        {
            age += 2;
        }
        else
        {
            age++;
        }
        
        if(age > MAX_AGE_TYRANNOSAURUS) 
        {
            setDead();
        }
    }
    
    /**
     * Make this tyrannosaurus more hungry. This could result in the tyrannosaurus's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) 
        {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Kayentatherium) 
            {
                Kayentatherium kayentatherium = (Kayentatherium) organism;
                if(kayentatherium.isAlive()) 
                { 
                    kayentatherium.setDead();
                    foodLevel += KAYENTATHERIUM_FOOD_VALUE;
                    return where;
                }
            } else if (organism instanceof Edmontosaurus) 
            {
                Edmontosaurus edmontosaurus = (Edmontosaurus) organism;
                if(edmontosaurus.isAlive()) 
                { 
                    edmontosaurus.setDead();
                    foodLevel += EDMONTOSAURUS_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this tyrannosaurus is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newTyrannosauruses A list to return newly born tyrannosauruses.
     */
    public void giveBirth(List<Organism> newTyrannosauruses)
    {
        // New tyrannosauruses are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Tyrannosaurus young = new Tyrannosaurus(false, field, loc);
            newTyrannosauruses.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY_TYRANNOSAURUS) {
            births = rand.nextInt(MAX_LITTER_SIZE_TYRANNOSAURUS) + 1;
        }
        return births;
    }
    
    /**
     * A tyrannosaurus can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object dinosaur = field.getObjectAt(where);
            if(dinosaur instanceof Tyrannosaurus)
            {
                Tyrannosaurus tyrannosaurus = (Tyrannosaurus) dinosaur;
                return (tyrannosaurus.isFemale == !isFemale && age >= BREEDING_AGE_TYRANNOSAURUS);
            }
        }
        return false;
    }
    
    /**
     * This method is used to scan the adjacent fields of a dinosaur and
     * work out of they will be infected or not.
     */
    public void possibleTransmission()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Dinosaur && hasDisease)
            {
                Dinosaur dinosaur = (Dinosaur) organism;
                dinosaur.hasDisease = rand.nextDouble() <= DISEASE_PROBABILITY;
            }
        }
    }
}