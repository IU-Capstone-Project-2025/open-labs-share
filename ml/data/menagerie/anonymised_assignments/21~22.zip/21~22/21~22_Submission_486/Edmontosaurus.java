import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Herbivore that eats grass and fern, prey dinosaur to others.
 *
 * @version 2022.03.09
 */
public class Edmontosaurus extends Dinosaur
{
    // Characteristics shared by all edmontosaurus (class variables).
    // The age at which a edmontosaurus can start to breed.
    private static final int BREEDING_AGE_EDMONTOSAURUS = 10;
    // The age to which a edmontosaurus can live.
    private static final int MAX_AGE_EDMONTOSAURUS = 30;
    // The likelihood of a edmontosaurus breeding.
    private static final double BREEDING_PROBABILITY_EDMONTOSAURUS = 0.8;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE_EDMONTOSAURUS = 8;
    //The value of food that grass gives to the edmontosaurus.
    private static final int GRASS_FOOD_VALUE = 20;
    //The value of food that fern gives to the edmontosaurus
    private static final int FERN_FOOD_VALUE = 10;
    //Probability of catching a disease
    private static final double DISEASE_PROBABILITY = 0.1; 
    // A shared random number generator to control breeding.
    private static final Random rand = Randomiser.getRandom();
    
    // Individual characteristics (instance fields).
    // The edmontosaurus's age.
    private int age;
    //Food level of edmontosaurus
    private int foodLevel;
    //gender
    private boolean isFemale;
    //are they infected
    private boolean hasDisease;
    
    /**
     * Concstructor for dinosaur Edmontosaurus.
     */
    public Edmontosaurus(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) 
        {
            age = rand.nextInt(MAX_AGE_EDMONTOSAURUS);
            foodLevel = rand.nextInt(GRASS_FOOD_VALUE);
            isFemale = findGender();
            hasDisease = rand.nextDouble() <= DISEASE_PROBABILITY;
        }
        else
        {
            age = 0;
            foodLevel = GRASS_FOOD_VALUE;
            isFemale = findGender();
        }
    }
    
    /**
     * This is what the prey does most of the time - it runs 
     * around. Sometimes it will breed, eat plants, or die of old age.
     * @param newEdmontosaurus A list to return newly born Edmontosaurus.
     */
    public void act(List<Organism> newEdmontosaurus)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) 
        {
            possibleTransmission();
            giveBirth(newEdmontosaurus);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) 
            { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) 
            {
                setLocation(newLocation);
            }
            else 
            {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the age based on if they have a disease
     * This could result in the prey's death.
     */
    protected void incrementAge()
    {
        if(hasDisease)
        {
            age += 2;
        }
        else
        {
            age++;
        }
        
        if(age > MAX_AGE_EDMONTOSAURUS) 
        {
            setDead();
        }
    }
    
    /**
     * Make this dinosaur more hungry. This could result in their death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) 
        {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Edmontosaurus is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newEdmontosaurus A list to return newly born prey.
     */
    public void giveBirth(List<Organism> newEdmontosaurus)
    {
        // New prey are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) 
        {
            Location loc = free.remove(0);
            Edmontosaurus young = new Edmontosaurus(false, field, loc);
            newEdmontosaurus.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY_EDMONTOSAURUS) 
        {
            births = rand.nextInt(MAX_LITTER_SIZE_EDMONTOSAURUS) + 1;
        }
        return births;
    }
    
    /**
     * A Edmontosaurus can breed if it has reached the breeding age.
     * @return true if the prey can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object dinosaur = field.getObjectAt(where);
            if(dinosaur instanceof Edmontosaurus)
            {
                Edmontosaurus edmontosaurus = (Edmontosaurus) dinosaur;
                return (edmontosaurus.isFemale == !isFemale && age >= BREEDING_AGE_EDMONTOSAURUS);
            }
        }
        return false;
    }
    
    /**
     * Look for Plants adjacent to the current location.
     * Only the first live plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) 
        {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Grass) 
            {
                Grass grass = (Grass) organism;
                if(grass.isAlive()) 
                { 
                    grass.setDead();
                    foodLevel += GRASS_FOOD_VALUE;
                    return where;
                }
            } 
            else if (organism instanceof Ivy)
            {
                Ivy ivy = (Ivy) organism;
                if(ivy.isAlive())
                {
                    ivy.setDead();
                    age = 0;
                    return where;
                }
            }
            else if (organism instanceof Fern)
            {
                Fern fern = (Fern) organism;
                if(fern.isAlive())
                {
                    fern.setDead();
                    foodLevel += FERN_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
        /**
     * This method is used to scan the adjacent fields of a dinosaur and
     * work out of they will be infected or not.
     */
    public void possibleTransmission()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext())
        {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Dinosaur && hasDisease)
            {
                Dinosaur dinosaur = (Dinosaur) organism;
                dinosaur.hasDisease = rand.nextDouble() <= DISEASE_PROBABILITY;
            }
        }
    }
}