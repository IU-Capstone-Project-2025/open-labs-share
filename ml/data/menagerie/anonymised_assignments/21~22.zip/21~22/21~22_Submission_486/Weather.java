import java.util.Random;

/**
 * Weather class allows for three different weather conditions (Sunny, rain, storm), it includes methods to set random weather in the simulation.
 *
 * @version 2022.03.09
 */
public class Weather
{
    // Variable that show whether a weather event is taking place.
    private boolean isSunny;
    private boolean isRainy;
    private boolean isStormy;
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        isSunny = false;
        isRainy = false;
        isStormy = false;
    }
    
    /**
     * This method creates a random weather event based on a random number as weather event probability.
     * It will then call the corresponding method to set the weather event boolean to true.
     */
    public void setRandomWeather()
    {
        Random rand1 = new Random();
        int n = rand1.nextInt(20);
        if(n <= 8) {
            setSunny();
        } 
        else if (n > 8 && n<=15) 
        {
            setRainy();
        } 
        else 
        {
            setStormy();
        }
    }
    
    // ---- Accessor methods for weather conditions. ----
    
    /**
     * @return isSunny
     */
    public boolean isSunny()
    {
        return isSunny;
    }
    
    /**
     * @return isRainy
     */
    public boolean isRainy()
    {
        return isRainy;
    }
    
    /**
     * @return isStormy
     */
    public boolean isStormy()
    {
        return isStormy;
    }
    
    // ---- Setter methods to set weather condition to true. ----
    
    /**
     * Sets isSunny to true.
     */
    private void setSunny()
    {
        isRainy = false;
        isStormy = false;
        isSunny = true;
    }
    
    /**
     * Sets isRainy to true.
     */
    private void setRainy()
    {
        isSunny = false;
        isStormy = false;
        isRainy = true;
    }
    
    /**
     * Sets isStormy to true.
     */
    private void setStormy()
    {
        isSunny = false;
        isRainy = false;
        isStormy = true;
    }
}