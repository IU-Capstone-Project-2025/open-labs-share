import java.util.List;

/**
 * Organism is the superclass for anything that lives in our simulation, plants or dinosaurs.
 *
 * @version 2022.03.09
 */
public abstract class Organism
{
    // The organism's field.
    private Field field; 
    // The organisms's position in the field.
    private Location location;
    // Boolean variable whether the organism is alive or not.
    private boolean alive;
    // Probability of a plant pollination (equivalent of animal's breedingProbability).
    protected double pollinationProbability;

    /**
     * Constructor for class Organism
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }

    /**
     * Make this Organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newOrganisms A list to receive newly born Organisms.
     */
    abstract public void act(List<Organism> newOrganisms);

    /**
     * Indicate that the Organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Check whether the Organism is alive or not.
     * @return true if the Organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Return the Organism's location.
     * @return The Organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the Organism at the new location in the given field.
     * @param newLocation The Organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the Organism's field.
     * @return The Organism's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Increases the plant's pollination probability for the weather condition isSunny.
     * The pollination probability only increases if it is less than 0.5 such that it does not get too large and disrupt the balanced environment.
     */
    public void increasePollinationProbability()
    {
        if (pollinationProbability < 0.3) {
            pollinationProbability += 0.002;
        }
    }
    
    /**
     * Decreases the plant's pollination probability for the weather condition isRainy.
     * The pollination probability only decreases if it is greater than 0.002 such that it does not go below zero and disrupt the balanced environment.
     */
    public void decreasePollinationProbability()
    {
        if (pollinationProbability > 0.002) {
            pollinationProbability -= 0.002;
        }
    }
}