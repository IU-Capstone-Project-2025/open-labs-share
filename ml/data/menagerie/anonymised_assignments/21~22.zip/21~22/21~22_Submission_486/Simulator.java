import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.SwingUtilities;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing organisms.
 *
 * @version 2022.03.09
 */
public class Simulator
{
    // ---- Constants representing configuration information for the simulation. ---
    
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 240;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 150;
    
    // The probability that a kayentatherium will be created in any given grid position.
    private static final double KAYENTATHERIUM_CREATION_PROBABILITY = 0.05;
    // The probability that a velociraptor will be created in any given grid position.
    private static final double VELOCIRAPTOR_CREATION_PROBABILITY = 0.02;    
    // The probability that a tyrannosaurus will be created in any given grid position.
    private static final double TYRANNOSAURUS_CREATION_PROBABILITY = 0.02;   
    // The probability that a edmontosaurus will be created in any given grid position.
    private static final double EDMONTOSAURUS_CREATION_PROBABILITY = 0.05;   
    // The probability that a megalosaurus will be created in any given grid position.
    private static final double MEGALOSAURUS_CREATION_PROBABILITY = 0.02;   
    // The probability that a patch of grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.1;
    //The probability that a patch of grass will be created in any given grid position.
    private static final double IVY_CREATION_PROBABILITY = 0.03;
    //The probability that a patch of grass will be created in any given grid position.
    private static final double FERN_CREATION_PROBABILITY = 0.04;
    
    
    // ---- Instance variables ----
    
    // The current state of the field.
    private Field field;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Current weather condition.
    private Weather weather;
    // Fun fact pop-up screen.
    private FunFact funFact;
    
    // The current step of the simulation.
    public static int step;
    // List of animals in the field.
    private List<Organism> organisms;

    // Boolean variable weather or not the simulation button has been clicked to start the simulation.
    private boolean clicked;
    // Boolean variable weather or not the simulation is running.
    private boolean isRunning;
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) 
        {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        // Create necessary objects for simulation such as: weather condition, organisms arraylist and field.
        weather = new Weather();
        organisms = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Kayentatherium.class, new Color(173, 177, 255)); //pastel purple
        view.setColor(Velociraptor.class, new Color(227, 247, 2)); //bright yellow
        view.setColor(Tyrannosaurus.class, new Color(250, 40, 50)); //red
        view.setColor(Edmontosaurus.class, new Color(247, 177, 250)); //pastel pink
        view.setColor(Megalosaurus.class, new Color(250, 135, 40)); //orange
        view.setColor(Grass.class, new Color(43, 140, 36)); //dark green
        view.setColor(Ivy.class, new Color(45, 250, 246)); //turquoise
        view.setColor(Fern.class, new Color(185, 247, 181)); //light green

        // Setup a valid starting point.
        reset();

        // Define simulation button conditions and actions.
        clicked = false;
        setSimulationButtonAction();
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        funFact = new FunFact();
        setWeather();

        for(int step = 1; step <= numSteps && view.isViable(field) && isRunning; step++) 
        {
            simulateOneStep();
            SwingUtilities.invokeLater(() -> {
                    view.repaint(); 
                });
            
            // Closes old pop-up funfact screen and creates a new one every 300 steps.
            if (step%300 == 0) 
            {
                funFact.getFactFrame().dispatchEvent(new WindowEvent(funFact.getFactFrame(), WindowEvent.WINDOW_CLOSING));
                funFact.create();
            }

            // Sets new weather conditions every 100 steps.
            if (step%100 == 0) 
            {
                setWeather();
            }
        }

        // Executes when desired simulation duration has been reached and allows for simulation to be restarted.
        if (step == view.getSimulationSliderValue() || !view.isViable(field)) 
        {
            funFact.getFactFrame().dispatchEvent(new WindowEvent(funFact.getFactFrame(), WindowEvent.WINDOW_CLOSING));
            view.getSimulationButton().setVisible(false);
            view.getRestartButton().setVisible(true);
            isRunning = false;
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each organism.
     */
    private void simulateOneStep()
    {
        step++;

        // Provide space for newborn animals.
        List<Organism> newOrganisms = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); )
        {
            Organism organism = it.next();
            organism.act(newOrganisms);
            if(! organism.isAlive()) 
            {
                it.remove();
            }
        }

        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with organisms.
     */
    private void populate()
    {
        Random rand = Randomiser.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) 
        {
            for(int col = 0; col < field.getWidth(); col++) 
            {
                if(rand.nextDouble() <= KAYENTATHERIUM_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Kayentatherium kayentatherium = new Kayentatherium(true, field, location);
                    organisms.add(kayentatherium);
                }
                else if(rand.nextDouble() <= EDMONTOSAURUS_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Edmontosaurus edmontosaurus = new Edmontosaurus(true, field, location);
                    organisms.add(edmontosaurus);
                }
                else if(rand.nextDouble() <= VELOCIRAPTOR_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Velociraptor velociraptor = new Velociraptor(true, field, location);
                    organisms.add(velociraptor);
                }
                else if(rand.nextDouble() <= TYRANNOSAURUS_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Tyrannosaurus tyrannosaurus = new Tyrannosaurus(true, field, location);
                    organisms.add(tyrannosaurus);
                }
                else if(rand.nextDouble() <= MEGALOSAURUS_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Megalosaurus megalosaurus = new Megalosaurus(true, field, location);
                    organisms.add(megalosaurus);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    organisms.add(grass);
                }
                else if(rand.nextDouble() <= IVY_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Ivy ivy = new Ivy(true, field, location);
                    organisms.add(ivy);
                }
                else if(rand.nextDouble() <= FERN_CREATION_PROBABILITY) 
                {
                    Location location = new Location(row, col);
                    Fern fern = new Fern(true, field, location);
                    organisms.add(fern);
                }
                //leave the location empty.
            }
        }
    }
    
    /**
     * Reset the simulation to a starting position.
     */
    private void reset()
    {
        step = 0;
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Sets the weather conditions, weather simulation label, and weather effect on the organisms.
     */
    private void setWeather()
    {
        weather.setRandomWeather();
        weatherLabelString();
        reactionToWeather();
    }

    /**
     * Changes the label on the GUI that tells the user what weather event is happening at the moment.
     */
    private void weatherLabelString()
    {
        view.setWeatherLabelString("nothing is happenening");
        if (weather.isSunny()) 
        {
            view.setWeatherLabelString("The sun is shining bright!");
        } else if (weather.isRainy()) 
        {
            view.setWeatherLabelString("It's pouring rain!");
        } else if (weather.isStormy()) 
        {
            view.setWeatherLabelString("There is a terrible storm!");
        }
    }
    
    /**
     * This method shows the way plants react to different weather conditions, 
     * usually changing the pollination probabilities or if there is a storm, killing off some organisms.
     */
    private void reactionToWeather()
    {
        if(weather.isSunny()) // pollinationProbability increases for all plants
        {
            for(Organism organism : organisms) {
                if (organism instanceof Plant) {
                    organism.increasePollinationProbability();
                }
            }
        } 
        else if(weather.isRainy()) // pollinationProbability decreases for all plants
        {
            for(Organism organism : organisms) {
                if (organism instanceof Plant) {
                    organism.decreasePollinationProbability();
                }
            }
        } 
        else if(weather.isStormy()) // 1 in 8 organisms die
        {
            int count = 0;
            for(Organism organism : organisms) {
                if (count%8 == 0) {
                    organism.setDead();
                }
                count++;
            }
        }
    }
    
    /**
     * Sets the actions for the buttons in charge of start, pause, resume, restart; as well as change their labels accordingly.
     */
    private void setSimulationButtonAction()
    {
        clicked = true;
        view.getSimulationButton().addActionListener (new ActionListener()
        {
                public void actionPerformed(ActionEvent e)
                {
                    if (clicked) // Starts the simulation.
                    {
                        new Thread(() -> {
                                simulate(view.getSimulationSliderValue());
                            }).start();
                        view.getSimulationButton().setText("Click to pause simulation.");
                        isRunning = true;
                        clicked = false;
                    } 
                    else if (isRunning) // Pauses the simulation.
                    {
                        view.getSimulationButton().setText("Click to resume simulation.");
                        isRunning = false;
                        funFact.getFactFrame().dispatchEvent(new WindowEvent(funFact.getFactFrame(), WindowEvent.WINDOW_CLOSING));
                    } 
                    else if (!isRunning) // Resumes the simulation.
                    {
                        view.getSimulationButton().setText("Click to pause simulation.");
                        isRunning = true;

                        new Thread(() -> {
                                simulate(view.getSimulationSliderValue() - step);
                            }).start();
                    }
                }
            });
        view.getRestartButton().addActionListener (new ActionListener()
        {
                public void actionPerformed(ActionEvent e)
                {
                    reset();
                    isRunning = true;
                    view.getSimulationButton().setVisible(true);
                    view.getRestartButton().setVisible(false);
                    new Thread(() -> {
                            simulate(view.getSimulationSliderValue());
                        }).start();
                    view.getSimulationButton().setText("Click to pause simulation.");
                }
            });
    }
}