/**
 * 
 * A simple model for a grass.
 * All that a grass does is grow and be eaten by animals.
 *
 * @version 1
 */
public class Grass extends Plant{

    //the probability that a grass creates a new leaf
    private final double REPRODUCTION_PROBABILITY = 0.20;

    //the probability that the grass is digested
    private final double DIGESTION_PROBABILITY = 0.8;

    //how many leaves the grass can make at one time
    private final int MAX_LEAF_SIZE = 3;

    //how much the grass can extend from the grass of depth 0
    private final int MAX_PLANT_EXTENSION = 2;

    //how far away, a leaf can be birthed to.
    //mimicking a branch of a plant.
    private final int MAX_BRANCH_EXTENSION = 1;

    //how fast the plant grows, effectively how many steps it takes for a plant to grow.
    private final int GROWTH_RATE = 5;

    /**
     * Create a Grass object, providing the current field,
     * the location of the grass and the "depth" : aka how far away it is from a grass of
     * depth 0. 
     * One can see a grass of depth 0 as the "main" grass, and the rest
     * are the grass's leaves extending outwards.
     * 
     * @param field the current field of the simulation
     * @param location the location of the new grass
     * @param depth how far away this grass is from the grass of depth 0.
     * 
     */
    public Grass(Field field, Location location, int depth)
    {
        super(field, location, depth);
    }

    /**
     * Returns the Grass class type
     * @return the Grass class type
     */
    protected Class<?> getPlantType(){
        return Grass.class;
    }

    /**
     * Returns the Grass's defining attributes 
     * @return the Grass's defining attributes
     */
    protected double[] getPlantAttributes(){
        return new double[] {REPRODUCTION_PROBABILITY, DIGESTION_PROBABILITY, 
                             MAX_LEAF_SIZE, MAX_PLANT_EXTENSION, MAX_BRANCH_EXTENSION, GROWTH_RATE};
    }

    /**
     * Create a new grass, providing the current field,
     * new location and depth.
     * 
     * @param field the current field of the simulation
     * @param location the location of the new grass
     * @param depth the depth of the new grass
     */
    public Organism createOffspring(Field field, Location location, int depth)
    {
        return new Grass(field, location, depth);
    }
}