import java.util.HashMap;
import java.util.List;

/**
 * A simple model of a Wolf.
 * Wolf age, move, breed, and die.
 * They can also clean themselves, thus creating a partial immunity to pathogens.
 *
 * @version 1
 */
public class Wolf extends Animal
{
    // Characteristics shared by all Wolves (class variables).
    
    // The age at which a Wolf can start to breed.
    private static final int BREEDING_AGE = 14;

    // The age to which a Wolf can live.
    private static final int MAX_AGE = 250;

    // The likelihood of a Wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;

    //the maximum food the Wolf can eat.
    private static final int MAX_FOOD_VALUE = 14;

    // The food value of a single deer. 
    private static final int DEER_FOOD_VALUE = 4;

    // The food value of a single boar.
    private static final int BOAR_FOOD_VALUE = 3;
    
    // The food value of a single bush
    private static final int BUSH_FOOD_VALUE = 2;

    // The time of day at which the wolf sleeps at
    private static final int SLEEP_CYCLE = Simulator.DAY_LENGTH/2;

    private static final double CLEAN_PROBABILITY = 0.5;
    

    /**
     * Create a new wolf, with a random age and pair of genes.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(Field field, Location location)
    {
        super(field, location, null, null);
    }

    /**
     * Create a newly born Wolf, assign its genes in function of his parent's genes.
     * 
     * @param field the field currently occupied.
     * @param location the location within the field
     * @param maleGenes the genes of the male parent
     * @param femaleGenes the genes of the female parent
     */
    public Wolf(Field field, Location location, byte[] maleGenes, byte[] femaleGenes){
        super(field, location, maleGenes, femaleGenes);
    }

    /**
     * Implementation to return the wolf's base characteristics
     */
    protected double[] getCharacteristics() {
        return new double[] {BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, MAX_LITTER_SIZE, MAX_FOOD_VALUE, SLEEP_CYCLE};
    }

    /**
     * returns the wolf's class type
     */
    protected Class<?> getAnimalType(){
        return Wolf.class;
    }

    /**
     * returns the Wolf's diet, which consists of boars, deers and bushes.
     */
    protected HashMap<Class<?>, Integer> getFoodInformation(){
        HashMap<Class<?>, Integer> foodInformation = new HashMap<Class<?>, Integer>();

        foodInformation.put(Bush.class, BUSH_FOOD_VALUE);
        foodInformation.put(Boar.class, BOAR_FOOD_VALUE);
        foodInformation.put(Deer.class, DEER_FOOD_VALUE);


        return foodInformation;
    }
    
    /**
     * Creates a new Wolf offspring
     */
    public Animal createOffspring(Field field, Location loc, byte[] maleGenes, byte[] femaleGenes){
        return new Wolf(field, loc, maleGenes, femaleGenes);
    }

    /**
     * Does the actions specific to Wolfes.
     */
    protected void doSpecialisedActions(List<Organism> newAnimals){
        if (!isAlive()) return;

        //get a singular, random active gene to decide on the wolf's actions.
        int bitIndex = this.getRandomActionGeneBitIndex();

        //Here we implement the different actions determined by the Wolf's genes
        //each case represents a gene, so it can go up to case 7.
        switch(bitIndex){
            case 0:
            case 1:
                clean();
                break;
            
        }    
    }

    /**
     * The wolf cleans itself, with a probability of killing all pathogens.
     */
    private void clean(){
        if (rand.nextDouble() <= CLEAN_PROBABILITY)  this.pathogen = null;
    }

    /**
     * What wolves do when they're asleep.
     * Some of them may sleep walk.
     * 
     * @param newAnimals the list of newly born animals
     */
    protected void doSpecialisedSleepActions(List<Organism> newAnimals){
        if (!isAlive()) return;

        //get a singular, random active gene to decide on the wolf's actions.
        int bitIndex = this.getRandomActionGeneBitIndex();

        switch(bitIndex){
            case 0:
            case 2:
                sleepWalk();
                break;
            
            }  
    }

    /**
     * Move the wolf to a new random adjacent location
     */
    private void sleepWalk(){
        Location newLocation = field.randomAdjacentLocation( location );

        this.setLocation( newLocation );
    }

}