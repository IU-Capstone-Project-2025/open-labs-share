import java.util.prefs.Preferences;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A model for every organism of the simulation.
 * Each organism is alive and is living on a field, with a location.
 * An organism's actions and qualities may be affected by its genetic makeup, 
 * that is encoded with bytes for each chromosome.
 * 
 * A chromosome may encompass a set of genes, and each gene encodes information.
 * Therefore in every chromosome, there are 8 genes (8 bits) of information.
 *
 * @version 1.0
 */
public abstract class Organism
{
    // A shared random number generator to control random behaviour.
    protected static final Random rand = Randomizer.getRandom();

    //the probability of a genetic mutation.
    private static final double MUTATION_PROBABILITY = 0.01;

    //the total number of chromosomes in every organism.
    private static final int NUMBER_OF_CHROMOSOMES = 2;


    //the genes of the organism that determine its qualities.
    //In our model the first gene controls the base characteristics (e.g : max_age, sleep time...)
    //and the second one its actions (e.g hunt more aggressively...). 
    private byte[] genes;

    // Whether the organism is alive or not.
    protected boolean alive;
    protected Pathogen pathogen;


    // The organism's field.
    protected Field field;

    // The organism's position in the field.
    protected Location location;

    // The organism's perception of time of the day.
    // It never surpasses the value of one day.
    protected int time;

    /**
     * The constructor to create an organism. If any of the parent's genes are null,
     * then we just create random ones.
     * @param field the field currently occupied
     * @param location the location within the field
     * @param maleGenes the genes given by the male parent
     * @param femaleGenes the genes given by the female parent
     */
    public Organism(Field field, Location location, byte[] maleGenes, byte[] femaleGenes) {

        this.alive = true;
        this.pathogen = null;

        this.field = field;
        this.location = location;

        loadTime();

        if (maleGenes == null || femaleGenes == null) {
            this.genes = new byte[2];
            randomGenes();
        }else {
            this.genes = mixGenes(maleGenes, femaleGenes);
        }
    }

    /**
     * Loads in the time of day, by using preferences.
     * It takes in the current number of steps.
     */
    public void loadTime(){
        String programDir = System.getProperty("user.dir");
        Preferences prefs = Preferences.userRoot().node(programDir);

        time = prefs.getInt("steps",0) % Simulator.DAY_LENGTH;
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if (field == null) return;
        
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * The action of the organism 
     * @param newOrganisms the list of newly born organisms
     */
    protected abstract void act(List<Organism> newOrganisms);

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Return the organism's genes.
     * @return the organism's genes.
     */
    public byte[] getGenes(){
        return this.genes;
    }
    
    /**
     * Assign random genes to the organism
     */
    private void randomGenes() {
        rand.nextBytes(this.genes);
    }

    /**
     * Merges the parent's genes with a dominant-recessive heuristic : the dominant genes are
     * passed on, whereas the recessive ones are not.
     * 
     * A dominant gene is marked with a 1 in the chromosome's byte whereas a recessive one
     * is marked with a 0.
     * 
     * An element of random mutation is added to favour genetic diversity.
     * @param maleGenes the genes of the male parent.
     * @param femaleGenes the genes of the female parent.
     * @return the offspring's mixed genes
     */
    private byte[] mixGenes(byte[] maleGenes, byte[] femaleGenes){
        byte[] newGenes = new byte[NUMBER_OF_CHROMOSOMES];

        // the logical xor is the implementation of our heuristic
        for (int i = 0; i < NUMBER_OF_CHROMOSOMES; i++){
            newGenes[i] = (byte) (maleGenes[i] ^ femaleGenes[i]);
        }

        newGenes = randomMutation(newGenes);
        
        return newGenes;

        //simpler mixing, other possible heuristic
        //return new byte[] {maleGenes[0], femaleGenes[1]};
    }

    /**
     * Puts a possible random mutation inside each chromosome of the organism's genes.
     * @param genes the genes to be mutated randomly.
     * @return the mutated genes.
     */
    private byte[] randomMutation(byte[] genes){
        byte[] newGenes = new byte[NUMBER_OF_CHROMOSOMES];

        for (int i = 0; i < NUMBER_OF_CHROMOSOMES; i++) {
            byte chromo = genes[i];
            //at most one mutation/chromosome
            if (rand.nextDouble() < MUTATION_PROBABILITY){
                newGenes[i] = (byte) (chromo | (rand.nextInt(1) << rand.nextInt(8)));
            }
        }

        return genes;
    }

    /**
     * Returns whether a particular gene in a chromosome is true or not.
     * @param geneIndex the index describing which chromosome we are checking.
     * @param geneBitIndex the index of the bit (gene) within the byte (chromosome).
     * @return whether the particular gene is present or not.
     */
    protected boolean isGeneBitTrue(int geneIndex, int geneBitIndex){
        //we shift the bit all the way to the right to get rid of all the bits 
        //to the right of our aforementioned bit. We then use the bitwise & to get rid of the otehr bits.
        return ((this.genes[geneIndex] >> geneBitIndex) & 1) == 1;
    }

    /**
     * We get a random gene from the second chromosome, that dictates the organism's behaviour.
     * We return the index of this gene, which gives a unique identifier for it.
     * @return the index of the gene picked randomly form the second chromosome.
     */
    protected int getRandomActionGeneBitIndex(){
        ArrayList<Integer> activeGeneBitIndexes = new ArrayList<Integer>();
        for (int i = 0; i < 8; i++){
            if ( isGeneBitTrue(1, i) ){
                activeGeneBitIndexes.add(i);
            }
        }
        int size = activeGeneBitIndexes.size();

        //in case of no active genes.
        if (size == 0) return -1;
        
        return activeGeneBitIndexes.get( rand.nextInt(size) );
    }

    /**
     * Increments the organism's time field by one, never surpassing the value of a day.
     */
    protected void incrementTime(){
        this.time = (time + 1) % Simulator.DAY_LENGTH;
    }

    /**
     * Returns the class type of the organism
     * @return the class type of the organism
     */
    public Class<?> getOrganismClass(){
        return Organism.class;
    }

    /**
     * Sets a given pathogen into the organism
     * @param pathogen
     */
    public void setPathogen( Pathogen pathogen ){
        this.pathogen = pathogen;
    }

    /**
     * Returns whether the organism is infected or not
     * @return
     */
    public boolean isInfected(){
        return this.pathogen != null;
    }

    /**
     * Infects a given organism, with a given pathogen
     * @param infectingPathogen the pathogen that infects an organism
     * @param organism the organism infected
     */
    public void infectOrganism( Pathogen infectingPathogen, Organism organism ){

        if (infectingPathogen == null || organism == null) return;

        if (infectingPathogen.canInfect( organism.getOrganismClass() ))
        {
            organism.setPathogen(infectingPathogen);
        }
    }

    /**
     * Infects an organism sexually, with this organism's pathogen
     * @param organism the organism that is being sexually infected
     */
    public void infectSexually(Organism organism){
        if (!isInfected() || organism == null || pathogen == null) return;

        if (pathogen.transmitsSexuallySuccessfully()){
            infectOrganism(organism);
        }
    }

    /**
     * Infect an organism with this organism's pathogen
     * @param organism the organism to infect
     */
    public void infectOrganism( Organism organism ){
        if ( !isInfected() || organism == null || pathogen == null ) return;
        
        if (this.pathogen.canInfect( organism.getOrganismClass() ))
        {
            organism.setPathogen(this.pathogen);
        }
    }

    /**
     * Make the pathogen act onto this organism, possibly modifying it's integrity.
     */
    protected void pathogenAct(){
        if (this.isInfected()){
            pathogen.affectOrganism(this);

            if (pathogen.doesRecover()){
                pathogen = null;
            }
        }
    }

    /**
     * Returns the hexadecimal string representing the genes, 
     * with a space separating each chromosome.
     * @return the hex string representing the genes.
     */
    public String getGenesString() {
        char[] hexArray = "0123456789ABCDEF".toCharArray();

        //there are 2 hex characters/byte
        char[] hexChar = new char[ this.genes.length*2  ];

        for ( int i = 0; i < this.genes.length; i++ ){
            int b = this.genes[i];

            //make it unsigned
            b = (256 + b)%256;
            
            //get the first byte
            hexChar[2*i] = hexArray[ b >> 4 ];

            //get the second byte (getting rid of the first byte with the bitwise-AND)
            hexChar[2*i + 1] = hexArray[ b & 0x0F ];

        }

        //putting a space every 2 characters, to separate each chromosome
        String hexString = new String(hexChar).replaceAll("..", "$0 ");
        return hexString;
    }

    /**
     * Return the pathogen's class name
     * @return the pathogen's class name
     */
    public String getPathogenName() {
        if (pathogen == null) return "null";

        return pathogen.getClass().getName();
    }
}