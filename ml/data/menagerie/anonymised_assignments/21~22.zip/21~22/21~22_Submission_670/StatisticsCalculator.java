import java.util.Arrays;
/**
 * This class handles statistical calculations.
 *
 * @version 1.0
 */
public class StatisticsCalculator {
    private Double[] data;

    /**
     * Creates StatisticsCalculator object 
     * @param inputData the input data we want from which we extract statistics
     */
    public StatisticsCalculator(Double[] inputData){
        this.data = inputData;
    }

    /**
     * Creates a StatisticCalculator object without the data being set.
     */
    public StatisticsCalculator(){
    }

    /**
     * Get the frequency of a range data point in a data set.
     * 
     * @param countedDataPoint the data point at the center of the range
     * @param delta half of the range
     * @return the frequency of a range of data points in a data set
     */
    public double getDataPointFrequency(double countedDataPoint, double delta){
        double dataPointFrequency = 0;
        for (double dataPoint : data ){
            if ( (countedDataPoint - delta) <= dataPoint && dataPoint <= (countedDataPoint + delta)){
                dataPointFrequency++;
            }
        }

        return dataPointFrequency;
    }

    /**
     * Get the probability that a data point appears inside the data set, 
     * and return it to an array containing all the data in the format :
     * [ data point, probability of occurence ] 
     * 
     * @return the array containing all the probabilities and distinct points.
     */
    public double[][] getProbabilitySpread(){
        Double[] tempData = Arrays.copyOf(data, data.length);
        
        Arrays.stream(tempData).distinct().toArray();           //removes all non-distinct elements
        double[][] newData = new double[tempData.length][];

        //loop through all distinct elements
        for (int dataIndex = 0; dataIndex < tempData.length; dataIndex++){
            double dataPoint = tempData[dataIndex];
            newData[dataIndex] = new double[] { dataPoint, getDataPointFrequency(dataPoint, dataPoint*0.1)/data.length };
        }

        return newData;
    }

    /**
     * Sets the data field to the value given.
     * @param inputData the new data set to the data field
     */
    public void setData(Double[] inputData){
        this.data = inputData;
    }
}
