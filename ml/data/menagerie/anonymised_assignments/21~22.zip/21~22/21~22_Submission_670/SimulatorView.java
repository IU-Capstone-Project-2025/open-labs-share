import java.awt.*;

import javax.swing.*;
import javax.swing.JButton;

import java.awt.event.ActionEvent;

import java.util.LinkedHashMap;
import java.util.Map;

import plot.*;

/**
 * A graphical view of the simulation grid.
 * 
 * The view displays a colored rectangle for each location 
 * representing its contents. It uses a default background color.
 * 
 * Colors for each type of species can be defined using the
 * setColor method.
 *
 * @version 1
 */
public class SimulatorView extends JFrame
{
    // Colors used for empty locations.
    private Color emptyColor = Color.white;

    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;

    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private JLabel stepLabel, population, infoLabel;
    private FieldView fieldView;
    
    // A map for storing colors for participants in the simulation
    private Map<Class<?>, Color> colors;

    // A statistics object computing and storing simulation information
    private FieldStats stats;

    // Whether we can show the window
    private boolean canShow = false;

    //the pause/reset/continue's button's width and height
    private int buttonWidth, buttonHeight;

    //whether the simulation is paused or reset
    private boolean isPaused, isReset;

    //the last viewed organism
    private OrganismView oldOrganismView;

    /**
     * Create a view of the given width and height.
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width, boolean canShow) 
    {
        this.canShow = canShow;

        stats = new FieldStats();
        colors = new LinkedHashMap<>();

        buttonWidth = 20;
        buttonHeight = 16;

        oldOrganismView = null;

        isPaused = false;
        isReset = false;


        setTitle("Simulation of Organisms");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
        
        setLocation(100, 50);
        
        fieldView = new FieldView(height, width);

        Container contents = getContentPane();
        
        JPanel infoPane = new JPanel(new BorderLayout());

        //defines the pausing button, changess its icon when pressed
        JButton pauseButton = new JButton( new AbstractAction() {
            @Override
            public void actionPerformed( ActionEvent e ) {
                Object source = e.getSource();

                if (source instanceof JButton) {
                    Icon icon;
                    JButton button = (JButton) source;

                    isPaused = !isPaused;

                    icon = (isPaused) ?  new ImageIcon(".\\icons\\continue_button.png") : 
                                            new ImageIcon(".\\icons\\pause_button.png");

                    icon = resizeIcon(icon, buttonWidth, buttonHeight);
                    button.setIcon(icon);  
                }
            
            }
        });

        JButton resetButton = new JButton( new AbstractAction() {
            @Override
            public void actionPerformed( ActionEvent e ) {
                isReset = true;  
            }
        });

        paintButton(infoPane, pauseButton ,".\\icons\\pause_button.png", 
                    fieldView.getPreferredSize().width - buttonWidth*3/2, 0);

        paintButton(infoPane, resetButton,".\\icons\\reset_button.png", 
                    fieldView.getPreferredSize().width - buttonWidth*5/2, 0);

        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(infoLabel, BorderLayout.CENTER);
        contents.add(infoPane, BorderLayout.NORTH);
        contents.add(fieldView, BorderLayout.CENTER);
        contents.add(population, BorderLayout.SOUTH);

        pack();
        setVisible(canShow);
    }


    /**
     * Paints a button onto the given JPanel with a given icon that is resized
     * to fit the button.
     * 
     * @param panel the JPanel onto which we want to paint on
     * @param button the JButton that we want to draw
     * @param buttonIconPath the path to the button's icon
     * @param x the x-coordinate of the button
     * @param y the y-coordinate of the button
     */
    private void paintButton( JPanel panel, JButton button, String buttonIconPath ,int x, int y)
    { 
        Icon icon = new ImageIcon(buttonIconPath);
        icon = resizeIcon(icon, this.buttonWidth, this.buttonHeight);

        button.setIcon(icon);
        
        button.setBounds(x, y, this.buttonWidth, this.buttonHeight);
        
        //this is to add the button freely
        panel.setLayout(null);
        panel.add(button);

        panel.setLayout(new BorderLayout());
    }

    /**
     * Resizes a given Icon object to match the width and height desired.
     * @param icon the icon we want to resize
     * @param width the new width of the icon
     * @param height the new height of the icon
     * @return the new resized icon
     */
    private Icon resizeIcon(Icon icon, int width, int height){

        Image img = ((ImageIcon) icon).getImage();  
        Image newimg = img.getScaledInstance( this.buttonWidth, this.buttonHeight,  java.awt.Image.SCALE_SMOOTH );
          
        return new ImageIcon( newimg );
    }

    /**
     * Returns true if the simulation is paused with the button.
     * @return true if the simulation is paused with the button.
     */
    public boolean getIsPaused(){
        return this.isPaused;
    }

    /**
     * Returns true if the simulation is reset with the button.
     * @return true if the simulation is reset with the button.
     */
    public boolean getIsReset(){
        return this.isReset;
    }

    public void toggleIsReset(){
        this.isReset = !this.isReset;
    }
    
    /**
     * Define a color to be used for a given class of object.
     * @param objectClass The object's Class object.
     * @param color The color to be used for the given class.
     */
    public void setColor(Class<?> objectClass, Color color)

    {
        colors.put(objectClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text)
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of object.
     */
    private Color getColor(Class<?> objectClass)
    {
        Color col = colors.get(objectClass);
        if(col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        }
        else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * @param step Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field)
    
    {

        if( !isVisible() && canShow ) {
            //uncomment if one desires to see the day/night cycle
            //setEmptyColor(step)

            setVisible(true);
        }
            
        stepLabel.setText(STEP_PREFIX + step);
        fieldView.preparePaint();

        stats.reset();

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                 Object object = field.getObjectAt(row, col);
                 if(object != null) {
                    stats.incrementCount(object.getClass());
                    Color objectColor = getColor(object.getClass());

                    if (object instanceof Organism){
                        Organism organism = (Organism) object;
                        
                        //if the organism is infected show it with a darker shade of the 
                        //organism's original color
                        if (organism.isInfected())
                        {
                            objectColor = objectColor.darker().darker().darker();
                        }

                        fieldView.drawMark(col, row, objectColor);
                    }
                }
                else {
                    fieldView.drawMark(col, row, emptyColor);
                }
            }
        }

        stats.countFinished();
        stats.updatePopulationNumbers(step);

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Sets the empty color depending on the time of day.
     * If it's day (first half of the day) set it to white.
     * If it's night (second half of the day) set it to black.
     *  
     * @param steps the number of steps the simulation ran so far
     */
    public void setEmptyColor( int steps ){
        if (steps%Simulator.DAY_LENGTH < Simulator.DAY_LENGTH / 2){
            this.emptyColor = Color.WHITE;
        }else{
            this.emptyColor= Color.BLACK;
        }
    }

    /**
     * Shows the graph of the organism's populations against total steps elapsed.
     */
    public void showPopulationGraph(){
        Plotter plotter = new Plotter( Data.getPackagedData(colors, stats.getPopulationNumebers()), 
                                       "Population against Time", "Time elapsed (steps)", 
                                       "Population count");
        
        plotter.toggleShowPoints();
        plotter.showLegend();

        plotter.setVisible(true);
    }

    /**
     * Resets the population counts
     */
    public void resetPopulationCounts(){
        stats.resetPopulationCounts();
    }

    /**
     * Returns whether the mouse's left button has been clicked
     * @return whether the mouse's left button has been clicked
     */
    public boolean mouseClicked(){
        return fieldView.isMouseClicked();
    }

    /**
     * Get the object on the field grid selected by the mouse.
     * @param field the current field
     * @return the object selected by the mouse
     */
    public Object getClickedObject(Field field){

        fieldView.preparePaint();

        int xScale = fieldView.getXScale();
        int yScale = fieldView.getYScale();

        int mouseX, mouseY;

        //if it's outside the window's boundaries return null
        try{
            mouseX = this.getMousePosition().x - xScale;
            mouseY = this.getMousePosition().y - buttonHeight*2 - 2*yScale;
        }catch (Exception e){
            return null;
        }

        //here we calculate the correct rows and cols
        int col = (int) (mouseX*Math.ceil( (double) ((double) xScale) / (double) mouseX) - mouseX%xScale);
        int row = (int) (mouseY*Math.ceil( (double) ((double) yScale) / (double) mouseY) - mouseY%yScale);

        row = Math.round(row/yScale);
        col = Math.round(col/xScale);

        return field.getObjectAt( new Location(row, col) );
    }

    /**
     * Show the information of an organism being selected by the mouse.
     * @param field the current field of the simulation
     */
    public void showOrganismInformation(Field field){
        
        Object clickedObject = getClickedObject(field);

        if (clickedObject instanceof Organism){
            Organism clickedOrganism = (Organism) clickedObject;
            Color color = colors.get(clickedObject.getClass());
            
            OrganismView orgView = new OrganismView( clickedOrganism, color );
            if ( oldOrganismView != null) oldOrganismView.setVisible(false);

            orgView.setVisible(true);

            this.oldOrganismView = orgView;
        }

    }


    /**
     * Determine whether the simulation should continue to run.
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    
    /**
     * Provide a graphical view of a rectangular field. This is 
     * a nested class (a class defined inside a class) which
     * defines a custom component for the user interface. This
     * component displays the field.
     * This is rather advanced GUI stuff - you can ignore this 
     * for your project if you like.
     */
    private class FieldView extends JPanel
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;

        Dimension size;

        private Graphics g;
        private Image fieldImage;

        MyMouseListener listener;           //the object listening to the mouse's actions

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width)
        {
            gridHeight = height;
            gridWidth = width;

            size = new Dimension(0, 0);

            listener = new MyMouseListener();
            this.addMouseListener(listener);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize()
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR,
                                 gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Return true if mouse's left button has been clicked.
         * @return true if mouse's left button has been clicked.
         */
        public boolean isMouseClicked()
        {
            if (listener.didLeftButtonClick()){
                listener.toggleLeftButtonClicked();
                return true;
            }

            return false;
        }

        /**
         * Prepare for a new round of painting. Since the component
         * may be resized, compute the scaling factor again.
         */
        public void preparePaint()
        {
            if(! size.equals(getSize())) {  // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if(xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if(yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }
        
        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color)
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale-1, yScale-1);
        }
         

        /**
         * The field view component needs to be redisplayed. Copy the
         * internal image to screen.
         */
        public void paintComponent(Graphics g)
        {
            if(fieldImage != null) {
                Dimension currentSize = getSize();
                if(size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                }
                else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }

        /**
         * Returns the xScale value.
         * @return the xScale value.
         */
        public int getXScale(){
            return this.xScale;
        }

        /**
         * Returns the yScale value.
         * @return the yScale value.
         */
        public int getYScale(){
            return this.yScale;
        }
    }
}