import java.util.List;
/**
 * A simple model for the plant.
 * Plant may grow, and every time they grow a new leaf, that leaf
 * has a depth of the original plant + 1.
 * 
 * Thus plants can grow up to certain sizes and with branch extending from 
 * their leaves.
 *
 * @version 1
 */
public abstract class Plant extends Organism
{
    // the rate of reproduction for plants
    private double plantReproductionProbability;

    // the probability of a plant being digested
    private double digestionProbability;

    //how much the plant can extend from the bush of depth 0
    private int maxPlantExtension;

    //how many leaves the plant can make at one time
    private int maxLeafSize;

    //how much the plant can extend from the bush of depth 0
    private int maxBranchExtension;

    //how far away the plant is from the original plant that birthed it of depth 0.
    private int depth;

    //how fast the plant grows, effectively how many steps it takes for a plant to grow.
    private int growthRate;
    
    /**
     * Create a new plant, providing the current field,
     * new location and depth.
     * 
     * @param field the current field of the simulation
     * @param location the location of the new plant
     * @param depth the depth of the new plant
     */
    public Plant(Field field, Location location, int depth) {
        super(field, location, null, null);
        this.depth = depth;
        assignQualities();

        setLocation(location);
    }

    /**
     * Assigns the various qualities specific to a plant from the plant's
     * sub-class.
     */
    public void assignQualities(){
        double[] plantAttributes = getPlantAttributes();
       
        plantReproductionProbability = plantAttributes[0];
        digestionProbability = plantAttributes[1];
        maxLeafSize = (int) plantAttributes[2];
        maxPlantExtension = (int) plantAttributes[3];
        maxBranchExtension = (int) plantAttributes[4];
        growthRate = (int) plantAttributes[5];

    }

    /**
     * Returns the attributes of the plant (e.g : the reproduction probability...)
     * @return the attributes of the plant
     */
    abstract double[] getPlantAttributes();

    /**
     * This is what plant do most of the time : grow.
     * 
     * @param newPlants a list to return newly born plants
     */
    protected void act(List<Organism> newPlants){
        pathogenAct();

        //creates new plants if its alive and at a fixed rate 
        if (isAlive() && (this.time % growthRate == 0)){
            plantMayReproduce(newPlants);
        }
    }

    /**
     * Check whether or not this plant is to make new plants at this step.
     * New plants will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     */
    protected void plantMayReproduce(List<Organism> newPlants)
    {
        // New plants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = reproduce();

        for(int b = 0; b < births && free.size() > 0; b++) {

            Location loc = free.remove(0);
            Organism young = createOffspring(field, loc, this.depth+1);
            newPlants.add( young );

            //here a plant may decide to extend into a branch
            Location oldLocation = this.getLocation();

            //the length of the plant's branch
            int branchExtension = rand.nextInt(maxBranchExtension);

            for (int i = 1; i < branchExtension; i++){

                //the direction onto which the plant extends towards
                int[] direction = oldLocation.getDirection(young.getLocation());

                int youngRow = young.getLocation().getRow();
                int youngCol = young.getLocation().getCol();

                //extend the branch onto one direction
                //if its not availbale stop growing the branch
                Location newLocation = new Location( youngRow + direction[0], youngCol + direction[1]);
                
                if (field.isLocationFree(newLocation)){
                    young = createOffspring(field, newLocation, this.depth+i);
                    newPlants.add(young);
                    b++;

                }else{
                    break;
                }
            }

            //the probability of reproducing again is halved every time 
            plantReproductionProbability /= 2;

        }
    }


    /**
     * Generate a number representing the number of births,
     * if it can reproduce.
     * @return The number of new plants (may be zero).
     */
    private int reproduce()
    {
        int births = 0;
        if(canReproduce() && rand.nextDouble() <= plantReproductionProbability) {
            births = rand.nextInt(maxLeafSize) + 1;
        }
        return births;
    }

    /**
     * Returns whether the plant has been digested or not.
     * @return whether the plant has been digested or not.
     */
    public boolean hasBeenDigested(){
        return rand.nextDouble() <= digestionProbability;
    }

    /**
     * An animal can breed if it has reached the breeding age, and there is a partner nearby.
     * @return true if the animal can breed, false otherwise.
     */
    private boolean canReproduce()
    {
        return depth < maxPlantExtension;
    }

    /**
     * Returns whether it drops seeds or not, in this case only the plants
     * of depth 0 can.
     * @return whether it drops seeds or not.
     */
    public boolean dropsSeeds()
    {
        return depth < 1;
    }

    /**
     * Create a new plant, providing the current field,
     * new location and depth.
     * 
     * @param field the current field of the simulation
     * @param location the location of the new plant
     * @param depth the depth of the new plant
     */
    public abstract Organism createOffspring(Field field, Location location, int depth);

    /**
     * Return the depth of the plant.
     * @return the depth of the plant.
     */
    public int getDepth(){
        return depth;
    }

    /**
     * Return the growth rate of the plant.
     * @return the growth rate of the plant
     */
    public int getGrowthRate(){
        return growthRate;
    }
}
