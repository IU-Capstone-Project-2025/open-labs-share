import java.util.Random;

/**
 * A simple class to represent a pathogen.
 * Pathogens can infect organisms, affecting their age, sleep patterns and 
 * hunger.
 *
 * @version 1
 */
public abstract class Pathogen {

    protected static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Pathogen.
     */
    public Pathogen(){
    }

    /**
     * How the pathogen affects the organism it infects.
     * It can affect its age, hunger or sleep patterns if its an animal.
     * If its a plant then it can affect other properties.
     * @param organism teh organism the pathogen is affecting.
     */
    public void affectOrganism(Organism organism){
        //if the pathogen can attack the organism
        if (this.canAttack(organism.getOrganismClass())){
            if (organism instanceof Animal){
                Animal animal = (Animal) organism;

                if (this.affectsAge())
                {
                    animal.offsetAge(this.affectsAgeModifier());
                }else if (this.affectsHunger())
                {
                    animal.offsetHunger(this.affectsHungerModifier());
                }else if (this.affectsSleep())
                {
                    animal.offsetSleep(this.affectsSleepModifier());
                }
            }
        }        
    }

    /**
     * Returns whether the pathogen affects age.
     * @return whether the pathogen affects age.
     */
    private boolean affectsAge(){
        return this.affectsAgeModifier() > 0;
    }

    /**
     * Returns whether the pathogen affects hunger.
     * @return whether the pathogen affects hunger.
     */
    private boolean affectsHunger(){
        return this.affectsHungerModifier() > 0;
    }

    /**
     * Returns whether the pathogen affects sleep.
     * @return whether the pathogen affects sleep.
     */
    private boolean affectsSleep(){
        return this.affectsSleepModifier() > 0;
    }

    /**
     * Returns the default age modifier which is 0.
     * @return the default age modifier which is 0.
     */
    protected int affectsAgeModifier(){
        return 0;
    }

    /**
     * Returns the default hunger modifier which is 0.
     * @return the default hunger modifier which is 0.
     */
    protected int affectsHungerModifier(){
        return 0;
    }

    /**
     * Returns the default sleep modifier which is 0.
     * @return the default sleep modifier which is 0.
     */
    protected int affectsSleepModifier(){
        return 0;
    }

    /**
     * Returns whether it can be transmitted sexually.
     * @return whether it can be transmitted sexually.
     */
    private boolean canBeTransmittedSexually(){
        return this.getSexualTransitivityProbability() > 0;
    }

    /**
     * Returns the probability of transmitting sexually, by default 0;
     * @return the probability of transmitting sexually, by default 0;
     */
    protected double getSexualTransitivityProbability(){
        return 0;
    }

    /**
     * Returns whether the organism can recover from a pathogen, by default true.
     * @return whether the organism can recover from a pathogen, by default true.
     */
    public boolean doesRecover(){
        return true;
    }

    /**
     * Returns the probability of attacking the host's qualities (e.g age, hunger...).
     * @param hostType the class type of the organism we are checking
     * @return probability of infecting an organism
     */
    protected abstract double getHostAttackRate(Class<?> hostType);

    /**
     * Returns whether the pathogen has been transmitted sexually successfully.
     * @return whether the pathogen has been transmitted sexually successfully.
     */
    public boolean transmitsSexuallySuccessfully(){
        if (!this.canBeTransmittedSexually()) return false;
        return rand.nextDouble() <= this.getSexualTransitivityProbability();
    }

    /**
     * Returns whether a pathogen can affect an organism's qualities.
     * @param hostType the class type of the host
     * @return whether a pathogen can affect an organism's qualities.
     */
    private boolean canAttack(Class<?> hostType){
        return rand.nextDouble() <= this.getHostAttackRate( hostType ); 
    }

    /**
     * Returns whether a pathogen can infect an organism given its class type,
     * false by default.
     * 
     * @param hostType the type of the organism tha pathogen wants to infect
     * @return  whether a pathogen can infect an organism given its class type, 
     * false by default.
     */
    public boolean canInfect(Class<?> hostType){
        return false;
    }

    /**
     * Creates a new pathogen object, specific to each sub-class.
     * @return a new pathogen object specific to each sub-class.
     */
    public abstract Pathogen newPathogen();
}
