import java.awt.Color;

/**
 * This class holds information about a certain organism :
 * it's subclass type, the color that is represented with on the field grid,
 * its probability of creation and an organism without location.
 *
 * @version 1.0
 */
public class OrganismInformation { 

    private Class<?> organismType;
    private Color organismColor;

    private double organismCreationProbability;
    private Organism nullOrganism;          //organism without location

    /**
     * Creates an OrganismInformation object
     * @param organismType the sub-class type of the organism
     * @param organismColor the color that it exhibits onto the field grid
     * @param organismCreationProbability the probability of being created at the start of the simulation
     * @param nullOrganism an organism object of class organismType without location
     */
    public OrganismInformation(Class<?> organismType, Color organismColor, 
                               double organismCreationProbability, Organism nullOrganism)
    {  
        
        this.organismType = organismType;
        this.organismColor = organismColor;
        this.organismCreationProbability = organismCreationProbability;
        this.nullOrganism = nullOrganism;

    }

    /**
     * Returns the sub-class type of the organism.
     * @return the sub-class type of the organism.
     */
    public Class<?> getOrganismType(){
        return this.organismType;
    }

    /**
     * Returns the color of the organism.
     * @return the color of the organism.
     */
    public Color getColor(){
        return this.organismColor;
    }

    /**
     * Return the creation probability of the organism.
     * @return the creation probability of the organism.
     */
    public double getOrganismCreationProbability(){
        return this.organismCreationProbability;
    }

    /**
     * Sets the creation probability of the organism to the one given
     * @param newProbability the new creation probability of the object
     */
    public void setOrganismCreationProbabilty(double newProbability) {
        this.organismCreationProbability = newProbability;
    }

    /**
     * Returns the null organism object
     * @return the null organism object
     */
    public Organism getNullOrganism(){
        return this.nullOrganism;
    }

    /**
     * Returns the name of the organism sub-class type
     * @return the name of the organism sub-class type
     */
    public String getOrganismName(){
        return this.organismType.getName();
    }
}
