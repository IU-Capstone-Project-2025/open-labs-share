/**
 * Its a type of plant.
 *  * The herbivores feeds from plants, which here it means corn is food for GrassHoppers
 */
public class Corn extends Plant{

    private static final  int GROWTH_RATE = 7;

    public Corn(boolean randomAge, Field field, Location location){
        super(randomAge, field, location);
    }

    /**
     * Gets growth rate
     * @return
     */
    public int getGrowthRate(){
       return GROWTH_RATE;
    }

}

