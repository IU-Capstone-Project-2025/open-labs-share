import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * A class representing shared characteristics of Organisms.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Organism
{

    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;

    // An array of all possible diseases an animal can have.
    protected static final Disease[] DISEASES = {new Disease("zbd", 5), new Disease("marg", 2)};

   // A list of diseases an animal is currently infected with.
    private List<Disease> diagnoses;

    // A random object to randomize certain behaviour.
    private static final Random rand = new Random();

    // The organism's current age;
    protected int age;



    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param randomAge Whether the created animal starts out with a random age.
     */
    public Organism(Field field, Location location, boolean randomAge)
    {

        alive = true;
        this.field = field;
        setLocation(location);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());
        }
        else {
            age = 0;
        }
        diagnoses = new ArrayList<>();
    }

    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param day The time of the day for the animal to act accordingly.
     * @param weather The current weather of the simulation.
     */
    abstract public void act(List<Animal> newAnimals, boolean day, String weather);

    /**
     * Returns true or false if this organism is infected with the passed in disease.
     * @param infection The disease to compare the animals current infections to.
     * @return True of False
     */
    public boolean isInfectedWith(Disease infection){
        if (diagnoses != null) {
            for (Disease disease : diagnoses) {
                if (infection.equals(disease)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Infects the animal with the given disease
     * @param disease The disease with which the animal will be infected with.
     */
    public void infect(Disease disease){
        diagnoses.add(disease);
    }

    /**
     * Increments the severity of all the organism's diseases.
     * The organism is will die if the disease has reached its max severity.
     */
    public void increaseInfectionSeverity(){

            for (Disease disease : diagnoses) {
                if (disease.isAtMaxSeverity()) {
                    setDead();
                } else {
                    disease.incrementSeverity();
                }
            }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }


    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }

    }


    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Increase the age. This could result in the organism's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }






    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * abstract getter, gets the age of a specific organism.
     * @return The age of a specific organism.
     */
    abstract public int getMaxAge();
}
