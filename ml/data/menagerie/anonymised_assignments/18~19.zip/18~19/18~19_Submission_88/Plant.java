import java.util.List;

public abstract class Plant extends Organism{
    private static final int MAX_AGE = 4000;

    private int size;

    /**
     *
     * @param randomAge
     * @param field
     * @param location
     */
    public Plant(boolean randomAge, Field field, Location location){
        super(field, location, randomAge);
        size = 2;
    }

    /**
     *
     * @param newAnimals A list to receive newly born animals.
     * @param day The time of the day for the animal to act accordingly.
     * @param weather The current weather of the simulation.
     */
    @Override
    public void act(List<Animal> newAnimals, boolean day, String weather) {
        if (day) {
            grow(weather);
        }
    }

    /**
     *
     * @param weather
     */
    private void grow(String weather){
        if (weather.equals("Snowy")) {
            size += getGrowthRate()/2;
        } else if (weather.equals("Rainy")){
            size += getGrowthRate()*2;
        } else {
            size += getGrowthRate();
        }
    }

    /**
     *
     * @return
     */
    @Override
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     *
     */
    public void decrementSize(){
        size--;
    }

    /**
     *
     * @return
     */
    public int getSize(){
        return size;
    }
    public abstract int getGrowthRate();
}