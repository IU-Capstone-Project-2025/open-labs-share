public class Disease {
    private String name;
    private int severity;
    private int maxSeverity;

    /**
     * Initialise the name, severity and max Severity of the diseases.
     * @param name
     * @param maxSeverity
     */
    public Disease(String name, int maxSeverity){
        this.name = name;
        this.severity = 0;
        this.maxSeverity = maxSeverity;
    }

    /**
     * increments the severity of the diseases.
     */
    public void incrementSeverity(){
        severity++;
    }

    /**
     * checks if the severity is at maximum.
     * @return true if severity is at max, false otherwise.
     */
    public boolean isAtMaxSeverity(){
        return severity >= maxSeverity;
    }

    /**
     * returns the name of the diseases
     * @return returns name of the diseases
     */
    public String getName(){
        return name;
    }
}
