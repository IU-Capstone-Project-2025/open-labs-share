import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class Herbivore extends Animal {

    /**
     * Constructor for a Herbivore. Calls the super class's constructor.
     * @param randomAge
     * @param field
     * @param location
     */
    public Herbivore(boolean randomAge, Field field, Location location)
    {
       super(field, location, randomAge);


    }

    /**
     * This is what the Herbivore does most of the time: it feeds.
     * In the process, it might breed, die of hunger,
     * or die of old age.
     * @param newAnimals A list to return newly born Cougares.
     * @param day
     */
    @Override
    public void act(List<Animal> newAnimals, boolean day, String weather)
    {
        incrementAgeHunger();
        super.act(newAnimals, day, weather);
    }

    /**
     * The herbivore tries to look for plants nearby to feed on.
     * @param weather
     * @return
     */
    @Override
    public Location findFood(String weather) {

        Set<Object> surroundingObjects = getSurroundingObjects();
        for (Object object : surroundingObjects)
            if (object instanceof  Plant) {
                Plant plant = (Plant) object;
                eat(plant);
                return getLocation();
                }
            return null;
    }

    //ABSTRACT METHODS


    abstract public void eat(Plant plant);
    abstract public double getBreedingProb();
    abstract public int getBreedingAge();
    abstract public int getMaxAge();
    abstract public int getMaxLitter();
    abstract public Animal createAnimal(Field field, Location loc);

}