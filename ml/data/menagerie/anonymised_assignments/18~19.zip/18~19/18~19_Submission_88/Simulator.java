import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a fox will be created in any given grid position.
    private static final double COUGAR_CREATION_PROBABILITY = 0.05;
    // The probability that a rabbit will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.07;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.09;
    // The probability that a rabbit will be created in any given grid position.
    private static final double LIZARD_CREATION_PROBABILITY = 0.11;
    // The probability that a rabbit will be created in any given grid position.
    private static final double GRASSHOPPER_CREATION_PROBABILITY = 0.13;

    private static final double CRICKET_CREATION_PROBABILITY = 0.15;

    private static final double CORN_CREATION_PROBABILITY = 0.16;

    private static final double CARROT_CREATION_PROBABILITY = 0.17;

    private static final String[] WEATHER = {"Rainy", "Sunny", "Snowy"};

    // List of animals in the field.
    private List<Organism> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Time of the day
    private boolean day;
    private String weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     *
     * @param args
     */
    public static void main(String args[]){
        Simulator sim1 = new Simulator(100, 150);
        sim1.simulate(1000);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Cougar.class, new Color(74,24,11));
        view.setColor(Fox.class, new Color(9, 209, 255));
        view.setColor(Rabbit.class, new Color(200, 50, 200));
        view.setColor(Cricket.class, new Color(203, 0, 7));
        view.setColor(GrassHopper.class, new Color(46, 220, 0));
        view.setColor(Lizard.class, new Color(0, 0, 100));
        view.setColor(Carrot.class, new Color(248, 118, 0));
        view.setColor(Corn.class, new Color(255, 251, 0));


        day = true;
        weather = WEATHER[0];

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(50);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    private void simulateOneStep()
    {
        step++;
        setTime();
        setWeather();
        view.setNight(day);

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Organism> it = animals.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newAnimals, day, weather);
            if(! organism.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born foxes and rabbits to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }

    /**
     * Determines the current time of the simulation.
     */
    private void setTime(){
        int time = step % 18;
        if (time > 12) {
            day = false;
        } else {
            day = true;
        }
    }

    /**
     * Determines the weather of the simulation every 33 steps.
     */
    public void setWeather(){
        Random rand = new Random();
        if (step % 33 == 0) {
            weather = WEATHER[rand.nextInt(3)];
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with all animal kinds species.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= COUGAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cougar cougar = new Cougar(true, field, location);
                    animals.add(cougar);
                }
                else if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fox fox = new Fox(true, field, location);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Rabbit rabbit = new Rabbit(true, field, location);
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= LIZARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lizard lizard = new Lizard(true, field, location);
                    animals.add(lizard);
                }
                else if(rand.nextDouble() <= GRASSHOPPER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    GrassHopper grassHopper = new GrassHopper(true, field, location);
                    animals.add(grassHopper);
                }
                else if(rand.nextDouble() <= CRICKET_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cricket cricket = new Cricket(true, field, location);
                    animals.add(cricket);
                }
                else if (rand.nextDouble() <= CORN_CREATION_PROBABILITY ){
                    Location location = new Location(row, col);
                    Plant plant = new Corn(true, field, location);
                    animals.add(plant);
                }
                else if (rand.nextDouble() <= CARROT_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Plant plant = new Carrot(true, field, location);
                    animals.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    public double rowColCheck(int row, int col){
       if (row > field.getDepth()/2 && col > field.getWidth()/2){
           return 0.10;
       } else {
           return 0;
       }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}

