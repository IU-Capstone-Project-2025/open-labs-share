import java.util.*;
import java.util.stream.Collectors;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Organism
{


    //Random object for the generation of random values.
    private static final Random rand = new Random();
    //The animal's gender.
    private boolean male;

    //The amount of food an animal has acquired.
    protected int foodLevel;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, boolean randomAge)
    {
        super(field, location, randomAge);
        male = rand.nextDouble() < 0.5;
        if (rand.nextDouble() < 0.005){
            infect(DISEASES[0]);
        }
        if (rand.nextDouble() < 0.003){
            infect(DISEASES[1]);
        }

    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param day
     */
    public void act(List<Animal> newAnimals, boolean day, String weather) {
        if (isAlive()) {
            spreadDisease();
            giveBirth(newAnimals, weather);
            // Move towards a source of food if found.
            Location newLocation = findFood(weather);
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                setLocation(newLocation);
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This method increments the animals age, hunger and if infected, disease severity.
     */
    public void incrementAgeHunger(){
        incrementAge();
        incrementHunger();
        increaseInfectionSeverity();
    }


    /**
     * Returns true or false depending on the animal's gender.
     * @return True if animal is a male.
     */
    public boolean isMale(){
        return male;
    }


     /**
     * Check whether or not this Animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born Animals.
     * @param weather  The current weather of the simulation so animals can behave appropriately.
     */
    protected void giveBirth(List<Animal> newAnimals, String weather)
    {
        if  (isMale() && findMate()) {
            // New Animals are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            int births = breed(weather);
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                newAnimals.add(createAnimal(field, loc));
            }
        }
    }


    /**
     * Spreads the first disease. If animals are close enough to each other,
     * there is a 1/3 chance that surrounding animals will also be infected with the disease.
      */
    public void spreadDisease(){
        Set<Object> adj = getSurroundingObjects();
        for (Object animal : adj){
            if (animal instanceof Organism){
                if (((Organism) animal).isInfectedWith(DISEASES[0])){
                    if (rand.nextDouble() < 0.33) {
                        infect(DISEASES[0]);
                    }
                }
            }
        }
    }

    /**
     * Tries to find a mate to reproduce with.
     * The mate is found only if it exists in neighbouring cells to this animal and is also of the same species.
     * and is made sure to be a female. There is also a chance of STD spreading by this method.
     * @return True if suitable mate was found.
     */
    public boolean findMate(){
        List<Location> adjacentLocs = field.adjacentLocations(location).stream().filter(Objects::nonNull).collect(Collectors.toList());
        for (Location loc : adjacentLocs){
            Object x = field.getObjectAt(loc);
            if (x != null && x.getClass() == this.getClass()) {
                Animal animal = (Animal) field.getObjectAt(loc);
                if (!animal.isMale()){
                    if (isInfectedWith(DISEASES[1])){
                        animal.infect(DISEASES[1]);
                    }
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed(String weather)
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProb()) {
            if (weather.equals("Snowy")) {
                births = rand.nextInt(2*(getMaxLitter())/3 + 1);
            } else {
                births = rand.nextInt(getMaxLitter() + 1);
            }


        }
        return births;
    }


    /**
     * Returns whether the animal is capable of breeding. As in, it having reached its breeding age.
     * @return True of False.
     */
    public boolean canBreed(){
        return age >= getBreedingAge();
    }

    /**
     * Make this Animal more hungry. This could result in the Animal's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if( foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Return a set of all adjacent Objects to this animal.
     * @return Set of Objects.
     */
    public Set<Object> getSurroundingObjects(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Set<Object> objectsAround = new HashSet<>();
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()){
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if (organism != null){
                objectsAround.add(organism);
            }
        }
        return objectsAround;

    }

    //ABSTRACT METHODS

    /**
     * Abstract method. Carnivores and Herbivores have different ways of finding food.
     * @param weather
     * @return
     */
    abstract public Location findFood(String weather);

    /**
     * Abstract method. Returns the species's breeding probability.
     * @return
     */
    abstract public double getBreedingProb();

    /**
     * Abstract method. Returns the species's max age.
     *
     * @return
     */
    abstract public int getMaxAge();

    /**
     * Abstract method. Returns the species's breeding age.
     *
     * @return
     */
    abstract public int getBreedingAge();

    /**
     * Abstract method. Returns the species's max number of births.
     * @return
     */
    abstract public int getMaxLitter();

    /**
     * Abstract method. Creates a new animal of the same species.
     * @return
     */
    abstract public Animal createAnimal(Field field, Location loc);
}
