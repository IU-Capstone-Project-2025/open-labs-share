import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Cougar.
 * Cougares age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Cougar extends Carnivore {
    // Characteristics shared by all Cougares (class variables).

    // The age at which a Cougar can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which a Cougar can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a Cougar breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Cougar can go before it has to eat again.
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();


    // Individual characteristics (instance fields).

    /**
     * Create a Cougar. A Cougar can be created as a new born (age zero
     * and not hungry) or with a random age.
     *
     * @param randomAge If true, the Cougar will have random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Cougar(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location);
        foodLevel = rand.nextInt(FOX_FOOD_VALUE);

    }

    /**
     * Returns the Cougar's max age.
     * @return
     */
    public int getMaxAge() {
        return MAX_AGE;
    }

    /**
     * Returns the Cougar's breeding age.
     * @return
     */
    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * Returns the likelihood of the cougar to breed.
     * @return
     */
    public double getBreedingProb() {
        return BREEDING_PROBABILITY;
    }

    /**
     * Returns the maximum number of children a cougar can have.
     * @return
     */
    public int getMaxLitter() {
        return MAX_LITTER_SIZE;
    }

    /**
     * Create a new Cougar with age 0 and the specified location with the specified field.
     * @param field
     * @param loc
     * @return returns the newly created Cougar.
     */
    public Animal createAnimal(Field field, Location loc){
        return new Cougar(false, field, loc);
    }

    /**
     * Tries to eat the object given that the object is either a fox or a rabbit.
     * @param loc
     * @param animal
     * @return
     */
    public Location eat(Location loc, Object animal) {
        if (animal instanceof Fox) {
            Fox fox = (Fox) animal;
            if (fox.isAlive()) {
                fox.setDead();
                foodLevel += FOX_FOOD_VALUE;
                return loc;
            }

        } else if (animal instanceof Rabbit) {
            Rabbit rabbit = (Rabbit) animal;
            if (rabbit.isAlive()) {
                rabbit.setDead();
                foodLevel += RABBIT_FOOD_VALUE;
                return loc;
            }
        }
        return null;
    }
}





    


