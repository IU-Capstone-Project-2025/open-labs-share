import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 * Animals belong to a location in a field. They have an age,
 * and can be either male or female, and infected or not
 * infected.
 *
 * @version 
 */
public abstract class Animal
{
    // The probability that the animal is female.
    protected static final double FEMALE_PROBABILITY = 0.5;
    // The probability that the animal is struck by lightning and dies.
    protected static final double LIGHTNING_DEATH = 0.02;
    
    // The animal's position in the field.
    private Location location;
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's sex.
    private boolean isFemale;
    // The animal's age.
    private int age;
    // Whether or not the animal is infected by disease.
    private boolean infected;
    
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param randomAge If true, the animal will have random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(boolean randomAge, Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        if(randomAge) {
            age = rand.nextInt(getMaxAge());            
        }
        else {
            age = 0;
        }
        if(rand.nextDouble() < FEMALE_PROBABILITY){
            isFemale = true;
        }
        else{
            isFemale = false;
        }
    }

    /**
     * Make this organism act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive new organisms.
     * @param isNight A boolean to check if it is currently night in the simulation.
     * @param weather A string that states the current weather in the simulation.
     */
    abstract public void act(List<Animal> newAnimals, boolean isNight, String weather);

    /**
     * Get the animal's breeding age.
     */   
    abstract public int getBreedingAge();
    
    /**
     * Get the animal's maximum age.
     */  
    abstract public int getMaxAge();
    
    /**
     * Get the animal's breeding probability.
     */ 
    abstract public double getBreedingProbability();
    
    /**
     * Get the animal's maximum litter size.
     */ 
    abstract public int getMaxLitterSize();
    
    /**
     * Check whther or not the adjacent animal is a 
     * compatible mate.
     */
    abstract public boolean adjCompatibleMate();
    
    /**
     * Create new instances of the animal.
     */
    abstract public Animal createYoung(Field field, Location loc);
    
    /**
     * Increase the age. This could result in the animal's death
     * if it reaches its maximum age.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * Infect the animal with disease by setting infected 
     * to true.
     */
    protected void infect()
    {
        infected = true;
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the animal is female or not.
     * @return true if the animal is female.
     */
    protected boolean isFemale()
    {
        return isFemale;
    }
    
    /**
     * Check whether the animal is infected or not.
     * @return true if the animal is infected.
     */
    protected boolean isInfected()
    {
        return infected;
    }

    /**
     * Return the animal's current age.
     * @return the animal's current age.
     */
    protected int getAge()
    {
        return age;
    }
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the breeding age is equal to or larger 
     * than the animal's current age.
     */
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && adjCompatibleMate() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Return the field's field.
     * @return The field's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        Field field = getField();
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    public void giveBirth(List<Animal> newAnimals)
    {
        // New animals are born into adjacent locations.
        // Get a list of adjacent free locations.
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            newAnimals.add(createYoung(field, loc));
        }
    }
}
