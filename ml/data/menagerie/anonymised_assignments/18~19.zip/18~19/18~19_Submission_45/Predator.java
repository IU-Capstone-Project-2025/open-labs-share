/**
 * A Predator is an Animal that eats other Animals.
 * It has a food level, unlike its prey. If its food level
 * decreases to zero, it dies.
 *
 * @version 2019.02.20
 */
public abstract class Predator extends Animal
{
    // The predator's food level, which is increased by eating its prey.
    private int foodLevel;

    /**
     * Create a new predator at location in field.
     * 
     * @param randomAge If true, the predator will have random age and foodlevel.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        if(randomAge) {
            foodLevel = rand.nextInt(getMaxFoodLevel());
        }
        else {
            foodLevel = getMaxFoodLevel();
        }
    }

    /**
     * Get the predator's maximum food level.
     */
    abstract public int getMaxFoodLevel();   

    /**
     * Get the predator's current food level.
     * @return the predator's current food level.
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * Update the predator's current food level.
     * @param newFoodLevel The predator's new food level.
     */
    protected void setFoodLevel(int newFoodLevel)
    {
        foodLevel = newFoodLevel;
    }

    /**
     * Make this predator more hungry. 
     * This could result in the predator's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
}
