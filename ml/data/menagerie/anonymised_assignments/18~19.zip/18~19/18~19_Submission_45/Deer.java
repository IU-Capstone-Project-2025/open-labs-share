import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A Deer is an Animal. It ages each step, and moves and gives
 * birth only during the night. A Deer can die from old age,
 * disease, or if it struck by lightning during a thunderstorm.
 * A Deer can mate with adjacent deer, if they are of the opposite
 * sex. A Deer can get infected with disease from adjacent
 * infected mice.
 *
 * @version 2019.02.20
 */
public class Deer extends Animal
{
    // The age to which a deer can live.
    private static int max_age = 1200;
    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 110;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.65;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The likelihood of a deer being infected by disease from an adjacent diseased mouse.
    private static final double CONTAGIOUS_INFECTION_PROBABILITY = 0.0000001;

    /**
     * Create a deer. A deer can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the deer will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }

    /**
     * Get the deer's breeding age.
     * @return the deer's breeding age.
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Get the deer's maximum age.
     * @return the deer's maximum age.
     */
    public int getMaxAge()
    {
        return max_age;
    }

    /**
     * Get the deer's maximum litter size.
     * @return the deer's maximum litter size.
     */
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Get the deer's breeding probability.
     * @return the deer's breeding probability.
     */
    public double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * Check whether there is a compatible mate in an adjacent location.
     * @return True if the adjacent deer is of the oppposite gender and
     * can breed, and False otherwise.
     */
    public boolean adjCompatibleMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()){
            Location location = it.next();
            Object animal = field.getObjectAt(location);
            if(animal instanceof Deer){
                Deer deer = (Deer) animal;
                if(deer.isFemale() != isFemale() && deer.canBreed()){
                    return true;
                }
            }            
        }
        return false;
    }

    /**
     * The deer might breed, die of hunger, die by
     * being eaten, die of old age, die from disease, 
     * or die by lightning strike.
     * @param newDeer A list to return newly born deer.
     * @param isNight A boolean to check if it is currently night in the simulation.
     * @param weather A string that states the current weather in the simulation.
     */
    public void act(List<Animal> newDeer, boolean isNight, String weather)
    {
        incrementAge();

        if(isAlive()) {
            if(weather.equals("thunderstorm")){
                if(rand.nextDouble()<= LIGHTNING_DEATH){
                    setDead();  // Kill the cougar if it is struck by lightning.
                }
                else{
                    defaultAct(newDeer, isNight);
                }
            }  
            else{
                defaultAct(newDeer, isNight);
            }
        }
    }

    /**
     * This is the default action of the Deer if it is day.
     * It may give birth and move around.
     * @param newDeer A list to return newly born deer.
     * @param isNight Whether or not it is night.
     */
    private void defaultAct(List<Animal> newDeer, boolean isNight)
    {
        if(!isNight){   // The deer sleeps during the night.
            giveBirth(newDeer);   
            getInfected();
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Create a newborn deer.
     * @param field The field of the new deer.
     * @param loc The location in the field of the new deer.
     * @return The new deer.
     */
    public Deer createYoung(Field field, Location loc)
    {
        Deer young = new Deer(false, field, loc);
        return young;
    }

    /**
     * Infect the deer with disease. It will have
     * only 5 more days to live.
     */
    public void infect()
    {
        super.infect();
        max_age = getAge() + 20;   
    }

    /**
     * Deer can get infected by interacting with adjacent mice that are infected.
     */
    private void getInfected()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);
            if(organism instanceof Mouse){
                Mouse mouse = (Mouse) organism;
                if(mouse.isAlive() && mouse.isInfected()){
                    if(rand.nextDouble() <= CONTAGIOUS_INFECTION_PROBABILITY){
                        infect();
                    }
                }
            }
        }
    }
}
