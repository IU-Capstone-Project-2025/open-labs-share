import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * An ocean environment simulator, based on a side-view rectangular field of
 * the sea, with depth (including above and below water), weather simulation,
 * and day/night cycles.
 *
 * The simulation contains:
 *      Predators: Whales
 *      Predator/Prey: Mackerel, Salmon, Bass
 *      Prey: Plankton
 *      Plants: Seaweed
 *
 * @version 2019.02.19
 *
 * Based on version 2016.02.29:
 *
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 130;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 110;
    // The probability for organisms that will be created in any given grid position:
    private static final double WHALE_CREATION_PROBABILITY = 0.0012;
    private static final double MACKEREL_CREATION_PROBABILITY = 0.005;
    private static final double BASS_CREATION_PROBABILITY = 0.004;
    private static final double PLANKTON_CREATION_PROBABILITY = 0.002;
    private static final double SEAWEED_CREATION_PROBABILITY = 1.0;
    private static final double SALMON_CREATION_PROBABILITY = 0.006;
    private static final double CLOUD_PROBABILITY = 0.4;

    // The length of one day or night.
    private static final int DAY_LENGTH_STEPS = 250;

    // List of organisms in the field.
    private List<Organism> organisms;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    private GraphView gview;

    // Keep track of current time.
    private int time = 0;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
        field = new Field(depth, width);
        field.setTime(time);


        // Create a view of the state of each location in the field
        view = new SimulatorView(depth, width);
        // Define colours for each organism
        view.setColor(Mackerel.class,new Color(237, 94, 37));
        view.setColor(Whale.class, new Color(220,100,220) );
        view.setColor(Bass.class,new Color(180, 36, 40));
        view.setColor(Plankton.class, new Color(148, 220, 173) );
        view.setColor(Seaweed.class, new Color(22, 141, 28) );
        view.setColor(Salmon.class, new Color(222, 194, 35) );

        // Create a graph view to track populations
        gview = new GraphView(800, 200, 100);
        // Define colours for each organism
        gview.setColor(Mackerel.class,new Color(237, 94, 37));
        gview.setColor(Whale.class, new Color(220,100,220) );
        gview.setColor(Bass.class,new Color(180, 36, 40));
        gview.setColor(Plankton.class, new Color(148, 220, 173) );
        gview.setColor(Seaweed.class, new Color(22, 141, 28) );
        gview.setColor(Salmon.class, new Color(222, 194, 35) );

        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            //delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each organism.
     */
    public void simulateOneStep()
    {
        Random rand = Randomizer.getRandom();
        step++;
        time = time+1;
        if(time>DAY_LENGTH_STEPS) {  // If one half-day has passed, toggle from day/night or vice versa.
            field.setIsCloudy(false);
            time = -1*DAY_LENGTH_STEPS;
            if(rand.nextDouble() <= CLOUD_PROBABILITY){ // Determine weather status for given half-day.
                field.setIsCloudy(true);

            }


        }
        field.setTime(time);

        // Provide space for newborn organisms.
        List<Organism> newOrganisms = new ArrayList<>();
        // Let all organisms act.
        for(Iterator<Organism> it = organisms.iterator(); it.hasNext(); ) {
            Organism organism = it.next();
            organism.act(newOrganisms);

            if(! organism.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born organisms to the main lists.
        organisms.addAll(newOrganisms);

        view.showStatus(step, time, field);
        gview.showStatus(step, field);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        time = -1*DAY_LENGTH_STEPS; // Start at the beginning of night.
        field.setTime(time);
        organisms.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, time, field);
        gview.showStatus(step, field);

    }


    /**
     * Randomly populate the field with organisms based of their defined probabilities and determined depths.
     * Field cannot be populated above-water (top 10% of field).
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {

                if(rand.nextDouble() <= SEAWEED_CREATION_PROBABILITY && row >= field.getDepth()*0.95){
                    Location location = new Location(row, col);
                    Seaweed seaweed = new Seaweed(true, field, location);
                    organisms.add(seaweed);
                }
                else if(rand.nextDouble() <= PLANKTON_CREATION_PROBABILITY && row <= field.getDepth()*0.2 && row>=0.1*field.getDepth()){
                    Location location = new Location(row, col);
                    Plankton plankton = new Plankton(true, field, location);
                    organisms.add(plankton);
                }
                else if(rand.nextDouble() <= WHALE_CREATION_PROBABILITY && row >= field.getDepth()*0.6) {
                Location location = new Location(row, col);
                    Whale whale = new Whale(true, field, location);
                    organisms.add(whale);
                }
                else if(rand.nextDouble() <= MACKEREL_CREATION_PROBABILITY && row>=0.1*field.getDepth()) {
                    Location location = new Location(row, col);
                    Mackerel mackerel = new Mackerel(true, field, location);
                    organisms.add(mackerel);
                }
                else if(rand.nextDouble() <= BASS_CREATION_PROBABILITY && row>=0.1*field.getDepth()) {
                    Location location = new Location(row, col);
                    Bass bass = new Bass(true, field, location);
                    organisms.add(bass);
                }
                else if(rand.nextDouble() <= SALMON_CREATION_PROBABILITY && row>=0.1*field.getDepth()) {
                    Location location = new Location(row, col);
                    Salmon salmon = new Salmon(true, field, location);
                    organisms.add(salmon);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
