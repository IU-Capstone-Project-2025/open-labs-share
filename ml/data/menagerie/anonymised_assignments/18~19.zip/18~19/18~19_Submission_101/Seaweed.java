import java.util.List;
import java.util.Random;

/**
 * A simple model of a Seaweed.
 * Seaweed are static, they age, grow and die.
 * It spawns in the bottom 5% of the ocean but can grow upwards.
 * Seaweed eats: Nothing.
 *
 * @version 2019.02.19
 *
 * based on version 2016.02.29
 *
 */

public class Seaweed extends Plant
{

    // The age to which a Seaweed can live.
    private static final int MAX_AGE =2;

    // The likelihood of a Seaweed growing.
    private static final double GROWTH_PROBABILITY = 0.8;

    // The maximum number of births.
    private static final int MAX_GROWTH_SIZE = 2;

    // A shared random number generator to control growth.
    private static final Random rand = Randomizer.getRandom();

    // The Seaweed's age.
    private int age;

    /**
     * Create a new Seaweed. A Seaweed may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the Seaweed will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Seaweed(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the Seaweed does most of the time - it
     * is static. Sometimes it will grow or die of old age.
     * @param newSeaweed A list to return newly grown Seaweed.
     */
    public void act(List<Organism> newSeaweed)
    {
        incrementAge();
        if(isAlive()) {
            grow(newSeaweed);

        }
    }

    /**
     * Increase the age.
     * This could result in the Seaweed's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Seaweed is to grow at this step.
     * New growths will be made into free adjacent locations.
     * @param newSeaweed A list to return newly grown seaweed.
     */
    private void grow(List<Organism> newSeaweed)
    {
        // New Seaweed are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = grow();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);

            if (loc.getRow()>=0.95*field.getDepth() || rand.nextDouble() < 0.37) {
                Seaweed young = new Seaweed(false, field, loc);
                newSeaweed.add(young);
            }
        }
    }
        
    /**
     * Generate a number representing the number of growths,
     * if it can grow.
     * @return The number of growths (may be zero).
     */
    private int grow()
    {
        int growths = 0;
        if(rand.nextDouble() <= GROWTH_PROBABILITY) {
            growths = rand.nextInt(MAX_GROWTH_SIZE) + 1;
        }
        return growths;
    }

}
