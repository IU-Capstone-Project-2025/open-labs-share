import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a Bass.
 * Bass age, move, breed, eat and die. They can form and spread a disease.
 * They can spawn and move anywhere in the ocean.
 * Bass eat: Plankton, Seaweed, Salmon and Mackerel.
 *
 * @version 2019.02.19
 *
 * based on version 2016.02.29
 *
 */
public class Bass extends Animal {
    // Characteristics shared by all Bass (class variables).

    // The age at which a Bass can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a Bass can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a Bass breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single fish/organism. In effect, this is the
    // number of steps a bass can go before it has to eat again.
    private static final int FISH_FOOD_VALUE = 20;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The Bass's age.
    private int age;
    // The bass' food level, which is increased by eating fish/organisms.
    private int foodLevel;

    // if a Bass is diseased
    private boolean isDiseased;
    // The chance of a Bass forming a disease.
    private static final double DISEASE_GENERATION_PROBABILITY = 0.00001;
    // The chance of a Bass not forming a disease when adjacent to a diseased Bass
    // that is spreading the disease.
    private static final double DISEASE_MORTALITY_PROBABILITY = 0.05;
    // The chance of a diseased Bass spreading the disease to adjacent Bass.
    private static final double DISEASE_SPREAD_PROBABILITY = 0.5;


    /**
     * Create a Bass. A Bass can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * All Bass are created without a disease.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Bass(boolean randomAge, Field field, Location location) {
        super(field, location);
        if (randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FISH_FOOD_VALUE);
        } else {
            age = 0;
            foodLevel = FISH_FOOD_VALUE;
        }
        isDiseased = false;
    }

    /**
     * This is what the Bass does most of the time: it hunts for
     * fish/organisms. In the process, it might breed, die of hunger,
     * die of old age or die of a disease.
     *
     * @param field     The field currently occupied.
     * @param newWhales A list to return newly born foxes.
     */
    public void act(List<Organism> newWhales) {
        incrementAge();
        incrementHunger();

        processDisease();

        if (isAlive()) {
            giveBirth(newWhales);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if (newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if (newLocation != null) {
                if ( newLocation.getRow()>=0.1*field.getDepth()) {
                    setLocation(newLocation);
                }
            } else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * This is where the Bass' disease is processed. If they are diseased,
     * there is a probability that they will die. If they aren't diseased,
     * there is a probabilty that they will form a disease. All Bass can
     * carry the disease, therefore can spread the disease to adjacent Bass.
     */
    private void processDisease() {

        // chance of dying if diseased
        if (isDiseased && rand.nextDouble() <= DISEASE_MORTALITY_PROBABILITY) {
            setDead();
            return;
        }

        // chance of forming disease
        if (rand.nextDouble() <= DISEASE_GENERATION_PROBABILITY) {
            isDiseased = true;
        }

        Field field = getField();
        if(field == null) return;

        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();

        // handles spreading to adjacent Bass
        while(it.hasNext()) {
            Location where = it.next();
            Object neighbour = field.getObjectAt(where);
            if (neighbour != null && neighbour.getClass() == this.getClass()){
                Bass n = (Bass) neighbour;

                if(rand.nextDouble() <= DISEASE_SPREAD_PROBABILITY){
                n.setDiseased(true);}
            }
        }

    }

    /**
     * Return if the Bass is diseased.
     * @return isDiseased If a Bass is diseased
     */
    public boolean isDiseased() {
        return isDiseased;
    }

    /**
     * Set if the Bass is diseased.
     */
    public void setDiseased(boolean disease){
        isDiseased = disease;
    }


    /**
     * Increase the age. This could result in the Bass' death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this Bass more hungry. This could result in the Bass' death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for fish/organisms adjacent to the current location.
     * Only the first live fish.organism is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object organism = field.getObjectAt(where);

            if(organism instanceof Mackerel || organism instanceof Plankton || organism instanceof Seaweed || organism instanceof Salmon){
                Organism fish = (Organism) organism;
                if(fish.isAlive()){
                    fish.setDead();
                    foodLevel = FISH_FOOD_VALUE;
                    return where;
                }

            }
        }
        return null;
    }
    
    /**
     * Check whether or not this Bass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newBass A list to return newly born foxes.
     */
    private void giveBirth(List<Organism> newBass)
    {
        // New Bass are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (loc.getRow() >= 0.1 * field.getDepth()) {
                Bass young = new Bass(false, field, loc);
                newBass.add(young);
            }
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Bass can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
