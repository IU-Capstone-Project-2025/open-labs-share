/**
 * The main class for this simulator project.
 * Provides a main method which instantiates a new simulator and runs a long simulation
 * on runtime.
 *
 * @version 2019.02.19
 **/
public class Main {
    public static void main(String[] args){
        Simulator s = new Simulator();
        s.runLongSimulation();
    }
}
