import java.time.*;
/**
 * This is the Weather class.
 * The weather changes based on the time, this time is the time at which the simulation
 * is started.
 * The different types of weather are allocated based on the different times in a day.
 *
 * @version 2016.02.29
 */
public class Weather
{
    public Weather()
    {
    }
    
    // The weather at a certain time of the day.
    private String currentWeather;
    
    /**
     * Returns the weather at certain times of the day.
     * @return the type of the weather as a string.
     */
    public String getWeather(){
        LocalTime currentTime = LocalTime.now(); // gets the current time in the simulation.
        
        // sets 4 different tintervals of time to allocate for the weather.
        LocalTime morningTime1 = LocalTime.parse("12:00:00");
        
        LocalTime afternoonTime1 = LocalTime.parse("16:00:00");
        
        LocalTime eveningTime1 = LocalTime.parse("19:00:00");
        
        LocalTime nightTime1 = LocalTime.parse("03:00:00");
        
        if ((currentTime.isAfter(nightTime1)) && (currentTime.isBefore(morningTime1)))
        {
            currentWeather = "fog";
        }
        
        if ((currentTime.isAfter(morningTime1)) && (currentTime.isBefore(afternoonTime1)))
        {
            currentWeather = "sunny";
        }
        
        if ((currentTime.isAfter(afternoonTime1)) && (currentTime.isBefore(eveningTime1)))
        {
            currentWeather = "windy";
        }

        if ((currentTime.isAfter(eveningTime1)) && (!currentTime.isBefore(nightTime1)))
        {   
            currentWeather = "rainy";
        }
        
        return currentWeather;
    }
}
