import java.util.Random;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.time.*;
/**
 * A simple model of the Grass class.
 * Grass can implement growth, size, they can die or stay alive
 * This depends on how much of the grass has been eaten by 
 * the Zebra.
 *
 * @version 2016.02.29 (2)
 * 
 */
public class Grass extends Plant
{
    // Checks whether the Grass is alive or not.
    private boolean alive;
    // The field of the Grass.
    private Field field;
    // The position of Grass in the field.
    private Location location;
    // The rate of grass growth per minute.
    private static final double GRASS_GROWTH_RATE = 0.10;
    // The max size the grass can grow.
    private static final double GRASS_MAX_SIZE = 0.90;
    // The number of steps it can travel before it dies.
    private static final double GRASS_FOOD_VALUE = 0.80;
    // The current grass size.
    private static double currentSize = 0.1;
    // The initial grass size at the start of the simulation.
    private static double initialSize;
    // Checks the last time when the grass was grown.
    protected Date lastGrowthTime;
    // The current weather.
    private Weather currentWeather;

    /**
     * Create a new Grass. Grass is created based on their
     * growth rate.
     * 
     * @param isAlive is true, then grass is alive and can be eaten.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean alive, Field field, Location location)
    {
        super(field, location);
        lastGrowthTime = initialTime; 
        // the intial time is stored as a value in the variable lastGrowthTime.
        initialSize = 0.50; // initial size of grass at the start of the simulation.
        alive = true;
        currentWeather = new Weather();
    }
    
    /**
     * This method allows the grass to grow at a given rate.
     * The growth is implemented by growth per min.
     * Grass growth hence increases by a given value every min.
     */
    protected void grow()
    {
        Date currentTime = new Date();   // gets the current time in the simulation.
        lastGrowthTime = new Date();     // gets the last time the grass was grown.
        long timeDiff = currentTime.getTime() - lastGrowthTime.getTime();   
        // finds the diff between the time it is now and the last time grass was grown. 
        long minuteDiff = TimeUnit.MILLISECONDS.toMinutes(timeDiff);
        // converts the value into minutes are growth is implemented by rate per min.
        currentSize = minuteDiff*GRASS_GROWTH_RATE + initialSize;
        //calculates the size of the grass in the simulation.
    }
    
    /**
     * Gets the size of the grass in the current position.
     * @return the value of the the size of the grass as a decimal number.
     */
    public double getSize()
    {
        grow(); // a method call to grow().
        return currentSize ;
        // returns the size after the grass has grown.
    }
    
    /**
     * Decreases the grass size based on how much of it has been eaten.
     * Each Zebra can only eat a fixed amount of grass.
     * @param eatenSize, the amount of grass one zebra can eat.
     */
    public void decreaseSize(double eatenSize)
    {
       if (currentSize < eatenSize){
           currentSize = 0;
           setDead(); // if the amount of grass that needs to be eaten is more than the current size of the grass.
           // then the grass dies, it cannot grow anymore.
        }
       else
       {
          currentSize = currentSize-eatenSize;
          // if the grass has a greater size than how much a zebra can eat,
          // then the newSize of the grass is the current - the amount eatenSize.
       }
    }
    
    /**
     * This is the act method for grass.
     * The grass between certain times will grow and the rest of the times it will not grow.
     * @param newGrass A list to receive newly born plants.
     */
    public void act(List<Plant> newGrass)
    {
        grow();
        
        LocalTime currentTime = LocalTime.now(); // gets the current time at that point in the simulation.
        LocalTime nightTime1 = LocalTime.parse("03:00:00");
        LocalTime nightTime2 = LocalTime.parse("20:00:00");
        if(currentTime.isAfter(nightTime1) && currentTime.isBefore(nightTime2) && (currentWeather.getWeather() != "rainy"))
        {
          grow();
          // the grass grows between two intervals of time and when its not a certain type of weather.
        }
    }
}


