import java.util.Random;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.time.*;
/**
 * A simple model of the Shrubs class.
 * Shrubs can implement growth, size, they can die or stay alive
 * based on how much of the Shrubs have been eaten by the Bison.
 *
 * @version 2016.02.29 (2)
 */
public class Shrubs extends Plant
{
    // Checks whether the Shrubs are alive or not.
    private boolean alive;
    // The Shrubs field.
    private Field field;
    // The Shrubs position in the field.
    private Location location;
    // The rate of Shrubs growth per minute.
    private static final double SHRUBS_GROWTH_RATE = 0.15;
    // The max size the Shrubs can grow.
    private static final double SHRUBS_MAX_SIZE = 0.80;
    // The amount of Shrubs that is eaten by Zebra.
    private static final double SHRUBS_FOOD_VALUE = 0.60;
    // The current Shrub size.
    private static double currentSize = 0.20;
    // The initial Shrub size at the start of the simulation.
    private static double initialSize;
    // Checks the last time when the Shrubs was grown.
    protected Date lastGrowthTime;
    //The current weather
    private Weather currentWeather;


    /**
     * Create a new Shrubs. Shrub size increases based on
     * their growth rate.
     * 
     * @param isAlive is true, then shrubs are alive and can be eaten
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Shrubs(boolean alive, Field field, Location location)
    {
        super(field, location); 
        lastGrowthTime = initialTime;
        initialSize = 0.30; // initial size of shrubs at the start of the simulation.
        alive = true;
        currentWeather = new Weather();
    }
    
    /**
     * Allows the Shrubs to grow at a given rate
     * The growth is implemented by growth per min.
     * Shrubs growth hence increases by a given value every min.
     */
    protected void grow()
    {
        Date currentTime = new Date();   // gets the current time in the simulation.
        lastGrowthTime = new Date();     // gets the last time the Shrubs was grown.
        long timeDiff = currentTime.getTime() - lastGrowthTime.getTime();   
        // finds the diff between the time it is now and the last time Shrubs was grown. 
        long minuteDiff = TimeUnit.MILLISECONDS.toMinutes(timeDiff);
        // converts the value into minutes are growth is implemented by rate per min.
        currentSize = minuteDiff*SHRUBS_GROWTH_RATE + initialSize;
        //calculates the current size of the Shrubs at the current time in the simulation.
    }
    
    /**
     * Gets the size of the Shrubs in the current position.
     * @return the value of the the size of the Shrubs as a decimal number.
     */
    public double getSize()
    {
        grow(); // a method call to grow()
        return currentSize ;
        // returns the size after the Shrubs has grown.
    }
    
    /**
     * Decreases the Shrub size based on how much of it has been eaten.
     * Each Bison can only eat a fixed amount of Shrubs.
     * @param eatenSize, the amount of shrubs one bison can eat.
     */
    public void decreaseSize(double eatenSize)
    {
       if (currentSize < eatenSize){
           currentSize = 0;
           setDead(); // if the amount of Shrubs that needs to be eaten is more than the current size of the shrubs.
           // then the shrubs dies, it cannot grow anymore.
        }
       else
       {
          currentSize = currentSize-eatenSize;
          // if the shrubs has a greater size than how much a bison can eat,
          // then the newSize of the shrubs is the current - the amount eaten by the bison.
       }
       
    }
    
    /**
     * This is the act method for shrubs.
     * The shrubs between certain times will grow and the rest of the times it will not grow.
     */
    public void act(List<Plant> newShrubs)
    {
        grow();
        
        LocalTime currentTime = LocalTime.now(); // gets the current time.
        LocalTime nightTime1 = LocalTime.parse("03:00:00");
        LocalTime nightTime2 = LocalTime.parse("20:00:00");
        
        if(currentTime.isAfter(nightTime1) && currentTime.isBefore(nightTime2) && (currentWeather.getWeather() != "rainy"))
        {
            grow(); // only executed if the conditions in the if statement match.
        }
    
    }
}
