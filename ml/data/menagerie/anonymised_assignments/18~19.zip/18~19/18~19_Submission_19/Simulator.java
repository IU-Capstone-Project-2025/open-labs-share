import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing Lions, Zebras, Bison, Hawks, Feretts, Grass and Shrubs.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a hawk will be created in any given grid position.
    private static final double HAWK_CREATION_PROBABILITY = 0.02000;
    // The probability that a ferret will be created in any given grid position.
    private static final double FERRETS_CREATION_PROBABILITY = 0.14500;    
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.01350;
    // The probability that a bison will be created in any given grid position.
    private static final double BISON_CREATION_PROBABILITY = 0.05825;
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.05900;
    // The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.50000;
    // The probability that shrubs will be created in any given grid position.
    private static final double SHRUBS_CREATION_PROBABILITY = 0.40000;
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The number of steps taken in the simulation.
    private int numberOfStepsTaken;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A random generator to see if zebra will be infected.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Ferrets.class, Color.ORANGE);
        view.setColor(Hawk.class, Color.BLUE);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Bison.class, Color.BLACK);
        view.setColor(Zebra.class, Color.PINK);
        view.setColor(Grass.class, Color.GREEN);
        view.setColor(Shrubs.class, Color.YELLOW);
        // gives each of the species in the simulation a different colour so that
        // they can be distinguished.
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Removes all the animals that have a disease after a certain number of steps.
     */
    public void removeInfected()
    {
      if(step >= 50){
          for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) { //iterates through the entire list of animals.
            Animal animal = it.next();
            if (animal.getDiseaseData() == true) // gets the boolean value and sees if it is true for an animal.
            {
                animal.removeDisease();                
                // if the boolean is true then the removeDisease() method is called on that animal.
            }
          }
      }
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            if(step == 50){
                removeInfected(); // removes those animals that are infected
            }
            delay(30);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep()
    {
        step++;
        // Provide space for newborn animals and plants.
        
        List<Animal> newAnimals = new ArrayList<>();   // Array list of all new animals created in the simulation.
        List<Plant> newPlants = new ArrayList<>(); // Array list of all new plants created in the simulation.
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(newPlants);
            if(! plant.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals, these are the lions, hawks, bison, ferrets and zebras.
        animals.addAll(newAnimals);
        // Add all the new plants created, these are grass and shrubs.
        plants.addAll(newPlants);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();    // creates the species in the simulation.
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with Lions, Zebras, Hawks, Bison, Ferrets, Grass and Shrubs.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Hawk hawk = new Hawk(true, field, location);
                    animals.add(hawk);   // creates hawks and adds it to the simulation.
                }
                else if(rand.nextDouble() <= FERRETS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Ferrets ferret = new Ferrets(true, field, location);
                    animals.add(ferret); // creates ferrets and adds it to the simulation.
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);  // creates lions and adds it to the simulation.
                }
                else if(rand.nextDouble() <= BISON_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Bison bison = new Bison(true, field, location);
                    animals.add(bison);   // creates bison and adds it to the simulation.
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    if (rand.nextInt(2) == 0)
                    {
                        zebra.setDiseaseData(); //Chance on creation of a zebra getting the disease or not   
                        // 0  it gets the disease and 1 it does not get the disease.
                    }
                    animals.add(zebra); // creates zebras and adds it to the simulation.
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    plants.add(grass);  // creates new grass and adds it to the simulation.
                }
                else if(rand.nextDouble() <= SHRUBS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Shrubs shrubs = new Shrubs(true, field, location);
                    plants.add(shrubs);  // creates new shrubs and adds it to the simulation.
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds.
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
