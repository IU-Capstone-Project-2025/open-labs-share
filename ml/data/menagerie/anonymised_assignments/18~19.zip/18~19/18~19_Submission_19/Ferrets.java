import java.util.List;
import java.util.Random;
import java.util.Iterator;
import java.time.*;

/**
 * A simple model of Ferrets.
 * Ferretss can age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Ferrets extends Animal
{
    // Characteristics shared by all Ferrets (class variables).

    // The age at which a Ferrets can start to breed.
    private static final int BREEDING_AGE = 5;
    // The max age to which a Ferrets can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a Ferrets breeding.
    private static final double BREEDING_PROBABILITY = 0.06;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
  
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The Ferrets's age.
    private int age;
    // Determines the gender of each ferret.
    // When a ferret gives birth they are not able to breed again for a certain number of steps.
    private int gender;
    // The current weather.
    private Weather weatherNow;

    /**
     * Create a new Ferrets. A Ferrets may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Ferrets will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Ferrets(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        gender = rand.nextInt(2); // creates a random counter for gender
        // from 0-2 so 0 inclusive and 2 exclusive.
        // 0 = male
        // 1 = female
        weatherNow = new Weather();
    }
    
    /**
     * Returns the gender of a ferret.
     * @return the gender of a ferret.
     */
    public int getGender()
    {
        return gender;
    }
    
    /**
     * This is what the Ferrets does most of the time - is is the
     * prey so it tries to escape from its predators.
     * Sometimes it will breed or die of old age.
     * @param newFerrets A list to return newly born Ferrets.
     */
    public void act(List<Animal> newFerrets)
    {
        LocalTime currentTime = LocalTime.now();
        LocalTime earlyTime = LocalTime.parse("00:00:00");
        LocalTime lateTime = LocalTime.parse("18:00:00");
        int currentFerret = getGender();
        if ((currentTime.isAfter(earlyTime)) && (currentTime.isBefore(lateTime)) && (weatherNow.getWeather() != "rainy")){
            incrementAge();
            if(isAlive()) {
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                int breedTookPlace = 0; //checker to keep giving birth under control
                
                while((breedTookPlace == 0) && (it.hasNext())) {     //stops the iterator after 1 ferret has given 1 birth           
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Ferrets) {              // checks if animal is a ferret.        
                        Ferrets Ferrets = (Ferrets) animal;
                        if(Ferrets.isAlive()) {                        
                            if ((Ferrets.getGender() != currentFerret)){   // can only make opposite genders breed
                                giveBirth(newFerrets);
                                breedTookPlace = 1;   // makes sure one animal can only breed with one animal at that step.
                            }
                            
                        }
                    }
                }           
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        else{
            incrementAge();
            if(isAlive()) {
                Field field = getField();
                List<Location> adjacent = field.adjacentLocations(getLocation());
                Iterator<Location> it = adjacent.iterator();
                int breedTookPlace = 0; 
                while((breedTookPlace == 0) && (it.hasNext())) {                
                    Location where = it.next();
                    Object animal = field.getObjectAt(where);
                    if(animal instanceof Ferrets) {                    
                        Ferrets Ferrets = (Ferrets) animal;
                        if(Ferrets.isAlive()) {                        
                            if ((Ferrets.getGender() != currentFerret)){
                                giveBirth(newFerrets);
                                breedTookPlace = 1;
                            }                                
                        }
                    }
                }
            }            
        }
    }

    /**
     * Increase the age.
     * This could result in the Ferrets's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Ferrets is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFerrets A list to return newly born Ferrets.
     */
    private void giveBirth(List<Animal> newFerrets)
    {
        // New Ferretss are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Ferrets young = new Ferrets(false, field, loc);
            newFerrets.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Ferrets can breed if it has reached the breeding age.
     * @return true if the Ferrets can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
