import java.util.Random;
/**
 * Class for easy implementation of markov chains
 * Maybe use for weather class?
 */

public class Markov {
    private double[][] probabilityMatrix;
    private int currentState;
    private Random r;

    public Markov(double[][] probabilityMatrix) {
        r = new Random();

        this.probabilityMatrix = probabilityMatrix;
        currentState = 0;
    }

    /**
     * A random walk is a random "step" from one state to another
     * The new resulting state becomes the current state
     **/

    public void randomWalk() {
        double randDouble = r.nextDouble();

        double lowerBound = 0;
        double upperBound = probabilityMatrix[currentState][0];

        if (randDouble > lowerBound && randDouble <= upperBound) {
            currentState = 0;
        }
        else {

            for (int nextState = 1; nextState < probabilityMatrix.length; ++nextState) {
                lowerBound = upperBound;
                upperBound += probabilityMatrix[currentState][nextState];

                if (randDouble > lowerBound && randDouble <= upperBound) {
                    currentState = nextState;
                    break;
                }
            }
        }
    }

    public int getCurrentState() {
        return currentState;
    }
}
