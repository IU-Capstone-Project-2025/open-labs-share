/**
 * Interface for implementing collision logic for every specified entity
 * Methods return true if objects cannot overlap, and false otherwise.
 */

public interface Collider {
    public abstract boolean collidesWith(AnimalCollider animal);
    public abstract boolean collidesWith(LakeCollider lake);
    public abstract boolean collidesWith(PlantCollider plant);
    public abstract boolean collidesWith(BerryCollider berry);
    public abstract boolean collidesWith(Collider collider);
}
