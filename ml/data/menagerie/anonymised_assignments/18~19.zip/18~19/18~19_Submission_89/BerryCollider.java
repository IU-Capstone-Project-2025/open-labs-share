public class BerryCollider implements Collider{
    @Override


    /**
     *The following methods are used to decide with what the
     * berries collide.
     */
    public boolean collidesWith(LakeCollider lake) {
        return true;
    }

    @Override
    public boolean collidesWith(AnimalCollider animal) {
        return false;
    }

    @Override
    public boolean collidesWith(PlantCollider plant) {
        return false;
    }

    @Override
    public boolean collidesWith(BerryCollider berry) {
        return true;
    }

    @Override
    public boolean collidesWith(Collider collider) {
        return collider.collidesWith(this);
    }
}
