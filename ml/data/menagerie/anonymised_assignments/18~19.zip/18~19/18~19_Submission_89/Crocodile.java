import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;


/*
 * @version 2019/02/21
 */
public class Crocodile extends Animal {

    // The crocodiles age
    private int age;
    //The habitate region for the crocodile. It's of type circle because the lake is basically a multiple of lakes put on top
    //of each other to look more natural
    private ArrayList < Circle > habitatRegions;
    //Inititalize the lake object
    private Lake lake;
    //Initialize the Collider for the crocodile
    private static CrocodileCollider crocCollider = new CrocodileCollider();
    //The breeding probability of the crocodile
    private static final double BREEDING_PROBABILITY = 0.04;
    //The Maximul amount of babies a Crocodile can get
    private static final int MAX_LITTER_SIZE = 1;
    // The max age of the crocodile
    private static final int MAX_AGE = 300;
    // The breeding age of the crocodile
    private static final int BREEDING_AGE = 50;
    // The maximal distance the crocodile can be away from the lake
    private static final int MAX_LAKE_DISTANCE = 10;
    // The gender of the crocodile
    private boolean isMale;
    // The food level of the animal, aka the amount of steps the animal can survive without finding a source of food
    private int foodLevel;
    // The nutrion gained by killing a Bear
    private static final int BEAR_FOOD_VALUE = 100;


    /**
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param homeLake The lake object in which the crocodile lives in
     * @param isMale indicates the gender of the animal
     * @param weather inserts the weather object
     * @param time inserts the time object
     */
    public Crocodile(Field field, Location location, Lake homeLake, boolean isMale, Weather weather, Time time) {
        super(field, location, weather, time);
        age = 0;
        habitatRegions = new ArrayList < > ();
        lake = homeLake;
        this.isMale = isMale;
        generateHabitatRegions();
        foodLevel = 0;
    }

    // one time generation of a list of boundaries that the crocodile can reside within.
    private void generateHabitatRegions() {
        int nextRadius;

        for (Circle region: lake.getCircles()) {
            nextRadius = region.radius + MAX_LAKE_DISTANCE;
            habitatRegions.add(new Circle(region.centre, nextRadius));
        }
    }

    /**
     * The Act function gets called once a step and make sure that the crocodile finds a partner, finds food, gets older
     * @param newCrocodiles is the list of all the crocos. We need this to find a partner and breed
     */
    public void act(List < Organism > newCrocodiles) {
        Location newLocation = getField().freeAdjacentLocation(getLocation(), this);
        findPartner(newCrocodiles);
        findFood();
        if (newLocation != null) {
            for (Circle region: habitatRegions) {
                if (newLocation.squareDistanceTo(region.centre) <= Math.pow(region.radius, 2)) {
                    setLocation(newLocation);
                    break;
                }
            }
        } else {
            // Overcrowding.
            setDead();
        }

        incrementAge();
    }

    /**
     * The breed function returns the number of babies the animal is getting
     * @return the number of births
     */

    private int breed() {
        Random r = new Random();
        int births = 0;
        if (canBreed() && r.nextDouble() <= BREEDING_PROBABILITY) {
            births = r.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * The giveBirth function creates a new Crocodile and adds it to the list afterwards
     * @param newCrocodiles the baby will be added to the List of crocodiles
     */

    private void giveBirth(List < Organism > newCrocodiles) {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List < Location > free = field.getFreeAdjacentLocations(getLocation(), this);
        int births = breed();
        for (int b = 0; b < births && free.size() > 0; b++) {
            // Randomly decide whether the baby will be male or female.
            boolean isTheBabyMale = Randomizer.getYesOrNo();
            if (free != null) {
                Location newLocation = free.remove(0);
                for (Circle region: habitatRegions) {
                    if (newLocation.squareDistanceTo(region.centre) <= Math.pow(region.radius, 2)) {
                        Crocodile young = new Crocodile(field, newLocation, lake, isTheBabyMale, weather, time);
                        newCrocodiles.add(young);
                        break;
                    }
                }
            }
        }
    }

    /**
     * The findPartner Function checks everty thing in proximty and then filters for crocodiles
     * of the different gender.
     * @param newCrocodiles, The baby will be put in this list
     */
    private void findPartner(List < Organism > newCrocodiles) {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > animals = field.getObjectsAt(where);
            for (Entity animal: animals) {
                if (animal instanceof Crocodile) {
                    Crocodile crocodile = (Crocodile) animal;
                    if (isMale != crocodile.isMale) {
                        giveBirth(newCrocodiles);
                    }
                }
            }
        }
    }

    /**
     * The find Food Function is used to check is there is a bear around.
     *  The crocodile kills the bear and gets nutrition for it
     */

    private void findFood() {
        Field field = getField();
        List < Location > adjacent = field.adjacentLocations(getLocation());
        Iterator < Location > it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            ArrayList < Entity > thingsAround = field.getObjectsAt(where);

            for (Entity thing: thingsAround) {
                if (thing instanceof Bear) {
                    Bear bear = (Bear) thing;
                    if (bear.isAlive()) {
                        bear.setDead();
                        foodLevel = BEAR_FOOD_VALUE;
                    }
                }
            }
        }
    }

    /**
     * This function gets the collider of the crocoidle
     * @return crocCollider
     */
    @Override
    public Collider getCollider() {
        return crocCollider;
    }

    /**
     * This function returns the breeding age of the animal
     * @return BREEDING_AGE
     */

    public int getBreedingAge() {
        return BREEDING_AGE;
    }

    /**
     * This function returns the Maximal age of the animal
     * @return MAX_AGE
     */

    public int getMaxAge() {
        return MAX_AGE;
    }
}