public class MouseCollider extends AnimalCollider {

    /**
     * This function checks whether the mouse is colliding with the lake or not
     * @param lake
     * @return true for collides with lake, meaning that the mouse won't end up in the lake.
     */


    @Override
    public boolean collidesWith(LakeCollider lake) {
        return true;
    }
}