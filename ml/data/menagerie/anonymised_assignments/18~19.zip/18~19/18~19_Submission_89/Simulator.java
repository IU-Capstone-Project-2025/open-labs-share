import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2019/02/22
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a fox will be created in any given grid position.
    private static final double TIGER_CREATION_PROBABILITY = 0.04;
    // The probability that a rabbit will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.2;
    private static final double BEAR_CREATION_PROBABILITY = 0.02;
    private static final double SHEEP_CREATION_PROBABILITY = 0.17;
    private static final double SPRUCE_CREATION_PROBABILITY = 0.005;

    private static final double LAKE_CREATION_PROBABILITY = 0.0002;

    private static final double CROC_CREATION_PROBABILITY = 0.01;

    // List of animals in the field.
    private List < Organism > animals;

    private List < Entity > berries;
    private ArrayList < Organism > plants;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;

    private Time time;

    public static Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {

        time = new Time();


        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }


        berries = new ArrayList < > ();
        plants = new ArrayList < > ();
        animals = new ArrayList < > ();


        field = new Field(depth, width);
        weather = new Weather(25, -5);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);

        view.setColor(Tiger.class, new Color(138, 53, 0));
        view.setColor(Lake.class, new Color(90, 150, 200));
        view.setColor(Spruce.class, new Color(0, 100, 0));
        view.setColor(Crocodile.class, Color.green);
        view.setColor(Berry.class, new Color(170, 0, 0));
        view.setColor(Bear.class, new Color(20, 20, 20));
        view.setColor(Mouse.class, new Color(175, 175, 175));
        view.setColor(Sheep.class, new Color(6, 210, 158));

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        reset();
        while (time.getStep() <= numSteps && view.isViable(field)) {
            simulateOneStep();
            time.nextTime();
            //delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep() {
        //  step++;

        // Provide space for newborn animals.
        List < Organism > newOrganisms = new ArrayList < > ();
        //List<Entity> newBerries = new ArrayList<>();

        // Provide space for newborn animals.
        List < Organism > newAnimals = new ArrayList < > ();
        List < Organism > newPlants = new ArrayList < > ();


                if(time.getHour()%6 == 0) {


                    for (Iterator<Organism> it = animals.iterator(); it.hasNext(); ) {
                        Organism animal = it.next();
                        animal.act(newAnimals);
                        if (!animal.isAlive()) {
                            it.remove();
                        }
                    }
                }

            for (Iterator<Organism> it = plants.iterator(); it.hasNext(); ) {
                Organism plant = it.next();
                plant.act(newPlants);
                if (!plant.isAlive()) {
                    it.remove();
                }
            }


        animals.addAll(newAnimals);
        plants.addAll(newPlants);

        // Add the newly born foxes and rabbits to the main lists.
        //  organisms.addAll(newOrganisms);
        //berries.addAll(newBerries);
        weather.changeWeather(time.getStep());

        view.showStatus(time.getStep(), field, weather);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        time.reset();
    
        animals.clear();
        plants.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(time.getStep(), field, weather);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        Random r = new Random();
        int randRow = r.nextInt(field.getDepth());
        int randCol = r.nextInt(field.getWidth());
        Lake wat = new Lake(field, new Location(randRow, randCol));

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                double randDouble = r.nextDouble();
                boolean isTheSpawnedAnimalMale = Randomizer.getYesOrNo();
                if (true /**!(field.getObjectAt(row, col) instanceof Lake)**/ ) {

                    if (randDouble <= SPRUCE_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Spruce spruce = new Spruce(field, location, weather, plants, true);

                        plants.add(spruce);
                    } else if (randDouble <= CROC_CREATION_PROBABILITY + SPRUCE_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        if (!field.isInLocation(location, new CrocodileCollider()) && !field.getObjectsAt(location).isEmpty()) {
                            Crocodile croc = new Crocodile(field, location, wat, isTheSpawnedAnimalMale, weather, time);
                            animals.add(croc);
                        }
                    } else if (randDouble <= TIGER_CREATION_PROBABILITY + CROC_CREATION_PROBABILITY + SPRUCE_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Tiger tiger = new Tiger(true, field, location, isTheSpawnedAnimalMale, weather, time);
                        animals.add(tiger);
                    } else if (randDouble <= MOUSE_CREATION_PROBABILITY + TIGER_CREATION_PROBABILITY + CROC_CREATION_PROBABILITY + SPRUCE_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Mouse mouse = new Mouse(true, field, location, isTheSpawnedAnimalMale, weather, time);
                        animals.add(mouse);
                    } else if (randDouble <= BEAR_CREATION_PROBABILITY + MOUSE_CREATION_PROBABILITY + TIGER_CREATION_PROBABILITY + CROC_CREATION_PROBABILITY + SPRUCE_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Bear bear = new Bear(true, field, location, isTheSpawnedAnimalMale, weather, time);
                        animals.add(bear);
                    } else if (randDouble <= SHEEP_CREATION_PROBABILITY + BEAR_CREATION_PROBABILITY + MOUSE_CREATION_PROBABILITY + TIGER_CREATION_PROBABILITY + CROC_CREATION_PROBABILITY + SPRUCE_CREATION_PROBABILITY) {
                        Location location = new Location(row, col);
                        Sheep sheep = new Sheep(true, field, location, isTheSpawnedAnimalMale, weather, time);
                        animals.add(sheep);
                    }

                }
                // else leave the location empty.
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}