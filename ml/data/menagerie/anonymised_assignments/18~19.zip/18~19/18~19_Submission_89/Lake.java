import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * Class for random generation of lakes.
 * Lakes are of varying size and shape.
 */

public class Lake extends Entity {
    // Associated collision object for lakes
    private static final LakeCollider lakeCollider = new LakeCollider();
    // List of circles that make up the lake
    private ArrayList<Circle>circles;
    // Determines the 'smoothness' of lake, though 12-16 seems to be optimal
    private static final int CIRCLE_COUNT = 15;

    public Lake(Field field, Location location) {
        super(field);
        this.circles = new ArrayList<>();
        generateLake(location);
    }

    /**
     * This method defines the properties of the circles that make up the lake.
     * @param location
     */
    private void generateLake(Location location) {
        int newRow, newCol;
        int radius = 20;
        circles.add(new Circle(location, radius));
        Random r = new Random();

        // Generate random circles for lake.
        for (int c = 0; c < CIRCLE_COUNT; ++c) {
            // Generate random centre on circumference of base circle.
            double angle = 2 * Math.PI * r.nextDouble();
            newRow = location.getRow() + (int) (radius * Math.sin(angle));
            newCol = location.getCol() + (int) (radius * Math.cos(angle));
            Location nextCentre = new Location(newRow, newCol);
            // Random radius between defined values.
            int nextRadius = 10 + r.nextInt(radius - 10);
            circles.add(new Circle(nextCentre, nextRadius));
        }

        placeLake();
    }

    /**
     * Places and draws the lake on the field.
     * Locations are determined by calculating distances to all centres
     * Any location with distance less than current circle radius must be a lake
     */
    private void placeLake() {
        for (int row = 0; row < field.getDepth(); ++row) {
            for (int col = 0; col < field.getWidth(); ++col) {
                for (int c = 0; c < circles.size(); ++c) {
                    double RowSqDis = Math.pow(row - circles.get(c).centre.getRow(), 2);
                    double ColSqDis = Math.pow(col - circles.get(c).centre.getCol(), 2);

                    if (RowSqDis + ColSqDis <= Math.pow(circles.get(c).radius, 2)) {
                        field.place(this, new Location(row, col));
                        break;
                    }
                }
            }
        }
    }

    /**
     * returns locations of the centres and radii of circles making up lake
     */
    public ArrayList<Circle> getCircles() {
        return new ArrayList<>(circles);
    }

    public Collider getCollider() {
        return lakeCollider;
    }
}