public class main {
    public static void main(String[] args) {
        Simulator newSim = new Simulator(150, 150);
        newSim.simulate(10 * 365 * 24);
    }
}
