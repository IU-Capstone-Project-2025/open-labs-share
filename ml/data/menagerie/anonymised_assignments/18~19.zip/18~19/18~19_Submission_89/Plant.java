import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public abstract class Plant extends Organism {
    // Associated collision object for plants
    private static final PlantCollider plantCollider = new PlantCollider();
    // Current maturity of plant, max maturity indicates plant can reproduce
    protected double maturity;
    // Used to check if plant is still a seed
    protected boolean isSeed;
    // Used to check if plant has matured
    protected boolean matured;
    // Reference to list all plants in simulation
    protected ArrayList<Organism> plants;

    // Location of seed
    protected Location seedLoc;
    // Reference to the associated climate
    protected Weather weather;

    // Locations a plant occupies at a given time
    protected ArrayList<Location> locations;

    public Plant(Field field, Location seedLoc, Weather weather,ArrayList<Organism> plants, boolean randMaturity) {
        super(field);
        this.plants = plants;
        this.weather = weather;
        this.matured = false;
        this.maturity = 0;
        this.isSeed = true;

        if (randMaturity) {
            Random r = new Random();
            // Set trees to be fully matured from the start
            if (r.nextInt(2) == 0) {
                if (isValidLoc(seedLoc)) {
                    this.maturity = getMaxMaturity();
                    this.isSeed = false;
                }
            }
        }
        this.seedLoc = seedLoc;
        this.locations = new ArrayList();
    }

    /**
     *  Protected function to get the maturity
     * @return  maturity
     */

    protected double getMaturity() { return maturity; }

    //Protected function to get the MaxMaturity
    protected abstract double getMaxMaturity();
    //Protected function to get the optimalTemp
    protected abstract double getOptimalTemp();
    //Protected function to get the optimal Rainfall
    protected abstract double getOptimalRainfall();
    //Protected function to make the plant germinate
    protected abstract void germinate();
    //Protected function to make the plant mature
    protected abstract void mature();
    //Protected function for the plant to breed and add the new instance to the list newPlants
    protected abstract void breed(List<Organism> newPlants);
    // Check if a given location is valid to drop a berry
    protected abstract boolean isValidLoc(Location location);

    /**
     * Simulate growth for one step.
     * This may result in maturity and even death of a plant.
     */
    protected void grow() {
        if (age > getMaxAge()) {
            setDead();
            return;
        }
        maturity += getGrowthRate();
        if (maturity > getMaxMaturity() && !matured) {
            maturity = getMaxMaturity();
            mature();
        }
        age++;
    }

    /**
     * The growth rate of a plant is modelled as an exponential square function.
     * Growth rate is computed using temperature and rainfall at current step.
     */
    protected double getGrowthRate() {
        // Constants to ensure max growth rate is at given temperature and rainfall
        double alpha = getOptimalTemp() / 8;
        double beta = getOptimalRainfall() / 4;

        double temp = weather.getTemperature();
        double rainfall = weather.getPrecipitation();

        // Growth rate is modelled as a multivariate function of temperature and rainfall
        double tempGrowthRate = Math.exp(-1 * Math.pow((temp / 8.0) - alpha, 2));
        double rainGrowthRate = Math.exp(-1 * Math.pow((rainfall / 4.0) - beta, 2));

        return tempGrowthRate * rainGrowthRate;
    }

    public Collider getCollider() {
        return plantCollider;
    }
}