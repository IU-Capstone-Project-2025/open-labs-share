import java.util.List;

public abstract class Organism extends Entity {
    protected int age;
    protected boolean isAlive;

    public abstract void act(List<Organism> newOrganisms);
    protected abstract void setDead();
    public abstract int getMaxAge();

    public int getAge() {return age;}

    /**
     * Increase the age.
     * This could result in the organism's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    public boolean isAlive() {return isAlive;}

    Organism(Field field) {
        super(field);
        age = 0;
        isAlive = true;
    }
}
