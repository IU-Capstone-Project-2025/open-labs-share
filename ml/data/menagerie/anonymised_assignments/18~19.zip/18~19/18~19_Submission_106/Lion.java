
/**
 * A simple model of a Lion
 *
 */
public class Lion extends Predator
{
    public Lion(boolean randomAge, Field field, Location location,String animalName,Field plantField)
    {
        super(randomAge,field, location,animalName,plantField);
        //Lions can only act during and noon
        addActingPeriod(2);
    }
}
