import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;

/**
 * A simple model of a predator.
 * Predators age, move, eat prey, spread disease, reproduce, and die.
 */
public class Predator extends Animal
{
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the predator will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalName The species of the predator.
     * @param plantField The field of plants associated with the predator.
     */
    public Predator(boolean randomAge, Field field, Location location,String animalName,Field plantField)
    {
        super(field, location,randomAge,animalName,plantField);
    }
    
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()) { 
                    prey.setDead();
                    incrementFoodLevel(getProperty()[4]);
                    return where;
                }
            }
        }
        return null;
    }
    
    
}
