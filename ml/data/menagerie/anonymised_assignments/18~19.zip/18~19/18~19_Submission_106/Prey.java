import java.util.*;

/**
 * A simple model of a prey.
 * Prey animals age, move, breed, eat plants, spread the disease, and die.
 */
public class Prey extends Animal
{
    private static final Random rand = Randomizer.getRandom();;

    /**
     * Create a new prey. A prey may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the prey will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param animalName The species of the prey.
     * @param plantField The field of plants from which the animal can eat.
     */
    public Prey(boolean randomAge, Field field, Location location,String animalName,Field plantField)
    {
        super(field, location,randomAge,animalName,plantField);
    }
    
    /**
     * Make the prey look around it for plants to be eaten.
     * 
     */
    public Location findFood()
    {
        Field field = getPlantField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Plant) {
                Plant pplant = (Plant) plant;
                if(pplant.isAlive()) { 
                    pplant.setDead();
                    incrementFoodLevel(pplant.getFoodValue());
                    return where;
                }
            }
        }
        return null;
    }
}
