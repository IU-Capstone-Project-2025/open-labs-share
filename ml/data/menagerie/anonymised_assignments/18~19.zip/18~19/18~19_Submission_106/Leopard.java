
/**
 * A simple model of a Leopard
 *
 * @version 2019.02.21 (2)
 */
public class Leopard extends Predator
{
    public Leopard(boolean randomAge, Field field, Location location,String animalName,Field plantField)
    {
        super(randomAge,field, location,animalName,plantField);
        //Leopards can only act at noon or during the evening
        addActingPeriod(2);
        addActingPeriod(3);
    }
}
