import java.util.*;
/**
 * This is a class for the weather types in the game
 *
 *
 * @version 2019.02.21 (2)
 */
public class Weather
{
    //an integer which is set on 0 for sunny weather, and on 1 is rainy
    private int weatherID;
    //lasting time of the weather
    private int remainTime;
    //the maximum time for continous sunny day and rainy day
    private final static int[] Max_Times={20,8};
    // Whether the weathers are currently up to date.
    private boolean valid;
    
    private final static Random rand=new Random();
    
    

    /**
     * Create a weather with the given weatherID.
     * @param weatherID an integer which 0 is sunny, 1 is rainy
     */
    public Weather(int weatherID)
    {
        this.weatherID=weatherID;
        remainTime=rand.nextInt(Max_Times[weatherID]);
        valid=true;
    }

    public int getWeatherID()
    {
        // put your code here
        return weatherID;
    }
    
    /**
     * Decrease the remain time of the current weather
     */
    public boolean decRemainTime()
    {
        remainTime--;
        if (remainTime <0)
        {
            valid=false;
        }
        return valid;
    }
    
    
    public int getRemainTime()
    {
        return remainTime;
    }
    
    
    public String getWeatherName()
    {
        if (weatherID==0)
        {
            return "Sunny";
        }
        else{
            return "rainy";
        }
    }
    
    
    
}
