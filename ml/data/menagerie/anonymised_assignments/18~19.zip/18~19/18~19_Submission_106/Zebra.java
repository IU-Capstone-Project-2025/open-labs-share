
/**
 * A simple model of a zebra
 *
 *
 * @version 2019.02.21 (2)
 */
public class Zebra extends Prey
{
    /**
     * Constructor for objects of class Zebra
     */
    public Zebra(boolean randomAge, Field field, Location location,String animalName,Field plantField)
    {
        super(randomAge,field, location,animalName,plantField);
        // Zebras can only act during the morning, at noon, or during the evening 
        addActingPeriod(1);
        addActingPeriod(2);
        addActingPeriod(3);
    }
}
