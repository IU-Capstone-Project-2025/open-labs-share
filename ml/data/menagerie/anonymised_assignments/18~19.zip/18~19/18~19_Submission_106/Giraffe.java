
/**
 * A simple model of a Giraffe
 *
 * @version 2019.02.21 (2)
 */
public class Giraffe extends Prey
{
    public Giraffe(boolean randomAge, Field field, Location location,String animalName,Field plantField)
    {
        super(randomAge,field, location,animalName,plantField);
        //Giraffes can only act during noon and evening.
        addActingPeriod(2);
        addActingPeriod(3);
    }
}
