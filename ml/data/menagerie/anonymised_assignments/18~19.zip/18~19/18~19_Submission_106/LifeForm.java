import java.util.*;
/**
 * Abstract class LifeForm - an abstract class used for both animals and plants in the simulation
 */
public abstract class LifeForm
{
    
    // The life form's field.
    private Field field;
    // The life form's position in the field.
    private Location location;
    // The life form's age.
    private int age;
    // The life form is alive or not.
    private boolean alive;
    
    /**
     * Constructor for the LifeForm class
     */
    public LifeForm(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
  
    abstract public void act(List<LifeForm> newLifeForm, int step);

    /**
     * Place the life form at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    protected void setAge(int age)
    {
        this.age=age;
    }
    protected void incAge()
    {
        age++;
    }
    protected void decAge()
    {
        age--;
    }
    
      protected Location getLocation()
    {
        return location;
    }
    protected Field getField()
    {
        return field;
    }
    /**
     * Check whether the life form is alive or not.
     * @return true if the life form is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    protected int getAge()
    {
        return age;
    }
    /**
     * Indicate that the life form is no longer alive.
     * It is has no more location in the field
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
        }
    }
}
