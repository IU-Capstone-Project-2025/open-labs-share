import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing trexes, triceratopses, ankylosaurs, raptors, flowers, cycads
 * and ocassionally meteors. The simulation keeps track of time and weather.
 *
 * @version 2019.02.20
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    
    // a global variable to indicate how many steps per day we have
    // this can be changed, however it is recomended that there are at least 24
    // note that changing this will impact the stability of the population
    public static final int STEPS_PER_DAY = 24;
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a trex will be created in any given grid position.
    private static final double TREX_CREATION_PROBABILITY = 0.016;
    // The probability that a triceratops will be created in any given grid position.
    private static final double TRICERATOPS_CREATION_PROBABILITY = 0.1; 
    // The probability that a ankylosaurs will be created in any given grid position.
    private static final double ANKYLOSAURS_CREATION_PROBABILITY = 0.13;  
    // The probability that a raptor will be created in any given grid position.
    private static final double RAPTOR_CREATION_PROBABILITY = 0.015;   
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.16;    
    // The probability that a flower will be created in any given grid position.
    private static final double FLOWER_CREATION_PROBABILITY = 0.25; 
    
    // Define all colors for object that will be shown on the grid
    private static final Color METEOR_COLOR = Color.MAGENTA; 
    private static final Color TREX_COLOR = new Color(183, 28, 28);
    private static final Color TRICERATOPS_COLOR = new Color(161, 136, 127); 
    private static final Color ANKYLOSAURUS_COLOR = new Color(78, 52, 46);
    private static final Color RAPTOR_COLOR = new Color(239, 83, 80);   
    private static final Color MOUSE_COLOR = new Color(197, 202, 233);
    private static final Color FLOWER_COLOR = new Color(234, 128, 252);   
    private static final Color CYCAD_COLOR = new Color(129, 199, 132);

    // List of animals in the field.
    private List<Animal> animals;
    // List of animals in the field.
    private List<Plant> plants;
    // The meteor that will occasionally wipe out animals in a square
    private Meteor meteor;
    // An object to generate weather conditions
    private Weather weatherGenerator;
    // What the current weather is 
    private String weather;
    // The current time of the day (calculated based on STEPS_PER_DAY);
    private int hour;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The graphical views of the simulation.
    private List<SimulatorView> views;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        // Instantiate all private fields
        this.field = new Field(depth, width);
        this.animals = new ArrayList<>();
        this.plants = new ArrayList<>();
        this.weatherGenerator = new Weather();
        this.weather = weatherGenerator.getWeather();
        this.hour = 0;
        this.meteor = new Meteor(field);
        this.views = new ArrayList<>();

        // Create a grid view and add it to the views ArrayList
        SimulatorView view = new GridView(depth, width);
        view.setColor(Trex.class, TREX_COLOR);
        view.setColor(Raptor.class, RAPTOR_COLOR);
        view.setColor(Triceratops.class, TRICERATOPS_COLOR);
        view.setColor(Ankylosaurs.class, ANKYLOSAURUS_COLOR);
        view.setColor(Mouse.class, MOUSE_COLOR);
        view.setColor(Cycad.class, CYCAD_COLOR);
        view.setColor(Flower.class, FLOWER_COLOR);
        view.setColor(Meteor.class, METEOR_COLOR);
        views.add(view);

        //create a graph view and add it to the views ArrayList
        view = new GraphView(500, 150, 500);
        view.setColor(Trex.class, TREX_COLOR);
        view.setColor(Raptor.class, RAPTOR_COLOR);
        view.setColor(Triceratops.class, TRICERATOPS_COLOR);
        view.setColor(Ankylosaurs.class, ANKYLOSAURUS_COLOR);
        view.setColor(Mouse.class, MOUSE_COLOR);
        views.add(view);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state as long as the field 
     * is viable. That is until any animal's population reaches 0.
     */
    public void simulate()
    {
        long startTime = System.currentTimeMillis();

        while(views.get(0).isViable(field)) {
            simulateOneStep();
        }
        
        long endTime = System.currentTimeMillis();

        // print how long the simulation runs for
        // the current configuration runs for 89 seconds on the computers in the lab
        System.out.println("That simulation ran for " + ((endTime - startTime) / 1000) + " seconds.");
    }
    
    /**
     * Run the simulation from its current state as long as the field 
     * is viable. That is until any animal's population reaches 0.
     * Delay between every step.
     * @param delay how long the delay should be (millisec)
     */
    public void simulateWithDelay(int delay)
    {
        while(views.get(0).isViable(field)) {
            simulateOneStep();
            delay(delay);
        }
    }
    
    /**
     * Run the simulation from its current state for as many steps
     * as there are defined to be in a day (24 by default).
     */
    public void simulateOneDay()
    {
        for(int i = 0; i < STEPS_PER_DAY; i ++) {
            simulateOneStep();
            //delay(60) // uncomment this to run slowly
        }
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        plants.clear();
        populate();
        
        // Show the starting state in both views.
        updateViews();
    }
    
    /**
     * Update all existing views.
     */
    private void updateViews()
    {
        for (SimulatorView view : views) {
            view.showStatus(step, field, weather);
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of animal, plant
     * and possibly generate a meteor to wipe out a random part of the field.
     * Keeps track of the time of the day as well as the weather.
     */
    public void simulateOneStep()
    {
        step ++;
        // the hour is calculated based on how many steps per day there are
        hour = (int) (step % STEPS_PER_DAY * 24) / STEPS_PER_DAY;
        // the weather can change twice a day
        if(hour % 12 == 0)
            weather = weatherGenerator.getWeather();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();   

        // Let all animals act, passing on the time and weather 
        // so they can react to that respectively
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, hour, weather);
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Let all plants act, passing on the time and weather 
        // so they can react to that respectively
        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.act(hour, weather);
        }

        // a meteor can only act once a day
        if(hour % 24 == 0)
            meteor.act();
               
        // Add the newly born animals to the existing list
        animals.addAll(newAnimals);
        // repaint views
        updateViews();
    }
    
    /**
     * Randomly populate the field with animals and plants
     */
    private void populate()
    {
        // controled random populating
        Random rand = Randomizer.getRandom();
        // prepare the field
        field.clear();
        // iterate through every square from the grid
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // instantiate animals with respect to their spawn probability
                // in descending order (lowest probability first)
                if(rand.nextDouble() <= TREX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Trex trex = new Trex(true, field, location);
                    animals.add(trex);
                } else if(rand.nextDouble() <= RAPTOR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Raptor raptor = new Raptor(true, field, location);
                    animals.add(raptor);
                } else if(rand.nextDouble() <= TRICERATOPS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Triceratops triceratops = new Triceratops(true, field, location);
                    animals.add(triceratops);
                } else if(rand.nextDouble() <= ANKYLOSAURS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Ankylosaurs ankylosaurs = new Ankylosaurs(true, field, location);
                    animals.add(ankylosaurs);
                } else if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }

                // instansiate a static plant object in a 'chess-like' pattern
                if((col % 2 == 1 && row % 2 == 0) ||
                    col % 2 == 0 && row % 2 == 1) {
                        Location location = new Location(row, col);
                        if(rand.nextDouble() <= FLOWER_CREATION_PROBABILITY) {
                            Flower flower = new Flower(field, location);
                            plants.add(flower);
                        } else {
                            Cycad cycad = new Cycad(field, location);
                            plants.add(cycad);
                        }
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
