/**
 * A model of a Cycad plant. The cycad has a high food worth value.
 * It is a static object on the field and the only thing it can is grow
 * and get eaten, whcih resets how much its grown to 0.
 * The food worth is based on how grown it is
 *
 * @version 2019.02.20
 */
public class Cycad extends Plant
{
    // How much the food level the plant will yield if eaten
    private static final int FOOD_WORTH = 80;

    /**
     * Constructor for objects of type Cycad
     */
    public Cycad(Field field, Location location)
    {
        // pass to the superclass
        super(field, location);
    }

    /**
     * This is how the plant grows. It is based on the time of the day
     * and the current weather.
     * 
     * @param hour the current time
     * @param weather the current weather
     */
    public void act(int hour, String weather)
    {
        // every 2 hours in a certain time frame, the plant grows
        if(hour >= 7 && hour <= 19 && hour % 2 == 1)
            grow((weather.equals("rainy")));
    }

    /**
     * An accessor method for private field.
     * The more the plant is grown the more it will be worth
     * 
     * @return how much the object that ate the Cycad will get fed
     */
    public int getFoodWorth()
    {
        // get a percentage of the foodworth value based on how grown it is
        double temp = percentGrown / 100;
        int n = (int) temp * FOOD_WORTH;
        return n;
    }
}
