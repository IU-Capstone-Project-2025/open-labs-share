/**
 * A class representing all shared characteristics of plants
 *
 * @version 2019.02.20
 */
public abstract class Plant
{
    // A global static variable to indicate the pace of the simulation;
    // initialized in Simulator class
    protected static final int SPD = Simulator.STEPS_PER_DAY;

    // The current simulation's field
    private Field field;
    // The location of the plant
    private Location location;
    // How grown the plant is (max 100)
    protected int percentGrown;

    /**
     * Constructor for children of Plant class
     * Creates a plant at the given location in the field
     * @param field the simulation's field
     * @param location the plant's location to be
     */
    public Plant(Field field, Location location)
    {
        this.field = field;
        setLocation(location);
        this.percentGrown = 100;    
    }

    /**
     * Make this plant act - that is: make it grow based on 
     * weather and the current time
     * 
     * @param hour what hour of the day it is
     * @param weather what the weather is like
     */
    abstract public void act(int hour, String weather);

    protected Field getField()
    {
        return field;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.placePlant(this, newLocation);
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * A method that makes the plant grow
     * Grows faster the the weather is rainy
     * 
     * @param isRainy true if the weather is rainy
     */
    protected void grow(boolean isRainy)
    {
        if(isRainy)
            percentGrown += 50;
        else
            percentGrown += 30;
            
        // make sure it doesnt grow over 100%
        if(percentGrown > 100) 
            percentGrown = 100;
    }
    
    /**
     * a method to indicate that the plant has been eaten,
     * resetting how grown it is.
     */
    protected void setEaten()
    {
        percentGrown = 0;
    }

}
