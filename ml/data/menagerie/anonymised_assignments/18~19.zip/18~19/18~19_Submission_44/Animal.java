import java.util.List;
import java.util.Iterator;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2019.02.20
 */
public abstract class Animal
{
    // A global static variable to indicate the pace of the simulation;
    // initialized in Simulator class
    protected static final int SPD = Simulator.STEPS_PER_DAY;
    // How much any given animal can be fed
    private static final int MAX_FOOD_LEVEL = 100;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's age
    private int age;
    // How fed the animal is (can't go higher than MAX_FOOD_LEVEL)
    private int foodLevel;
    // The animal's gender; true - male; false - female
    private boolean gender;
    // Whether the animal is pregnant or not
    private boolean isPregnant;
    // Used to keep track of how long the animal has been pregnant
    private int pregnancyLength;
    
    /**
     * Create a new animal at a given location in the field.
     * @param randomAge whether the animal's age should be randomized or not
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param maxAge how old the animal can get (used for randomization)
     */
    public Animal(boolean randomAge, Field field, Location location, int maxAge)
    {
        this.alive = true;
        this.field = field;
        setLocation(location);

        // Animals are constructed with a random age in the beginning of the simulation
        if(randomAge) 
            this.age = rand.nextInt(maxAge);
        else 
            this.age = 0;

        // animals are constructed 'well-fed'
        this.foodLevel = MAX_FOOD_LEVEL;

        // random gender
        this.gender = rand.nextBoolean();

        this.isPregnant = false;
        this.pregnancyLength = 0;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param hour what hour of the day it is
     * @param weather what the weather is like
     */
    abstract public void act(List<Animal> newAnimals, int hour, String weather);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */ 
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     * This method needs to public so it can be accessed from java reflection
     * classes
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.placeAnimal(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Used when the animal eats something;
     * Increases the food level of the animal by the food worth
     * of whatever was eaten (plant/another animal)
     * @param val how much the eaten object fed the animal
     */
    protected void eat(int val)
    {
        foodLevel += val;
        //make the animal doesnt get overfed
        if(foodLevel > MAX_FOOD_LEVEL)
            foodLevel = MAX_FOOD_LEVEL;
    }

    /**
     * Check if the animal is hungry enough to look for food
     * @return true if the animal is 50% hungry
     */
    protected boolean isHungry()
    {
        return ((double) foodLevel/MAX_FOOD_LEVEL < 0.5);
    }

    /**
     * This method needs to be public so it can be accessed by 
     * java.lang.reflect classes
     * Check if an animal is old enough to breeding
     * An animal can breed if it has reached its breeding age
     * @param breedingAge how old the animal needs be 
     * @return true if the animal is old enough
     */
    public boolean canBreed(int breedingAge)
    {
        return (age >= breedingAge);
    }

    /**
     * Ages the animal, make it hungrier by decrementing
     * its food level (dies if it gets to 0)
     * and increment its age (dies if it gets older than its max age)
     * @param max the animal's maximum age
     */ 
    protected void age(int max)
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
            // animal is already dead, no need to continue
            return;
        }

        age++;
        if(age > max) 
            setDead();
    }

    /**
     * Check if two animals are of opposite genders
     * @param adjAnimalGender the gender (boolean) of an animal
     * @return true if the parameter is not the same as the gender of 'this' animal
     */
    protected boolean isOppositeGender(boolean adjAnimalGender)
    {
        return !(this.gender == adjAnimalGender);
    }

    /**
     * This method needs to be pulbic so that it can be accessed
     * from the java.lang.reflect classes.
     * @return the animal's gender (true - male, false - female)
     */
    public boolean getGender()
    {
        return gender;
    }

    /**
     * This method needs to be pulbic so that it can be accessed
     * from the java.lang.reflect classes.
     * @return true if pregnant
     */
    public boolean isPregnant()
    {
        return isPregnant;
    }

    /**
     * This method needs to be pulbic so that it can be accessed
     * from the java.lang.reflect classes.
     * Indicates that the animal has been impregnated 
     */
    public void setPregnant()
    {
        if(!isPregnant()) {
            isPregnant = true;
            pregnancyLength = 0;
        }
    }

    /**
     * The animal tries to give birth to young ones in free adjacent locations.
     * This method uses dynamic run-time casting which has been achieved with the help
     * of java.lang.reflect library
     * @param newAnimals A list to store the newly constructed animals
     * @param pregnancyDuration How long the animal has been pregnant
     * @param maxLitter The maximum number of children the animal can breed
     */
    protected void giveBirth(List<Animal> newAnimals, int pregnancyDuration, int maxLitter)
    {
        if(isPregnant && isAlive()) {
            //if the animal has been pregnant long enough
            if(pregnancyLength == pregnancyDuration) {
                // get the free adj. location where the kids will be bron
                Field field = getField();
                List<Location> free = field.getFreeAdjacentLocations(getLocation());
                // generate a random number of children that will be bred
                int births = 0;
                // between 1 and the maximum for the given animal
                births = rand.nextInt(maxLitter) + 1;

                // spawn kids as long as there are free locations left
                for(int b = 0; b < births && free.size() > 0; b++) {
                    try {
                        // get the first free location
                        Location loc = free.remove(0);

                        // get the class type of 'this' (the animal that invoked the method)
                        Class<?> youngAnimal = Class.forName(this.getClass().getName());

                        // make a constructor object with the required parameters
                        Constructor<?> cons = youngAnimal.getConstructor(boolean.class,Field.class,Location.class);

                        // instantiate a kid that wont get a random age, at the free locaton
                        Animal kid = (Animal) cons.newInstance(false, field, loc);

                        // add the kid to the list of new animals
                        newAnimals.add(kid);
                    } catch (Exception e) {
                        System.out.println("Error when spawning kids");
                    } 
                }

                // the female is no longer pregnant
                pregnancyLength = 0;
                isPregnant = false;
            }
            else // the animal has not been pregnant for long enough
                pregnancyLength ++;
        }
    }

    /**
     * This method is called at certain times of the day by the males
     * They search for females of the same type in adjacent location and have 
     * a chance to mate with them.
     * This method is using java.lang.reflect classes so that it can dynamically call
     * methods from different animal classes.
     * @param breedingProbability The animals probability to mate.
     */
    protected void procreate(double breedingProbability)
    {
        // try to find a female in adj. lcoation 
        Object female = searchForPartner();

        // check if a female has been found and 'roll a dice'
        if(female != null && rand.nextDouble() <= breedingProbability) {
            try {
                // create an object of type Method which holds the setPregnant method for
                // for the female that was retrieved
                Method m =  female.getClass().getSuperclass().getMethod("setPregnant");
                // invoke the method, making the female pregnant
                m.invoke(female);
            } catch(Exception e) {
                System.out.println("Error when setting female pregant");
            }
        }
    }

    /**
     * This method is used to search for females in adjacent locations
     * to the animal that has invoked it. It uses java.lang.reflect to check the gender and
     * if she is at an appropriate age to breed
     * @return an animal Object, if found and null if not
     */
    private Object searchForPartner()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        // iterate through adjacent locations
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location here = it.next();
            // fetch whatever object is at the location
            Object animal = field.getAnimalAt(here);

            // if its not null then it must be an animal because the getAnimalAt() method only returns
            // animals and not plants or meteors which are stored in a different 'layer' of the 3D array
            // from the Field class. We also check if the animal matches the class of 'this' (the animal
            // that invoked the method
            if(animal != null && animal.getClass().getName().equals(this.getClass().getName())) {
                try {
                    // create an object of type method that stores the getGender() method for the animal
                    Method getGender =  animal.getClass().getSuperclass().getMethod("getGender");
                    // store wahtever is returned after invoking the method (true means male and false means female)
                    Object receivedGender =  getGender.invoke(animal);

                    // as the method returns a boolean value we can safely cast it and pass it along to get
                    // checked if its opposite  
                    if(isOppositeGender((boolean) receivedGender)) {
                        // now that we have found a female we make sure she is of appropriate breeding age
                        Method getBreedingAge =  animal.getClass().getMethod("getBreedingAge");
                        // store the returned int in an Object type
                        Object receivedBreedingAge =  getBreedingAge.invoke(animal);

                        Method canBreed =  animal.getClass().getSuperclass().getMethod("canBreed", int.class);
                        // check if the animal can breed by passing an the int with casting
                        Object femaleCanBreed =  canBreed.invoke(animal, (int) receivedBreedingAge);

                        // safely cast the Object to a boolean because we know that canBreed returns boolean;
                        if((boolean) femaleCanBreed)
                            // we have found a viable female of the same class and of age to breed
                            return animal;
                    }
                } catch(Exception e) {
                    System.out.println("Error when checking isOppositeGender");
                }
            }
        }
        return null;
    }
}
