/**
 * A main class for the simulation.
 * Instantiates a simulator and begins the simulation
 *
 * @version 2019.02.20
 */
public class SimulatorMain
{
    public static void main(String[] args) {
        Simulator simulator = new Simulator(); 
        // runs until an animal's population is 0 with 50 ms delay between steps
        simulator.simulateWithDelay(50);       
    }
}