import java.util.Random;
import java.lang.reflect.Method;

/**
 * A meteor class to generate meteors of random sizes 
 * between 4x4 and 20x20 that wipe out all animals in a square.
 * They can be seen in the GUI for a split second.
 * The chance of a meteor dropping is low.
 *
 * @version 2019.02.20
 */
public class Meteor
{
    // controlled meteor dropping
    private static final Random rand = Randomizer.getRandom();
    // the likelihood of a meteor dropping
    private static final double METEOR_DROP_PROBABILITY = 0.03;

    private Field field;
    private Location location;
    
    /**
     * Constructor for objects of class Metor
     */
    public Meteor(Field field)
    {
        // get the simualtion's field
        this.field = field;
        // the meteor is not spawned yet - has no location
        this.location = null;
    }

    public void act()
    {
        if(rand.nextDouble() <= METEOR_DROP_PROBABILITY) {
            
            // determine the half of the meteor's size
            int size = 0;
            size = rand.nextInt(8) + 2;

            // get the location of the center of the meteor,
            // making sure that it doesnt go out of the field
            int randRow = 0;
            int randCol =  0;
            randRow = rand.nextInt(field.getDepth() - size * 2 - 1) + size + 1;
            randCol = rand.nextInt(field.getWidth() - size * 2 - 1) + size + 1;    

            // iterate through all location in a square around the center of the meteor
            for (int i = randRow - size + 1; i <= randRow + size - 1; i ++)
            {
                for(int j = randCol - size + 1; j <= randCol + size - 1; j ++)
                {
                    // get the current loc
                    this.location = new Location(i, j);
                    Object animal = field.getAnimalAt(location);
                    // check if there is an animal at that location
                    if(animal != null) {
                        try {
                            // invoke the animal's setDead meethod with java reflection
                            Method m = animal.getClass().getSuperclass().getMethod("setDead");
                            m.invoke(animal);
                        } catch(Exception e) {
                            System.out.println("Error when killing animals with meteor");
                        }
                    }
                    
                    // indicate that a meteor has dropped in the square (used for GUI representation)
                    field.placeMeteor(this, location);
                }
            }   

            // Print out coordinates of the square that the meteor has wiped
            System.out.println("A meteor of size " + (size*2) + "x" + (size*2) +  
                               " has cleared animals in the square (x value,y value):");
            System.out.println("(" + (randCol - size) + "," + (randRow - size) + ")" + " --- " +
                               "(" + (randCol + size) + "," + (randRow - size) + ")");
            System.out.println("|                 |");
            System.out.println("|                 |");
            System.out.println("(" + (randCol - size) + "," + (randRow + size) + ")" + " --- " +
                               "(" + (randCol - size) + "," + (randRow + size) + ")");
            System.out.println();

            // the meteor only exists for a step
            this.location = null;
        }
    }
}
