import java.util.List;
import java.util.Iterator;

/**
 * A model of a trex. Trexes move, breed, eat (animals),
 * age and die
 *
 * @version 2019.02.20
 */
public class Trex extends Animal
{
    // Characteristics shared by all Trexes (class variables).
    
    // The age at which a Trex can start to breed.
    private static final int BREEDING_AGE = 20 * SPD;
    // The age to which a Trex can live.
    private static final int MAX_AGE = 200 * SPD;
    // The likelihood of a Trex breeding.
    private static final double BREEDING_PROBABILITY = 0.85;
    // The maximum number of births.    
    private static final int MAX_LITTER_SIZE = 2;
    //The duration of the animal's pregnancy
    private static final int PREGNANCY_DURATION = 4 * SPD;

    /**
     * Constructor for objects of class Trex
     */
    public Trex(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, MAX_AGE);
    }

    /**
     * This is what the Trex does most of the time: it looks for
     * food (animals), moves, procreates or dies in the meanwhile.
     * It is dependant on what time of the day it is and the weather
     * 
     * @param newTrexes A list to return newly born trexes.
     * @param hour what the current time is
     * @param weather what the current weather is
     */
    public void act(List<Animal> newTrexes, int hour, String weather)
    {
        age(MAX_AGE);
        if(isAlive()) {
            //if the animal is male and is over the breeding age
            if(getGender() && canBreed(BREEDING_AGE)) {
                if(hour >= 12 && hour <= 18)
                    //look for females in adjacent locations
                    procreate(BREEDING_PROBABILITY);  
            }
            //if the animal is female
            else
                //try to give birth (if it has been pregnant for long enough)
                giveBirth(newTrexes, PREGNANCY_DURATION, MAX_LITTER_SIZE); 
            
            // every 6 hours in the specified time frame
            if(hour >= 8 && hour <= 21 && hour % 6 == 0) {
                    Location newLocation = null;
                    // Move towards a source of food if hungry and its not foggy
                    if(isHungry() && !(weather.equals("foggy")))
                        newLocation = findFood();
                    if(newLocation == null) { 
                        // No food found - try to move to a free location.
                        newLocation = getField().freeAdjacentLocation(getLocation());
                    }
                    // See if it was possible to move.
                    if(newLocation != null) {
                        setLocation(newLocation);
                    }
                    else 
                        // Overcrowding.
                        setDead();
            }
        }
    }

    /**
     * Look Raptors, Triceratopses or Ankylosaurs in adjacent location and eat them
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        // iterate through adj. locations
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getAnimalAt(where);
            // if there is a Triceratops
            if(animal instanceof Triceratops) {
                // safely cast
                Triceratops triceratops = (Triceratops) animal;
                if(triceratops.isAlive()) { 
                    triceratops.setDead();
                    // get the animal's food worth and eat
                    eat(triceratops.getFoodWorth());
                    // end the method - not looking for more than one animal
                    return where;
                }
            }

            // if there is a Raptor
            if(animal instanceof Raptor) {
                // safely cast
                Raptor raptor = (Raptor) animal;
                if(raptor.isAlive()) { 
                    // get the animal's food worth and eat
                    eat(raptor.getFoodWorth());
                    raptor.setDead();
                    // end the method - not looking for more than one animal
                    return where;
                }
            }

            // if there is an Ankylosaurs
            if(animal instanceof Ankylosaurs) {
                // safely cast
                Ankylosaurs ankylosaurs = (Ankylosaurs) animal;
                if(ankylosaurs.isAlive()) { 
                    ankylosaurs.setDead();
                    // get the animal's food worth and eat
                    eat(ankylosaurs.getFoodWorth());
                    // end the method - not looking for more than one animal
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * A method required for the java reflection used in the super class
     * It is invoked to fetch the breeding age of a female at run-time
     * @return BREEDING_AGE private field of 'this'
     */
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
}
