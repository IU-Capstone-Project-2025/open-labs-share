import java.util.Random;

/**
 * Simple Enum for Gender
 */
public enum Gender
{
    // Define the two genders
    MALE,
    FEMALE;
    
    // Create randomizer object
    private static final Random RANDOM = new Random();
    
    /**
     * Method to return a random gender with a 50/50 chance of it being male/female
     * @return A random gender
     */
    public static Gender randomGender() {
        int randInt = RANDOM.nextInt(2); // Get a random integer which is either 0 or 1
        if(randInt == 1) return MALE; // If random integer is 1, return male else return female
        return FEMALE;
    }
}
