import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * A simple model for a Hawk, Hawks eat mice, and compete with Wolves and snakes.
 *
 */
public class Hawk extends Animal
{
  // Characteristics shared by all hawks (class variables).
    
    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a hawk can live.
    private static final int MAX_AGE = 300;
    // The likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food values of single prey animals. In effect, these make up the
    // number of steps a Wolf can go before it has to eat again.
    private static final int MOUSE_FOOD_VALUE = 50;
    private static final int SNAKE_FOOD_VALUE = 50;
    private static final int WOLF_FOOD_VALUE = 50;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The snakes' age.
    private int age;
    // The hawk's food level, which is increased by eating other animals.
    private int foodLevel;
    
    /**
     * Constructor for a Hawk.
     * @param randomAge If true, the Hawk will be created with a random age
     * @param Field The field of the Hawk
     * @param Location The location of the Hawk
     */
    public Hawk(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MOUSE_FOOD_VALUE + SNAKE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = MOUSE_FOOD_VALUE + SNAKE_FOOD_VALUE;
        }
    }
    
    /**
     * Act method for the Hawk, controls it's behaviour
     * @param List of new Hawks to be created
     */
    @Override
    public void act(List<Animal> newHawks)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHawks);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(isAlive()) {
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
    }
    
    /**
     * Method for the Hawk to find the nearest mice, Wolves or snakes
     * @return Location The location of the neareast prey or null if there is none
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive()) { 
                    mouse.setDead();
                    foodLevel = this.getFoodLevel() + MOUSE_FOOD_VALUE;
                    if(mouse.isInfected()) this.infect();
                    return where;
                }
            }
            if(animal instanceof Snake) {
                Snake snake = (Snake) animal;
                if(snake.isAlive()) {
                    if(this.getStrength() > snake.getStrength()) {
                        snake.setDead();
                        foodLevel = this.getFoodLevel() + SNAKE_FOOD_VALUE;
                        if(snake.isInfected()) this.infect();
                        return where;
                    } else {
                        this.setDead();
                        snake.setFoodLevel(50);
                        return null;
                    }
                }
            }
            if(animal instanceof Wolf) {
                Wolf wolf = (Wolf) animal;
                if(wolf.isAlive()) {
                    if(this.getStrength() > wolf.getStrength()) {
                        wolf.setDead();
                        foodLevel = this.getFoodLevel() + WOLF_FOOD_VALUE;
                        if(wolf.isInfected()) this.infect();
                        return where;
                    } else {
                        this.setDead();
                        wolf.setFoodLevel(50);
                        return null;
                    }
                }
            }
            if(animal instanceof Plant) {
                Plant plant = (Plant) animal;
                if(plant instanceof SpecialPlant && this.isInfected()) { // If the rabbit is infected, and eats a special plant, the rabbit is cured.
                    this.cure();
                    plant.setDead();
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Method for the Hawk to give bith
     * @param List of new hawks
     */
    private void giveBirth(List<Animal> newHawks)
    {
        // New hawks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hawk) {
                Hawk hawk = (Hawk) animal;
                if(hawk.isAlive() && hawk.gender != this.gender) {
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Hawk young = new Hawk(false, field, loc);
                        if(this.isInfected()) {
                            young.infect();
                        }
                        newHawks.add(young);
                    }
                    break;
                }
            }
        }
    }
    
    /**
     * Method to increment the age of the hawk
     */
    private void incrementAge(){
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Method to decrement the foodLevel of the hawk
     */
    private void incrementHunger() {
        if(this.isInfected()) foodLevel -= 3;
        else foodLevel--;
        
        if(foodLevel <= 0) this.setDead();
    }
    
    /**
     * Getter for the foodLevel field.
     */
    private int getFoodLevel() {
        return foodLevel;
    }
    
    /**
     * Getter for the strength field.
     */
    public int getStrength() {
        return BASE_STRENGTH + age;
    }
    
    /**
     * Method to check whether the hawk is able to breed
     * @return True/False depending on whether the hawk can breed yet or not
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Setter for the foodLevel field
     * @param Increment the amount to increase the foodLevel by
     */
    public void setFoodLevel(int increment) {
        this.foodLevel += increment;
    }
    
    /**
     * Generates a random number of offspring depending on the breeding probability and the max litter size
     * @return The number of offspring
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
