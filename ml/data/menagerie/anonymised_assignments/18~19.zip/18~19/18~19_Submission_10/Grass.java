import java.util.List;

/**
 * Simple model for grass
 */
public class Grass extends Plant
{
    // Grass has a chance to spawn a special plant alongside it, but very rarely
    private static final double SPECIAL_PLANT_RATE = 0.001;
    // The growth rate of grass
    private double growthRate = 0.5;
    // Number of steps grass can live before it dies
    private int health = 1000;
    
    /**
     * Constructor for the Grass object
     * @param Field The field of the grass
     * @param Location The location of the grass
     */
    public Grass(Field field, Location location) {
        super(field, location); // Call the superclass constructor
    }
    
    /**
     * Controls how grass grows
     * @param newGrass list of newly grown grass
     */
    @Override
    public void grow(List<Plant> newGrass) {
        update(); // Update the state of the grass
        if(this.isAlive()) { // Check if grass is alive, if it is, try spreading it
            spread(newGrass);
        }
    }
    
    /**
     * Method to control how grass spreads
     * @param newGrass list of newly grown grass
     */
    private void spread(List<Plant> newGrass) {
        Field field = this.getField();
        List<Location> free = field.getFreeAdjacentLocations(this.getLocation());
        for(Location location : free) { // For each location, try to grow grass and special grass
            if(rand.nextDouble() <= growthRate) {
                Grass offspring = new Grass(field, location);
                newGrass.add(offspring);
            }
            else if(rand.nextDouble() <= SPECIAL_PLANT_RATE) {
                SpecialPlant spec = new SpecialPlant(field, location);
                newGrass.add(spec);
            }
        }
    }
    
    /**
     * Controls decay, and growth rate depending on the weather
     */
    private void update() {
        this.health--;
        if(this.health <= 0) {
            this.setDead();
            return;
        }
     
        if(State.WEATHER.getValue() == Value.RAINY) {
            this.growthRate = 1.0;
        }
        else if(State.WEATHER.getValue() == Value.SNOWY) {
            this.growthRate = 0.2;
        } 
        else {
            this.growthRate = 0.5;
        }
    }
}
