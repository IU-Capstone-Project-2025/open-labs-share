
import java.util.Random;

/**
 * Contains all the possible values of the time and weather states
 *
 */
public enum Value
{
    DAY,
    NIGHT,
    RAINY,
    SUNNY,
    SNOWY,
    FOGGY;
    
    private static final Value[] WEATHERS = {RAINY, SUNNY, SNOWY, FOGGY};
    private static final Random RANDOM = new Random();
    private static final int SIZE = WEATHERS.length;
    
    /**
     * Method for getting a random weather value
     * @return A random Weather
     */
    public static Value randomWeather() {
        int randomIndex = RANDOM.nextInt(SIZE);
        return WEATHERS[randomIndex];
    }
    
    /**
     * @return String The string representation of the value enum
     */
    public String toString() {
        switch(this) {
            case DAY:
                return "Day";
            case NIGHT:
                return "Night";
            case RAINY:
                return "Rainy";
            case SUNNY:
                return "Sunny";
            case SNOWY:
                return "Snowy";
            case FOGGY:
                return "Foggy";
            default:
                return "Error";
        }
    }
}
