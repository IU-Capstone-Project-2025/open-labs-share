import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a mouse.
 * Mice age, move, breed, and die.
 *
 */
public class Mouse extends Animal
{
    // Characteristics shared by all mice (class variables).

    // The age at which a mouse can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a mouse can live.
    private static final int MAX_AGE = 400;
    // The likelihood of a mouse breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The amount of steps a mouse can go before having to eat again.
    private static final int PLANT_FOOD_VALUE = 150;
    // Individual characteristics (instance fields).
    
    // The mouse's age.
    private int age;
    // The mouse's food level
    private int foodLevel;

    /**
     * Create a new mouse. A mouse may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the mouse will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Mouse(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt();
        } else {
            age = 0;
            foodLevel = 1;
        }
    }
    
    /**
     * This is what the mouse does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newMice A list to return newly born mice.
     */
    public void act(List<Animal> newMice)
    {
        incrementAge();
        incrementHunger();
        tryInfect();
        if(isAlive()) {
            giveBirth(newMice);            
            // Try to move into a free location.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    
    
    /**
     * Check whether or not this mouse is able to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newMice A list to return newly born mice.
     */
    private void giveBirth(List<Animal> newMice)
    {
        // New mice are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Mouse) {
                Mouse mouse = (Mouse) animal;
                if(mouse.isAlive() && mouse.gender != this.gender) {
                    int births = breed();
                    for(int b = 0; b < births && free.size() > 0; b++) {
                        Location loc = free.remove(0);
                        Mouse young = new Mouse(false, field, loc);
                        if(this.isInfected()) {
                            young.infect();
                        }
                        newMice.add(young);
                    }
                    break;
                }
            }
        }
    }
    
    /**
     * Find food for the mouse, the mouse only eats plants
     * @return Location location of the food, null if none is found
     */
    private Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object obj = field.getObjectAt(where);
            if(obj instanceof Plant) {
                Plant plant = (Plant) obj;
                if(plant instanceof SpecialPlant && this.isInfected()) {
                    this.cure();
                }
                this.foodLevel += PLANT_FOOD_VALUE;
                plant.setDead();
                return where;    
            }
        }
        return null;
    }
    
    /**
     * Method to increment the age of the mouse
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Method to decrement the foodLevel of the mouse
     */
    private void incrementHunger() {
        if(this.isInfected()) foodLevel -= 3;
        else foodLevel--;
        if(foodLevel <= 0) setDead();
    }
    
    /**
     * Getter for the foodLevel field
     */
    private int getFoodLevel() {
        return foodLevel;
    }
    
    /**
     * Getter for the strength level
     */
    public int getStrength() {
        return BASE_STRENGTH + age;
    }
    
    /**
     * Checks whether a mouse can breed yet
     * @return True/False depending on whether the mouse can breed
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }
    
    /**
     * Generates a random number of offspring depending on the breeding probability and max litter size
     * @return Number of offspring
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
}
