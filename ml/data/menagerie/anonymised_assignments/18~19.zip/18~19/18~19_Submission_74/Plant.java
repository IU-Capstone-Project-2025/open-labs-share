import java.util.List;
import java.util.Random;

/**
 * An abstract class that represents plants
 *
 * @version 2019.02.22
 */
public abstract class Plant extends LivingThings{
	
	private static final Random rand = Randomizer.getRandom();
	
	//You cannot actually create a plant but as super is called in sub class you can still group construction 
	//similarities at each level of inheritance
	public Plant(boolean randomAge, Field field, Location location) 
	{
		super(field, location);
		
	}
	
	abstract int getFoodValue();
	
}