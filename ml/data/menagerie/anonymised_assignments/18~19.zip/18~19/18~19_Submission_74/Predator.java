import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple predator classF
 *
 * @version 2019.02.22
 */
public abstract class Predator extends LivingThings
{

    private static final Random rand = Randomizer.getRandom();
    
    

    /**
     * Create a predator. A predator can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the predator will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            setAge(rand.nextInt(this.getMaxAge()));
        }
        else {
            setAge(0);
        }
        this.setIsMale(this.fiftyFifty());
    }
    


    /**
     * Make this predator more hungry. This could result in the predator's death.
     * Predators get hungry more quickly than other species
     */
    protected void incrementHunger()
    {
        addFood(-2);
        if(getFoodLevel() <= 0) {
            setDead();
            //System.out.println(this.getClass()+ " has died of hunger");
        }
    }
    
    public void act(List<LivingThings> newPredator)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newPredator);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    } 
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object livingThing = field.getObjectAt(where);
            if(livingThing instanceof Carvidae && getFoodLevel() < 75) 
            {
                Prey prey = (Prey) livingThing;
                if(prey.isAlive()) 
                { 
                	eatPrey(prey);
                    return where;
                }
            }
            else if(livingThing instanceof Rabbit && getFoodLevel() < 40) 
            {
                Prey prey = (Prey) livingThing;
                if(prey.isAlive()) 
                { 
                	eatPrey(prey);
                    return where;
                }
            }
            

            if(livingThing instanceof Beaver && getFoodLevel() < 15) //only go for beavers when rly hungrey
            {
            	//System.out.println("A Beaver just got eaten");
                Prey prey = (Prey) livingThing;
                if(prey.isAlive()) 
                { 
                	eatPrey(prey);
                    return where;
                }
            }
            else if(livingThing instanceof Grass)//If there is grass there move anyway, death represents the scent of the animal making the grass patch an invalid feeding area for prey
            {
            	if(((Grass) livingThing).isAlive())
            	{
            		((Grass) livingThing).setDead();
            		return where;
            	}
            }
            
        }
        return null;
    }
    
    public void eatPrey(Prey prey)
    {
    	prey.setDead();
    	addFood(prey.getFoodLevel());
    	//System.out.println(this.getClass() + " has just eaten a " + prey.getClass());
    }
    
    abstract int getFoodLevel();
    
    abstract void addFood(int foodInput);
    
}
