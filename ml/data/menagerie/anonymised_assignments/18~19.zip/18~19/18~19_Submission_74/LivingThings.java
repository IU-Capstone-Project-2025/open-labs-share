import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A simple Grass class
 *
 * @version 2019.02.22
 */
public abstract class LivingThings
{
    // Whether the living thing is alive or not.
    private boolean alive;
    // The living thing's field.
    protected Field field;
    // The living thing's position in the field.
    private Location location;
    
    
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new living thing at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public LivingThings(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this living thing act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born living things.
     */
    abstract public void act(List<LivingThings> newAnimals);
    
    /**
     * Check whether the living thing is alive or not.
     * @return true if the living thing is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the living thing is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the living thing's location.
     * @return The living thing's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the living thing at the new location in the given field.
     * @param newLocation The living thing's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the living thing's field.
     * @return The living thing's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    
    protected void giveBirth(List<LivingThings> newLivingThing)
    {
        // New are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if (rand.nextDouble() <= this.getBreedingProbability()) //Check the breeding probability
            {
            if(this instanceof Wolf)
            {
            	if(this.findMate(this.getLocation())) //if you find a mate, then breed
            	{
            	Predator young = new Wolf(false, field, loc);
            	newLivingThing.add(young);
            	//System.out.println(young);
            	}
            }
            if(this instanceof Lynx)
            {
            	if(this.findMate(this.getLocation())) //if you find a mate, then breed
            	{
            	Predator young = new Lynx(false, field, loc);
            	newLivingThing.add(young);
            	//System.out.println(young);
            	}
            }

            if(this instanceof Tree)
            {

            	Tree young = new Tree(false, field, loc);
            	newLivingThing.add(young);
            	System.out.println(young);
            	
            }
            if(this instanceof Grass)
            {
            	if(field.getObjectAt(loc) == null)
            	{
            	Grass young = new Grass(false, field, loc);
            	newLivingThing.add(young);
            	//System.out.println(young);
            	}
            }
            if(this instanceof Deer)
            {
            	if(this.findMate(this.getLocation()))
            	{
            	Deer young = new Deer(false, field, loc);
            	newLivingThing.add(young);
            	System.out.println(young);
            	}
            }
            if(this instanceof Elk)
            {
            	if(this.findMate(this.getLocation()))
            	{
            	Elk young = new Elk(false, field, loc);
            	newLivingThing.add(young);
            	System.out.println(young);
            	}
            }
            if(this instanceof Moose)
            {
            	if(this.findMate(this.getLocation()))
            	{
            	Moose young = new Moose(false, field, loc);
            	newLivingThing.add(young);
            	System.out.println(young);
            	}
            }
            if(this instanceof Beaver)
            {
            	if(this.findMate(this.getLocation()))
            	{
            	Beaver young = new Beaver(false, field, loc);
            	newLivingThing.add(young);
            	System.out.println(young);
            	}
            }
            if(this instanceof Rabbit)
            {
            	if(this.findMate(this.getLocation()))
            	{
            	Rabbit young = new Rabbit(false, field, loc);
            	newLivingThing.add(young);
            	//System.out.println(young);
            	}
            }
          }
        }
        
    }
    
    
    private int breed()
    {
    	
        int births = 0;
        if(canBreed() && rand.nextDouble() <= this.getBreedingProbability()) {
            births = rand.nextInt(this.getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    
    private boolean canBreed()
    {
        return this.getAge() >= this.getBreedingAge();
    }
    
    protected void incrementAge()
    {
        setAge(this.getAge()+1);
        if(getAge() > this.getMaxAge()) {
            setDead();
            //System.out.println(this.getClass() + " has died of old age");
        }
    }
    
    public boolean findMate(Location loc)
    {
    	List<Location> adjLocs = field.adjacentLocations(loc);
    	List<Location> doubleAdjLocs = new ArrayList<>();
    	
    	for (Location allAdjLocs: adjLocs)
    	{
    		List<Location> temp = field.adjacentLocations(allAdjLocs);
    		for(Location tempLoc: temp)
    		{doubleAdjLocs.add(tempLoc);}
    	}
    			
    	for(Location allAdjLocs: doubleAdjLocs)
    	{
    		LivingThings mate = (LivingThings) field.getObjectAt(allAdjLocs);
    		if(mate != null)
    		{
    			if(mate.getClass() == this.getClass() && mate.getIsMale() != this.getIsMale())//Check to see if they are the same class and opposite sexes
    			{return true;}
    		}
    	}
    	return false;
    }
    
    public boolean fiftyFifty()
    {
        if(rand.nextInt(100) >= 50)
        {return true;}
        else
        {return false;}
    }
    
    abstract boolean getIsMale();
    
    abstract void setIsMale(boolean male);
    
    abstract void setAge(int ageInput);
	
	abstract int getAge();

    abstract int getBreedingAge();
    
    abstract int getMaxLitterSize();
    
    abstract double getBreedingProbability();
    
    abstract int getMaxAge();
}
