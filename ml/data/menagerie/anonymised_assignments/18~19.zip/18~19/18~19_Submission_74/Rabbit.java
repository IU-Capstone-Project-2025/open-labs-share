import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple Rabbit class
 *
 * @version 2019.02.22
 */
public class Rabbit extends Prey
{
    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rabbit can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.17;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 12;
    //The amount of food a beaver provides when eaten.
    private static final int RABBIT_FOOD_VALUE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The rabbit's age.
    private int age;
    // The rabbit's food level.
    private int foodLevel;
    // boolean vaule of rabbit's gender.
    private boolean isMale;
    
    /**
     * Create a Rabbit. A beaver may be created with age
     * zero (a new born) or with a random age.
     * Start with a specific food level.
     * 
     * @param randomAge If true, the tree will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        foodLevel = 15;
    }
    
    /**
     * This is what the Rabbit does most of the time - it gives birth based on a few 
     * conditions. Sometimes it will breed or die of old age.
     * @param newPrey A list to return newly born Beaver.
     */
    public void act(List<LivingThings> newPrey)
    {
	        incrementAge();
	        incrementHunger();
	        if(isAlive()) 
	        {
	            giveBirth(newPrey);            
	            // Move towards a source of food if found.
	            if(!field.getIsDay())
	            {
	            	Location newLocation = findFood();
	            
	            	if(newLocation == null) 
	            	{ 
	                // No food found - try to move to a free location.
	                newLocation = getField().freeAdjacentLocation(getLocation());
	            	}
	                // See if it was possible to move.
	            	if(newLocation != null) 
	            	{
	                setLocation(newLocation);
	            	}
	            	else 	
	            	{
	                // Overcrowding.
	                setDead();
	            	}
	            }
	        }
    	    }
    	    
    /**
     * This is how a Rabbit searches for food by searching
     * adjacent locations for the correct object type that is 
     * its food, grass.
     * @return The location of the found food, or null if no food is found
     */   
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object livingThing = field.getObjectAt(where);
            if(livingThing instanceof Grass) 
            {
                Grass grass = (Grass) livingThing;
                if(grass.isAlive()) 
                { 
                    grass.setDead();
                    foodLevel += grass.getFoodValue();
                    return where;
                }

            }
        }
        return null;
    }
    
    //@return food level of rabbit
     protected int getFoodLevel()
	 {return foodLevel;}
	 
	 //add food to current beaver's food leve
	 protected void addFood(int foodInput)
	 {foodLevel += foodInput;}
	 
	//@return food value of beaver 
     protected int getFoodValue()
     {return RABBIT_FOOD_VALUE;}
     
      //@return boolean value of beaver's gender
     protected boolean getIsMale()
	 {return isMale;}
	 
	 //set gender of beaver
	 protected void setIsMale(boolean male)
	 {isMale = male;}
	 
	// set beaver's age 
     protected void setAge(int ageInput)
	 {this.age = ageInput;}
	
	 //@return rabbit's age
	 protected int getAge()
	 {return age;}

	 //@return rabbit's breeding age
	 protected int getBreedingAge()
	 {return BREEDING_AGE;}

	 //@return maximum rabbit's maximum number of births
	 protected int getMaxLitterSize()
	 {return MAX_LITTER_SIZE;}
	    
	 //@return rabbit's breeding probability
	 protected double getBreedingProbability()
	 {return BREEDING_PROBABILITY;}
	    
	 //@return rabbit's max age
	 protected int getMaxAge()
	 {return MAX_AGE;}
}