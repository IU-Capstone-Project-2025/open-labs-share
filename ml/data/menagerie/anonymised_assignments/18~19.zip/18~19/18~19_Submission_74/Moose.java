import java.util.List;
import java.util.Random;

/**
 * A simple Moose class
 *
 * @version 2019.02.22
 */
public class Moose extends Carvidae
{
	// Characteristics shared by all mooses (class variables).

    // The age at which a moose can start to breed.
    private static final int BREEDING_AGE = 20;
    // The age to which a moose can live.
    private static final int MAX_AGE = 200;
    // The likelihood of a moose breeding.
    private static final double BREEDING_PROBABILITY = 0.18;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    private static final int MOOSE_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The moose's age.
    private int age;
    private int foodLevel;
    private boolean isMale;
    
    /**
     * Create a moose. A moose may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the tree will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Moose(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
        foodLevel = 45;
    }

     protected int getFoodLevel()
	 {return foodLevel;}
	 
	 protected void addFood(int foodInput)
	 {foodLevel += foodInput;}
	 
     protected int getFoodValue()
     {return MOOSE_FOOD_VALUE;}
     
     protected boolean getIsMale()
	 {return isMale;}
	 
	 protected void setIsMale(boolean male)
	 {isMale = male;}
  
     protected void setAge(int ageInput)
	 {this.age = ageInput;}
	
	 protected int getAge()
	 {return age;}

	 protected int getBreedingAge()
	 {return BREEDING_AGE;}

	 protected int getMaxLitterSize()
	 {return MAX_LITTER_SIZE;}
	    
	 protected double getBreedingProbability()
	 {return BREEDING_PROBABILITY;}
	    
	 protected int getMaxAge()
	 {return MAX_AGE;}
}