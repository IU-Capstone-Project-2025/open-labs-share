/**
 * A simple Tree class
 *
 * @version 2019.02.22
 */


public class Main
{
	
public static void main(String[] args)

{
System.out.println("Console test");
Simulator simTest = new Simulator(240, 360);

simTest.runLongSimulation();

}



















}