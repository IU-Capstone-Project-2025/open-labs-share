import java.util.List;
import java.util.Random;
/**
 * A simple Tree class
 *
 * @version 2019.02.22
 */
public class Tree extends Plant {

    // The age to which a tree can live. 
    private static final int MAX_AGE = 2000;
	// The age at which a tree can start to breed. 
    private static final int BREEDING_AGE = 200;
    // The likelihood of a tree breeding.
    private static final double BREEDING_PROBABILITY = 0.13;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 8;
    //The amount of food a tree provides
    private static final int TREE_FOOD_VALUE = 50;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
   
    // The fox's age.
    private int age;
    private boolean isMale;
	
    /**
     * Create a Tree. A tree may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the tree will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
	public Tree(boolean randomAge, Field field, Location location) 
	{
		super(randomAge, field, location);
	}
	
	 /**
     * This is what the tree does most of the time - it gives birth based on a few 
     * conditions. Sometimes it will breed or die of old age.
     * @param newPlants A list to return newly born trees.
     */
	public void act(List<LivingThings> newPlant)
    {
        incrementAge();
        // Giving birth is affected by if it is alive, whether it is snowing and if it is day/night time.
        if(isAlive()&&(!field.getWeather().equals("Snow")) && field.getIsDay())//Trees will not grow in the snow or at night) 
        {
            giveBirth(newPlant);            
        }

        
    } 


	// @return the food value of tree
    protected int getFoodValue()
    {return TREE_FOOD_VALUE;}
     
    //@return boolean value of tree's gender
    protected boolean getIsMale()
    {return isMale;}
    
    // set gender of tree to male if boolean value is true
    //@param male determine boolean value of male
    protected void setIsMale(boolean male)
    {isMale = male;}
    
    // set age of tree
    //@param ageInput input tree's age
    protected void setAge(int ageInput)
    {this.age = ageInput;}
    
    // return age value of tree
    protected int getAge()
    {return age;}

    // @return breeding age of tree
    protected int getBreedingAge()
    {return BREEDING_AGE;}
    // @return maximum number of births each tree can give
    protected int getMaxLitterSize()
    {return MAX_LITTER_SIZE;}
    
    // @return the breeding probability of tree
    protected double getBreedingProbability()
    {return BREEDING_PROBABILITY;}
    
    // @return maximum age of tree
    protected int getMaxAge()
    {return MAX_AGE;}


}
