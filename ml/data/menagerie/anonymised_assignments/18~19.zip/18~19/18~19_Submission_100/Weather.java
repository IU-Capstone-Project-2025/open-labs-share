/**
 * This class represents the characteristics of the weather in
 * the simulation. Weather is defined by day time, temperature, 
 * and if it is raining. It can influence some of the actions
 * in the simulation
 *
 * @version 2019.02.15
 */
public class Weather {
	// Wether if it is raining
	private boolean isRaining;
	// The current temp in the simulation
	private double temp;
	// Wether it is day or not 
	private boolean isDay;
	
	/**
	 * Set the default values of a weather object
	 * @param isRaining If it is raining or no
	 * @param temp The starting temperature
	 * @param isDay Day time
	 */
	public Weather(boolean isRaining, double temp, boolean isDay) {
		this.isRaining = isRaining;
		this.temp = temp;
		this.isDay = isDay;
		
	}

	/**
	 * 
	 * @return true if it is raining
	 */
	public boolean raining() {
		return isRaining;
	}

	/**
	 * Sets if its raining or if it is clear
	 * @param isRaining true if it is raining
	 */
	public void setIsraining(boolean isRaining) {
		this.isRaining = isRaining;
	}

	/**
	 * 
	 * @return the current temperature in the simulation
	 */
	public double getTemp() {
		return temp;
	}

	/**
	 * 
	 * @param temp the value to be set for current temp
	 */
	public void setTemp(double temp) {
		double setTemp = Math.round(temp * 10) / 10.0;
		this.temp = setTemp;
	}

	/**
	 * Set the current day time.
	 * Change day/night every 14 steps in the simulation.
	 * 
	 * @param step current step in the simulation
	 * @return true if it is day
	 */
	public void isIsDay(int step) {
		boolean isDayTemp = true;
		if((step/14)%2==1) {
			isDayTemp = false;
        }
		isDay = isDayTemp;
	}
	
	/**
	 * 
	 * @return if it is day 
	 */
	public boolean isIsDay() {
		return isDay;
	}
}
