/**
 * A class representing shared characteristics of a virus.
 * A virus spreads under certain conditions over all the animals
 * in the field. Can be transfered during breeding process. 
 *
 * @version 2019.02.19
 */
public class Virus
{
	// Whether the virus is active or not.
	private boolean ISACTIVE;

	//Probability of the virus spreading 
	private double SPEAD_PROBABILITY;

	//Probability of the virus originating 
	private double ORIGIN_PROBABILITY;

	//Virus Danger (decrease lifespan per frame?)  
	private double VIRUS_DANGER;

	//Virus Name 
	private String NAME;

	/**
	 * Create a new virus in the field.
	 * 
	 * @param IACTIVE If the virus is active or no
	 * @param SPEAD_PROBABILITY The probability of a virus spreading
	 * @param VIRUS_DANGER The power of the virus
	 * @param ORIGIN_PROBABILITY The probability of the virus being created
	 * @param NAME The name of the virus
	 */
	public Virus(boolean ISACTIVE, double SPEAD_PROBABILITY, double VIRUS_DANGER, double ORIGIN_PROBABILITY, String NAME)
	{	
		this.ISACTIVE = ISACTIVE;
		this.SPEAD_PROBABILITY = SPEAD_PROBABILITY;
		this.VIRUS_DANGER = VIRUS_DANGER;
		this.ORIGIN_PROBABILITY = ORIGIN_PROBABILITY;
		this.NAME = NAME;

	}

	/**
	 * 
	 * @return The name of the virus
	 */
	public String getNAME() {
		return NAME;
	}

	/**
	 * 
	 * @return if the virus is active
	 */
	public boolean ISACTIVE() {
		return ISACTIVE;
	}


	public void setISACTIVE(boolean isactive) {
		this.ISACTIVE = isactive;
	}

	/**
	 * 
	 * @return the spread probability
	 */
	public double getSPEAD_PROBABILITY() {
		return SPEAD_PROBABILITY;
	}

	/**
	 * Set the probability of the virus spreading
	 * @param sPEAD_PROBABILITY The value to set probability
	 */
	public void setSPEAD_PROBABILITY(double sPEAD_PROBABILITY) {
		SPEAD_PROBABILITY = sPEAD_PROBABILITY;
	}

	/**
	 * 
	 * @return the danger of the virus
	 */
	public double getVIRUS_DANGER() {
		return VIRUS_DANGER;
	}

	/**
	 * 
	 * @param vIRUS_DANGER the value to set for the virus danger
	 */
	public void setVIRUS_DANGER(double vIRUS_DANGER) {
		VIRUS_DANGER = vIRUS_DANGER;
	}

	/**
	 * 
	 * @return the probability of a virus being created
	 */
	public double getORIGIN_PROBABILITY() {
		return ORIGIN_PROBABILITY;
	}

	/**
	 * 
	 * @param vORIGIN_PROBABILITY the value to set for the origin probability
	 */
	public void setORIGIN_PROBABILITY(double vORIGIN_PROBABILITY) {
		ORIGIN_PROBABILITY = vORIGIN_PROBABILITY;
	}



}