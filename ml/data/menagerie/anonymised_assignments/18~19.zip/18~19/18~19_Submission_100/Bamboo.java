import java.util.List;
import java.util.Random;
/**
 * A simple model of a bamboo palnt.
 * Plants age, multiply in adjacent locations, and die when reach max age or get eaten.
 *
 * @version 2019.02.12
 */
public class Bamboo extends Plant{
	// The age to which a bamboo can live.
	private int MAX_AGE = 30;
	// The likelihood of a bamboo growing.
	private static final double GROW_PROBABILITY = 0.05;
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();

	// The bamboo's age.
	private int age;

	// Individual characteristics (instance fields).
	public Bamboo(Field field, Location location, SimulatorView view){
		super(field, location, view);
		age = 0;
	}

	/**
	 * This is what the bamboo does most of the time: it grows.
	 * In the process, it might grow, die of old age or do nothing,
	 * @param newPlants A list to return newly born plants.
	 */
	@Override
	public void act(List<Plant> newPlants) {
		incrementAge();
		if(isAlive()) {
			// Plants don't grow if it is night
			if(this.getview().getweather().isIsDay()){ 
				grownewplant(newPlants);     
			}
		}
	}

	/**
	 * Increase the age.
	 * This could result in the bamboo's death.
	 */
	private void incrementAge()
	{
		age++;
		if(age > MAX_AGE) {
			setDead();
		}
	}
	
	/**
	 * Duplicate plant species in an adjacent field
	 * @param newPlants a list of new plants
	 */
	private void grownewplant(List<Plant> newPlants) {
		Field field = getField();
		List<Location> free = field.getFreeAdjacentLocations(getLocation());
		for(Location loc : free) {
			if(canMultiply()) {
				Random random = new Random();
				if(this.getview().getweather().raining() || random.nextBoolean()) {
					Bamboo young = new Bamboo(field, loc, this.getview());
					newPlants.add(young);
				}
			}
		}

	}

	/**
	 * Check if a bamboo will grow according to its 
	 * probability of growing.
	 * @return true or false if the plant will grow
	 */
	private boolean canMultiply(){
		boolean canMultiply = false;
		if(rand.nextDouble() <= GROW_PROBABILITY) {
			canMultiply = true;
		}
		return canMultiply;

	}
}
