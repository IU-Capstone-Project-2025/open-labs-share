/**
 * A class representing shared characteristics of hebivorous animals.
 *
 * @version 2019.02.19 (3)
 */


public abstract class Herbivore extends Animal
{
    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Herbivore(Field field, Location location)
    {
        super(field, location);
    }

    /**
     * Look for Grass at the current location.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        Location currentLocation =  getLocation();
        Object actor = field.getPlantAt(currentLocation);
        if(actor instanceof Plant) {
            Plant Plant = (Plant) actor;
            if(Plant.isAlive()) {
                Plant.setDead();
                setFoodLevel(0);
                if (Plant instanceof PoisonIvy) {
                    setPoisoned(true);
                }
                return currentLocation;
            }
        }
        return null;
    }
}
