import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a Condor.
 * Condors age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Condor extends Carnivore
{
    // Characteristics shared by all Condors (class variables).

    // The age at which a Condor can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a Condor can live.
    private static final int MAX_AGE = 75;
    // The likelihood of a Condor breeding.
    private static final double BREEDING_PROBABILITY = 0.2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // In effect, this is the number of steps a Condor can go before it has to eat again.
    private final static int MAX_FOOD_VALUE = 13;
    // The Condor's food source.
    private static final Class[] PREYS = {Mouse.class};
    //The food value of a single Condor, also the number of steps that its predator can take before
    //it needs to eat again,
    public static final int FOOD_VALUE = 10;

    // Individual characteristics (instance fields).
    
    // The Condor's age.
    private int age;
    // The Condor's food level, which is increased by eating Mice.
    private int foodLevel;

    /**
     * Create a new Condor. A Condor may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the Condor will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Condor(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(MAX_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = MAX_FOOD_VALUE;
        }
        
    }
    
    /**
     * This is what the Condor does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newCondors A list to return newly born Condors.
     */
    public void act(List<Animal> newCondors, boolean night)
    {
        // This animal is nocturnal. If not night time, a.k.a. day time: does nothing
        if (!night) {
            return;
        }
        super.act(newCondors, night);
    }

    /**
     * Increase the age.
     * This could result in the Condor's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this Condor more hungry. This could result in the Condor's death.
     */
    protected void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this Condor is able to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCondors A list to return newly born Condors.
     */
    protected void giveBirth(List<Animal> newCondors)
    {
        // New Condors are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Condor young = new Condor(false, field, loc);
            newCondors.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A Condor can breed if it has reached the breeding age.
     * @return true if the Condor can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && super.canBreed(this.getClass()));
    }

    /**
     * Returns the food value of a Condor if eaten.
     * @return the food value of Condor.
     */
    public int getFoodValue()
    {
        return FOOD_VALUE;
    }

    /**
     * Set the Condor's foodLevel.
     * Set to max if arg is 0.
     * @param foodLevel value to add.
     */
    public void setFoodLevel(int foodLevel)
    {
        if (foodLevel == 0) {
            this.foodLevel = MAX_FOOD_VALUE;
        }
        else {
            this.foodLevel += foodLevel;
            if (this.foodLevel > MAX_FOOD_VALUE) this.foodLevel = MAX_FOOD_VALUE;
        }
    }
    /**
     * Return a list of the Condor's prey's classes.
     * @return prey classes
     */
    public Class[] getPreys()
    {
        return PREYS;
    }
}
