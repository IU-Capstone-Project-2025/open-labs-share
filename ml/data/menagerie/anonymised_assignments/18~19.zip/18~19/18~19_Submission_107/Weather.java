/**
 * Interface for the weather of the system, used by all types of weather. 
 *
 * @version (2019.02.17)
 */
public interface Weather
{
    /**
     *  generates the behaviour of animals or plants during the day, 
     *  an interface used by every type of weather.
     */
    boolean DayTime(Field field, Location location);
    
    /**
     *  generates the behaviour of animals or plants during the night, 
     *  an interface used by every type of weather.
     */
    boolean NightTime(Field field, Location location);
}
