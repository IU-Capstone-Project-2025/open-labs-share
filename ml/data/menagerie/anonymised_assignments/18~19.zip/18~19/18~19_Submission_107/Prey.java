import java.util.ArrayList; 
import java.util.Random; 
import java.util.List; 
import java.util.Iterator;
/**
 * Abstract class Predator - This class is characteristic for all predatos, it
 * includes functions that apply to all preys. 
 *
 * @version (2019.02.08)
 */
public abstract class Prey extends Animal
{
   /** 
     *  This is the constructor of the abstract class Predator.
     *  @param infectedFromBirth Specify if animal is infected at birth.
     *  @param RandomAge Specify if the age is random or not.
     *  @param field The field currently occupied. 
     *  @param location The location currently occupied. 
     */
    public Prey(boolean infectedFromBirth, boolean RandomAge, Field field, Location location)
    {
        super(infectedFromBirth, RandomAge,field, location); 
    }
    
   /**
     * Look for plants adjacent to the current location.
     * Only the first alive plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object food = field.getObjectAt(where);
            if(food instanceof Plants) {
                Plants plant = (Plants) food;
                plant.SetDead(); 
                SetFoodValue(plant.FoodValue());
                return where;
            }
        }
        return null;
   }
}