import java.util.List;
import java.util.Iterator;
/**
 * The class snake holds characteristics for the type snake of predator.
 *
 * @version (2019.02.08)
 */
public class Snake extends Predator
{
    // Characteristics shared by all snakes (class variables).
    
    // The age at which a snake can start to egg.
    private static final int BREEDING_AGE = 8;
    // The age to which a snake can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a snake egging
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single snake. In effect, this is the
    // number of steps a snake can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    
   /**
     *  This is the constructor of the class Snake, inherited from Prey.
     *  @param infectedFromBirth Specify if animal is infected at birth.
     *  @param RandomAge Specify if the age is random or not.
     *  @param field The field currently occupied. 
     *  @param location The location currently occupied.
     */
    public Snake(boolean infectedFromBirth, boolean RandomAge, Field field, Location location)
    {
        super(infectedFromBirth, RandomAge, field, location);
    } 
   
    /**
     *  @param An animal to be tested 
     *  @return true if the parameter is of class Snake
     */
    public boolean testNeighbor(Animal animal)
    {
        if(animal instanceof Snake) return true;
        return false; 
    }
   /**
     *  @return a new snake. 
     */
    public Snake newBaby(Location location, Field field)
    {
        return new Snake(!GetHealthy(), false, field, location);
    }
    
   /**
    * @returns maximum age of a snake.
    */
   public int MaxAge()
    {
        return MAX_AGE; 
    }
    
   /**
    * @returns the food value of a snake.
    */
   public int FoodValue()
    { return FOOD_VALUE;}
   
    /**
     *  Returns the breeding age of a snake.
     */
   public int BreedingAge()
    { return BREEDING_AGE;}
    
   /**
    * @returns the breeding probability of a snake.
    */
   public double BreedingProbability()
    { return BREEDING_PROBABILITY;}
   
   /**
    * @returns the litter size of a snake.
    */
   public int LitterSize()
   {return MAX_LITTER_SIZE;}
}