import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * The class cat holds characteristics for the type sparrow of prey. 
 *
 * @version 2016.02.29 (2)
 */
public class Sparrow extends Prey
{
    // Characteristics shared by all sparrows (class variables).
    
    // The age at which a sparrow can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a sparrow can live.
    private static final int MAX_AGE = 80;
    // The likelihood of a sparrow breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single sparrow. In effect, this is the
    // number of steps a sparrow can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    
    /**
     *  This is the constructor of the class Sparrow, inherited from Prey. 
     *  @param infectedFromBirth Specify if animal is infected at birth.
     *  @param RandomAge Specify if the age is random or not.
     *  @param field The field currently occupied. 
     *  @param location The location currently occupied.
     */
    public Sparrow(boolean infectedFromBirth, boolean RandomAge, Field field, Location location)
    {
        super(infectedFromBirth, RandomAge, field, location);
    }
    
    /**
     *  @param An animal to be tested 
     *  @return true if the parameter is of class Sparrow
     */
    public boolean testNeighbor(Animal animal)
    {
        if(animal instanceof Sparrow) return true;
        return false; 
    }
    
    /**
     *  @return a new sparrow.
     */
    public Sparrow newBaby(Location location, Field field)
    {
        return new Sparrow(!GetHealthy(), false, field, location);
    }
    
    /**
     * @return maximum living age of a sparrow.
     */
    public int MaxAge()
    {return MAX_AGE;}
    
    /**
     * @return the food value of a sparrow.
     */
    public int FoodValue()
    { return FOOD_VALUE;}
    
    /** 
     * @return the breeding age of a sparrow.
     */
    public int BreedingAge()
    { return BREEDING_AGE;}
    
    /**
     *  @return the breeding probability of a sparrow.
     */
    public double BreedingProbability()
    {return BREEDING_PROBABILITY;}
    
    /**
     * @return the litter size of a sparrow.
     */
    public int LitterSize()
    {return MAX_LITTER_SIZE;}
}
