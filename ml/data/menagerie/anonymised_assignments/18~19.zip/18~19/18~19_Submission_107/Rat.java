import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * The class rat holds characteristics for the type rat of prey
 *
 * @version 2016.02.29 (2)
 */
public class Rat extends Prey
{
    // Characteristics shared by all rats (class variables).
    
    // The age at which a rat can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a rat can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a rat breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 50;
    // The food value of a single rat. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    /**
     *  This is the constructor of the class Rat, inherited from Prey.
     *  @param infectedFromBirth Specify if animal is infected at birth.
     *  @param RandomAge Specify if the age is random or not.
     *  @param field The field currently occupied. 
     *  @param location The location currently occupied.
     */
    public Rat(boolean infectedFromBirth, boolean RandomAge, Field field, Location location)
    {
        super(infectedFromBirth,RandomAge, field, location);
    }
    
    /**
     *  @param An animal to be tested 
     *  @return true if the parameter is of class Rat
     */
    public boolean testNeighbor(Animal animal)
    {
        if(animal instanceof Rat) return true;
        return false; 
    }
    
    /**
     *  @return a new rat.
     */
    public Rat newBaby(Location location, Field field)
    {
        return new Rat(!GetHealthy(), false, field, location);
    }
  
    /**
     * @return maximum living age of a rat.
     */
    public int MaxAge()
    {return MAX_AGE;}
    
    /**
     * @return the food value of a rat.
     */
    public int FoodValue()
    { return FOOD_VALUE;}
    
    /** 
     * @return the breeding age of a rat.
     */
    public int BreedingAge()
    { return BREEDING_AGE;}
    
    /**
     *  @return the breeding probability of a rat.
     */
    public double BreedingProbability()
    {return BREEDING_PROBABILITY;}
    
    /**
     * @return the litter size of a rat.
     */
    public int LitterSize()
    {return MAX_LITTER_SIZE;}
}
