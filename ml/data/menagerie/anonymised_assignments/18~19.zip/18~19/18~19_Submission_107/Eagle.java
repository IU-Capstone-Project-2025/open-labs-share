import java.util.Iterator;
import java.util.List;
/**
 * The class Eagle holds characteristics for the type eagle of predator.
 *
 * @version (2019.02.08)
 */
public class Eagle extends Predator 
{
   // Characteristics shared by all eagles (class variables).
    
    // The age at which an eagle can start to egg.
    private static final int BREEDING_AGE = 10;
    // The age to which an eagle can live.
    private static final int MAX_AGE = 60;
    // The likelihood of a eagle egging
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // The food value of a single eagle. In effect, this is the
    // number of steps an eagle can go before it has to eat again.
    private static final int FOOD_VALUE = 9;
    
   /**
     *  This is the constructor of the class Eagle, inherited from Prey.
     *  @param infectedFromBirth Specify if animal is infected at birth.
     *  @param RandomAge Specify if the age is random or not.
     *  @param field The field currently occupied. 
     *  @param location The location currently occupied.
     */
    public Eagle(boolean infectedFromBirth, boolean RandomAge, Field field, Location location)
    {
        super(infectedFromBirth, RandomAge, field, location);
    }
    
   /**
     *  @param An animal to be tested 
     *  @return true if the parameter is of class Eagle
     */
    public boolean testNeighbor(Animal animal)
    {
        if(animal instanceof Eagle) return true;
        return false; 
    }
    
   /**
     *  @return a new eagle.
     */
    public Eagle newBaby(Location location, Field field)
    {
        return new Eagle(!GetHealthy(), false, field, location);
    }
    
   /**
    * @returns maximum living age of an eagle.
    */
   public int MaxAge()
    {return MAX_AGE;}
   
    /** 
     * @returns the food value of an eagle.
     */
   public int FoodValue()
    { return FOOD_VALUE;}
   
    /**
     * @returns the breeding age of an eagle.
     */
   public int BreedingAge()
    { return BREEDING_AGE;}
   
   /**
    * @returns the breeding probability of an eagle.
    */
   public double BreedingProbability()
   {return BREEDING_PROBABILITY;}
   
   /**
    * @returns the litter size of an eagle. 
    */
   public int LitterSize()
   {return MAX_LITTER_SIZE;}
}
