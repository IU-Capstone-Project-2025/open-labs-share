import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
import java.util.concurrent.TimeUnit;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing pigs and anteateres.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a antEater will be created in any given grid position.
    private static final double ANTEATER_CREATION_PROBABILITY = 0.03;
    // The probability that a pig will be created in any given grid position.
    private static final double PIG_CREATION_PROBABILITY = 0.08;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.03;
    // The probability that a Female ant will be created in any given grid position.
    private static final double ANTF_CREATION_PROBABILITY = 0.02;
    // The probability that a Male ant will be created in any given grid position.
    private static final double ANTM_CREATION_PROBABILITY = 0.02;
    // The probability that a plant will be created in any given grid position. 
    private static final double PLANT_CREATION_PROBABILITY = 0.09;
   
   
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private static int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //The value of the step int but public
    public int valueOfStep;
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Pig.class, Color.ORANGE);
        view.setColor(AntEater.class, Color.BLUE);
        view.setColor(Wolf.class, Color.RED);
        view.setColor(Antm.class, Color.BLACK);
        view.setColor(AntF.class, Color.PINK);
        view.setColor(Plant.class, Color.GREEN);
        
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * antEater and pig.
     */
     public void simulateOneStep()
     {
        try
           {
          Thread.sleep(1000);
         }
        catch(InterruptedException ex)
         {
             Thread.currentThread().interrupt();
             }
         step++;
         List<Animal> newAnimals = new ArrayList<>(); 
        

        // Provide space for newborn animals.
              
        // Let all pigs act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if(! animal.isAlive()) {
                it.remove();
            }
        }
      
        // Add the newly born antEateres and pigs to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }
        
    /**
     * It gets the current step number and checks if it's odd or even
     * We put even steps as a Day in the world and
     * odd as Night
     */
     public static boolean getStep()
      {
      boolean day ; 
       if(step % 2 == 0)
       {
        day = true;
        }
        else
        {
        day = false;
        }
        return day; 
     }
     /**
      * Provides the other classes with the number of the current step
      * without it being public.
      */
       public static int getStepNumber()
     {
        int theStep;
        theStep = step;
        return theStep;
        
        }
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with antEateres and pigs.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= ANTEATER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    AntEater antEater = new AntEater(true, field, location);
                    animals.add(antEater);
                }
                else if(rand.nextDouble() <= PIG_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Pig pig = new Pig(true, field, location);
                    animals.add(pig);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= ANTF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    AntF antf= new AntF(true, field, location);
                    animals.add(antf);
                }
                 else if(rand.nextDouble() <= ANTM_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Antm antm= new Antm(true, field, location);
                    animals.add(antm);
                }
                 else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant= new Plant(true, field, location);
                    animals.add(plant);
                }
                // else leave the location empty.
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
