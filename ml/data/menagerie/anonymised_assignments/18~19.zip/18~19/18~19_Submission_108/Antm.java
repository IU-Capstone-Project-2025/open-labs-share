import java.util.List;
import java.util.Random;

/**
 * A simple model of a antm.
 * Antms age, move, breed with female ants, and die.
 *
 * @version 2016.02.29 (2)
 */
 public class Antm extends Animal
 {
    // Characteristics shared by all antms (class variables).


    // The age to which a antm can live.
    private static final int MAX_AGE = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The antm's age.
    private int age;

    /**
     * Create a new antm. A antm may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the antm will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Antm(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the antm does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newAntms A list to return newly born antms.
     */
    public void act(List<Animal> newAntms)
    {
        incrementAge();
        if(isAlive()) {
                    
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the antm's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    
 }
        
   


