import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 *  A simple model of a lobster.
 * lobster age, move, breed, eat plants, may have disease and die.
 *
 * @version (2019.2.21)
 */
public class Lobster extends Prey
{
    private static final int BREEDING_AGE = 4;
    // The age to which a lobster can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a lobster breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    private static final int MAX_HUNGER_LEVEL = 30;
    private static final double DISEASE_INFECTED_PROBABILITY = 0.01;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    private int age;
    private int hungerLevel;
    private boolean isFemale;
    /**
     * Create a new lobster. A lobster may be created with age
     * zero (a new born) or with a random age.
     * The gender of a lobster is random.
     * 
     * @param randomAge If true, the lobster will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lobster(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            hungerLevel = rand.nextInt(MAX_HUNGER_LEVEL);
        }
        else{
            age = 0;
            hungerLevel = 0;
        }
        if(rand.nextInt(2) == 0){
            isFemale = true;
        }
        else{
            isFemale = false;
        }
    }

    /**
     * This is what the lobster does most of the day time - it runs 
     * around and eat algae. Sometimes it will be infected disease, breed or die of old age.
     * @param newLobster A list to return newly born lobster. 
     */
    public void dayAct(List<Creature> newLobster)
    {
        incrementAge();
        incrementHunger();
        diseaseInfection();
        if(isAlive()) {
            giveBirth(newLobster);    
            findFood();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the lobster does most of the night time - it 
     * runs around and may be infected disease. 
     */
    public void nightAct()
    {
        diseaseInfection();
        if(isAlive()) {
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * Increase the hunger level.
     * This could result in the lobster's death.
     */
    private void incrementHunger()
    {
        hungerLevel++;
        if(hungerLevel > MAX_HUNGER_LEVEL) {
            setDead();
        }
    }
    
    /**
     * Increase the age.
     * This could result in the lobster's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Look for algae that are adjacent to the current location.
     * The cod eat algae to reach 0 hunger level and the height of the algae will dicrease.
     */
    private void findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Algae) {
                Algae algae = (Algae) creature;
                if(algae.getHeight() >= hungerLevel){
                    hungerLevel = 0;
                    algae.setHeight(algae.getHeight() - hungerLevel);
                }
                else{
                    hungerLevel = hungerLevel - algae.getHeight();
                    algae.setHeight(0);
                }
            }
        }
    }
    
    /**
     * Check whether or not this lobster is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newLobster A list to return newly born lobster.
     */
    private void giveBirth(List<Creature> newLobster)
    {
        // New lobsters are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Lobster young = new Lobster(false, field, loc);
            newLobster.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero). 
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A lobster can breed if it is female, have adjacent 
     * male lobster and has reached the breeding age.
     * @return If the lobster can breed. 
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE && isFemale && hasAdjacentMale()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Return the lobster's gender.
     * @return The lobster's gender.
     */
    public boolean getIsFemale()
    {
        return isFemale;
    }
    
    /**
     * Return the lobster's age.
     * @return The lobster's age.
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * Check if the lobster has adjacent male lobster.
     * @return if the lobster has adjacent male lobster.
     */
    private boolean hasAdjacentMale()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Lobster) {
                Lobster lobster = (Lobster) creature;
                if(lobster.isAlive() && !lobster.getIsFemale() && lobster.getAge() >= BREEDING_AGE){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check if the lobster has adjacent disease infected lobster.
     * @return if the lobster has adjacent disease infected lobster.
     */
    private boolean adjacentInfectedLobster()
    {
        Field field = getField();
        if(getLocation() == null)return false;
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Lobster) {
                Lobster lobster = (Lobster) creature;
                if(lobster.isAlive() && lobster.hasDisease()){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * The lobster will be infected if it has adjacent lobster. 
     */
    private void infectedDisease()
    {
        if(adjacentInfectedLobster() && rand.nextDouble() <= DISEASE_INFECTED_PROBABILITY){
            setDisease();
        }
    }
    
    /**
     * Increase the disease level of the infected lobster
     * or set disease to the lobster if it will be infected.
     */
    private void diseaseInfection()
    {
        if(hasDisease()){
            incrementDiseaseLevel();
        }
        else{
            infectedDisease();
        }
    }
}
