import java.util.Random;
import java.util.List;

/**
 * A simple model of a algae.
 * algae can grow at a given rate and will die at a max height.
 *
 * @version (2019.2.21)
 */ 
public class Algae extends Plant
{
    private static final int GROWING_RATE = 3;
    private static final int SLOWER_GROWING_RATE = 2;
    private static final int WEATHER_GROWING_RATE = 1;
    private static final int MAX_HEIGHT = 1200;
    private static final Random rand = Randomizer.getRandom();
    
    private int height;

    /**
     * Create a algae. A algae can be created with a random height.
     * 
     * @param randomHeight If true, the algae will have random height.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Algae(boolean randomHeight, Field field, Location location)
    {
        super(field, location);
        height = 0;
        if(randomHeight){
            height = rand.nextInt(MAX_HEIGHT);
        }
    }

    /**
     * The algae grow up during day time.
     * @param newPlants A list to return newly born plants.
     */
    public void dayAct(List<Creature> newPlants)
    {
        incrementHeight();
    }
    
    /**
     * The algae grow up slower during night time.
     */
    public void nightAct()
    {
        incrementHeightSlower();
    }
    
    /**
     * Increase the height of algae at a weather_growing_rate.
     */
    public void weatherAct()
    {
        height += WEATHER_GROWING_RATE;
        isDead();
    }
    
    /**
     * Increase the height of algae.
     * This could result in the algae's death.
     */
    public void incrementHeight()
    {
        height += GROWING_RATE;
        isDead();
    }
    
    /**
     * Increase the algae height slower.
     * This could result in the algae's death.
     */
    public void incrementHeightSlower()
    {
        height += SLOWER_GROWING_RATE;
        isDead();
    }
    
    /**
     * Set the algae to death if it's height is over max height.
     */
    public void isDead()
    {
        if(height > MAX_HEIGHT){
            setDead();
        }
    }
    
    /**
     * Return the height of algae.
     * @return The height of algae
     */
    public int getHeight()
    {
        return height;
    }
    
    /**
     * Set a new height of algae.
     * @param newHeight The new height of algae.
     */
    public void setHeight(int newHeight)
    {
        height = newHeight;
    }
}
