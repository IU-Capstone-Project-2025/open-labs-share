
/**
 * The disease class shows that wheather the creatures 
 * have disease or not and the disease level of the creatures.
 *
 * @version (2019.2.21)
 */
public class Disease 
{ 
    // the max disease level  
    private static final int MAX_DISEASE_LEVEL = 5;
    
    private boolean hasDisease;
    
    private int diseaseLevel;

    /**
     * Create the disease and it's disease level.
     * @param hasDisease If the disease exist or not
     * @param level The disease level
     */
    public Disease(boolean hasDisease, int level)
    {
        this.hasDisease = hasDisease;
        diseaseLevel = level;
    }

    /**
     * Set up the disease and set the disease level to 1.
     */
    public void setDisease()
    {
        hasDisease = true;
        diseaseLevel = 1;
    }
    
    /**
     *  Return if the disease level is higher than the max disease level.
     */
    public boolean isDead()
    {
        return diseaseLevel > MAX_DISEASE_LEVEL;
    }
    
    /**
     * Increase the disease level.
     */
    public void incrementLevel()
    { 
        diseaseLevel++;
    }
    
    /**
     * Return if the disease is exist.
     */
    public boolean getHasDisease()
    {
        return hasDisease;
    }
    
    /**
     * Return the disease level.
     * @return the disease level
     */
    public int getDiseaseLevel()
    {
        return diseaseLevel;
    }
}
