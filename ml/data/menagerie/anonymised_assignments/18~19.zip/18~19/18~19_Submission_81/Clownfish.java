import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a clownfish.
 * clownfish age, move, breed, may have disease and die.
 *
 * @version 2016.02.29 (2)
 */
public class Clownfish extends Prey
{
    // Characteristics shared by all clownfish (class variables).

    // The age at which a clownfish can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a clownfish can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a clownfish breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    
    private static final double DISEASE_INFECTED_PROBABILITY = 0.01;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The clownfish's age.
    private int age;
    
    private boolean isFemale;

    /**
     * Create a new clownfish. A clownfish may be created with age
     * zero (a new born) or with a random age.
     * The gender of a clownfish is random.
     * 
     * @param randomAge If true, the clownfish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Clownfish(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        if(rand.nextInt(2) == 0){
            isFemale = true;
        }
        else{
            isFemale = false;
        }
    }
    
    /**
     * This is what the clownfish does most of the day time - it runs 
     * around. Sometimes it will be infected disease, breed or die of old age.
     * @param newClownfish A list to return newly born clownfish.
     */
    public void dayAct(List<Creature> newClownfish)
    {
        incrementAge();
        diseaseInfection();
        if(isAlive()) {
            giveBirth(newClownfish);            
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the clownfish does most of the night time - it 
     * runs around and may be infected disease. 
     */
    public void nightAct()
    {
        diseaseInfection();
        if(isAlive()) {
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Increase the age.
     * This could result in the clownfish's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this clownfish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newClownfish A list to return newly born clownfish.
     */
    private void giveBirth(List<Creature> newClownfish)
    {
        // New clownfish are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Clownfish young = new Clownfish(false, field, loc);
            newClownfish.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A clownfish can breed if it is female, have adjacent 
     * male clownfish and has reached the breeding age.
     * @return If the clownfish can breed.
     */
    private boolean canBreed()
    {
        if(age >= BREEDING_AGE && isFemale && hasAdjacentMale()){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Return the clownfish's gender.
     * @return The clownfish's gender.
     */
    public boolean getIsFemale()
    {
        return isFemale;
    }
    
    /**
     * Return the clownfish's age.
     * @return The clownfish's age.
     */ 
    public int getAge()
    {
        return age;
    }
    
    /**
     * Check if the clownfish has adjacent male clownfish.
     * @return if the clownfish has adjacent male clownfish.
     */
    private boolean hasAdjacentMale()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Clownfish) {
                Clownfish clownfish = (Clownfish) creature;
                if(clownfish.isAlive() && !clownfish.getIsFemale() && clownfish.getAge() >= BREEDING_AGE){
                    return true;
                }
            }
        }
        return false;
    }
    
    
    /**
     * Check if the clownfish has adjacent disease infected clownfish.
     * @return if the clownfish has adjacent disease infected clownfish.
     */
    private boolean adjacentInfectedClownfish()
    {
        Field field = getField();
        if(getLocation() == null)return false;
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object creature = field.getObjectAt(where);
            if(creature instanceof Clownfish) {
                Clownfish clownfish = (Clownfish) creature;
                if(clownfish.isAlive() && clownfish.hasDisease()){
                    return true;
                }
            }
        }
        return false;
    }
    
    
    /**
     * The clownfish will be infected if it has adjacent clownfish. 
     */
    private void infectedDisease()
    {
        if(adjacentInfectedClownfish() && rand.nextDouble() <= DISEASE_INFECTED_PROBABILITY){
            setDisease();
        }
    }
    
    /**
     * Increase the disease level of the infected clownfish
     * or set disease to the clownfish if it will be infected.
     */
    private void diseaseInfection()
    {
        if(hasDisease()){
            incrementDiseaseLevel();
        }
        else{
            infectedDisease();
        }
    }
}
