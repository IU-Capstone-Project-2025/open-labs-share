import java.util.Random;
import java.util.List;

//Create weather conditions
enum Weather {CLEAR, TOOSALTY, HIGHTEMP}
public class EnvironmentState
{
    
    //Creating weather.
    private Weather weather;
    
    /**
     * Constructor for objects of class Environment
     */
    public EnvironmentState()
    {
        
        setRandomWeather();
    }
  
    
    /**
     * Chooses a random weather name from the list.
     */
    public void setRandomWeather()
    {
        Weather[] weathers = Weather.values();
        Random randomGenerator = new Random();
        weather = weathers[randomGenerator.nextInt(weathers.length)];
    }
    
    /**
     * Return the weather.
     * @return the weather. 
     */
    public Weather getWeather()
    {
        return weather;
    }
}