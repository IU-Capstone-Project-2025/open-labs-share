
/**
 * This class represents a Human
 *
 * @version Version 1.0 - 07/02/2019
 */
public class Human extends Predator
{
    
    /**
     * Create a new snake at location in field.
     * 
     * @param randomAge Check if we want a random age
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Human(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, AnimalType.HUMAN);
    }
    
}
