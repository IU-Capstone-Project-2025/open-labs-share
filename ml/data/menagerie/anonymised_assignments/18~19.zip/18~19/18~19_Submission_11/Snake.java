import java.util.List;
/**
 * This class represents a Snake
 *
 * @version Version 1.0 - 07/02/2019
 */
public class Snake extends Predator
{
    
    /**
     * Create a new snake at location in field.
     * 
     * @param randomAge Check if we want a random age
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Snake(Boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, AnimalType.SNAKE);
    }
    
    /**
     * Allow the snake to move and eat twice in one go
     */
    public void act(List<Animal> newAnimals, Weather currentWeather)
    {
        // carry out the basic functionality
        super.act(newAnimals, currentWeather);
        // eat and move again
        if (isAlive()) { // check that the location is not null
            findPrey();
        }
    }
    
}
