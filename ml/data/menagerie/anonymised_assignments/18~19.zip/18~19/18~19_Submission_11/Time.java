
/**
 * Keeps track of the time in our simulation.
 *
 * @version Version 1.0 - 21/02/2019
 */
public class Time
{
    // the number of steps (hours) in one day of our simulation
    private final int DAY_LENGTH = 24;
    
    // the current hour
    private int hour = 0;
    
    /**
     * Increase the current hour by one
     */
    public void tick() 
    {
        hour++;
    }
    
    /**
     * Return the current hour
     */
    public int getHour()
    {
        return hour;
    }
    
    /**
     * Reset the time
     */
    public void reset() 
    {
        hour = 0;
    }
    
        /**
     * Gets the current time
     * every day is 5 steps long
     * @return Boolean - true if it is night in the simulation
     */
    public boolean isNight()
    {
        return (hour % DAY_LENGTH) >= (DAY_LENGTH / 2);       
    }
    
    /**
     * @return true if there has just been a new day
     */
    public boolean isNewDay() 
    {
        return hour % DAY_LENGTH == 0;
    }
}
