import java.awt.Color;

/**
 * This class represents a plant in the simulation
 * Animals can eat plants and need to eat them in order to 
 * survive. Only certain animals can eat plants.
 *
 * @version Version 1.0 - 14/02/2019
 */
public class Plant implements SimulatorObject
{
    // A constant having the value that a plant can grow to
    private static final int MAX_GROWTH = 48;
    // The location of the plant
    private Location location;
    // The field
    private Field field;
    // The amount to which the plant has grown
    private int growth; 
    // A boolean variable which holds if the plant is poisonous or not
    private Boolean isPoisonous;
    
    /**
     * @param field The field
     * @param location The location of the plant
     */
    public Plant(Field field, Location location) 
    {
        // start the plant as grown
        growth = MAX_GROWTH;
        this.isPoisonous = setIsPoisonous();
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Makes the plant grow based on the rate
     * @param rate The rate of growth
     */
    public void grow(int rate)
    {
        growth = (growth == MAX_GROWTH) ? MAX_GROWTH : growth + rate;
    }
    
    /**
     * @return The location of the plant in the field
     */
    public Location getLocation() 
    {
        return location; 
    }
    
    /**
     * Sets the growth back to zero 
     */
    public void setEaten() 
    {
        growth = 0;
    }
    
    /**
     * Checks if the plant can be eaten based on growth
     * @return true if it can be eaten, false otherwise 
     */
    public boolean canBeConsumed() 
    {
        return (growth >= 24);    
    }
    
    /**
     * Sets a new location to the plant
     * @param newLocation The new location to be assigned
     */
    public void setLocation(Location newLocation) 
    {
        location = newLocation; 
    }
    
    /**
     * 
     * @return The field in which this plant resides. 
     */
    public Field getField() 
    {
        return field;
    }
    
    /** 
     * Get is poisonous - decides if the generated plant should be poisonous
     * based on a random probability
     */
    private Boolean setIsPoisonous() 
    {
        // generate a random number and then decide if the plant is poisonous
        // there is a 1 in 200 chance that the plant is poisonous
        int random = Simulator.rand.nextInt(300);
        return (random == 100); 
    }
     
    /**
     * Return whether the plant is poisonous
     * @return True if the plant is poisonous
     */
    public Boolean plantIsPoisonous() 
    {
        return isPoisonous;
    }
    
    /**
     * Get the plant grow rate based on a given weather 
     * @return int the given grow rate
     */
    public static int getPlantGrowRate(Weather currentWeather) 
    {
        // change the amount that a plant can grow based on the current
        // weather
        switch (currentWeather) {
            case SUN  : return 1;
            case RAIN : return 2;
            case FOG  : return 0;
            default   : return 1;
        }
    }
    
    /**
     * Get the color of the plant based on if it can be eaten or not
     * @return Light green if the plant can't be eaten - dark green if the plant can
     *         be eaten 
     */
    public Color getPlantColor() {
        // if the plant is posionous then return a purple color
        if (isPoisonous) {
            return new Color(224,189,255);
        }
        if (canBeConsumed()) {
            return new Color(193, 255, 189);
        } else {
            // make the plant color slightly lighter to show that it has been eaten
            return new Color(222, 255, 218);
         }
    }
    
}
