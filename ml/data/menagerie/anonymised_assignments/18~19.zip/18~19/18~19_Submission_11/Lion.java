
/**
 * This class represents a Lion
 *
 * @version Version 1.0 - 07/02/2019
 */
public class Lion extends Predator
{

    public Lion(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location, AnimalType.LION);   
    }
   
    /**
     * This is how we would add extra functionality to the animal on top
     * of the functionality inherited by the predator class.
     * 
    public void act(List<Animal> newAnimals, Weather currentWeather)
    {
        super.act(newAnimals, currentWeather);
        System.out.println("A lion is acting");
    }
    */
}
