import java.util.List;
/**
 * This class represents a Bird
 *
 * @version Version 1.0 - 07/02/2019
 */
public class Bird extends Prey
{
    
    /**
     * Create a new bird at location in field 
     *
     * @version Version 1.0 - 07/02/2019
     */
    public Bird(Boolean randomAge, Field field, Location location) 
    {
        super(randomAge, field, location, AnimalType.BIRD);
    }
    
    /**
     * Give bird the ability to move twice after eating so that it can spread out more
     * This calls all the functionality in the super class (prey) 
     * and then carries out the new functionality
     */
    public void act(List<Animal> newAnimals, Weather currentWeather)
    {
        // carry out the basic behaviour
        super.act(newAnimals, currentWeather);
        // make the bird move two times after eating 
        super.move(false);
    } 
    
}
