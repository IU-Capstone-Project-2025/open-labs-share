import java.util.ArrayList;
import java.awt.Color;

/**
 * This enum represents a type of animal that is avaiable
 * in the simulation. The deafult values for the animal are set 
 * and these help with the generation and modification of each animal
 *
 * @version 2016.02.29 (2)
 */
// AnimalSimulationConfiguration
public enum AnimalType
{
    // Data Format:
   
    // maxLitterSize, breedingAge, maxAge, breedingProbability, preyFoodValue, creationProbability
    // Predators - enter all the default values for how each predator is simulated
    SNAKE(8, 8, 130, 0.64, 9, 0.03), 
    LION(3, 17, 100, 0.42, 15, 0.021),
    HUMAN(5, 20, 150, 0.20, 18, 0.0125),
    
    // maxLitterSize, breedingAge, maxAge, breedingProbability, preyFoodValue = 0. creationProbability
    // Prey - set the preyFoodValue to 0 as these animals don't eat any other animals
    SHEEP(4, 5, 50, 0.6, 0, 0.03),
    BIRD(6, 15, 100, 0.8, 0, 0.05),
    MOOSE(4, 15, 160, 0.5495, 0, 0.02),
    ;   
   
    // ------------------------------------------------
    // Simulation Properites
    
    // the maximum number of babies
    public int maxLitterSize;
    // The age at which a fox can start to breed.
    public int breedingAge;
    // The age to which a fox can live.
    public int maxAge;
    // The likelihood of a fox breeding.
    public double breedingProbability;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    public int preyFoodValue;
    // creation Probability for each of the animals in the simulation
    public double creationProbability;
    
    // ------------------------------------------------
    
    // Constructors
    // this constructor will init all the values with the default types
    // provided - Allowing us to access all of the animal defaults with syntax such as: 
    //            AnimalType.FOX.BREEDING_AGE
    AnimalType(int maxLitter, int breedingAge, int maxAge, double breedingProbability, int preyFoodValue, double creationProbability) 
    {
        this.maxLitterSize = maxLitter;
        this.breedingAge = breedingAge;
        this.maxAge = maxAge;
        this.breedingProbability = breedingProbability;
        this.preyFoodValue = preyFoodValue;
        this.creationProbability = creationProbability;
    }

    // ------------------------------------------------------
    // Accessor methods for all of the simulation properties
    
    public int getMaxLitterSize() 
    {
        return maxLitterSize;
    }
    
    public int getBreedingAge()
    {
        return breedingAge;
    }
    
    public int getMaxAge() 
    {
        return maxAge;
    }
    
    public double getBreedingProbability() 
    {
        return breedingProbability;
    }
    
    public int getPreyFoodValue()
    {
        return preyFoodValue;
    }
    
    public double getCreationProbability() 
    {
        return creationProbability;
    }
    
    // ------------------------------------------------------
    
    // -----------------------------------------------------------------------------
    // !!! Edit this code when adding new animals to the simulation !!!
   
    // this public constant holds all of the types of animal that we are 
    // running in this simulator
    public static final AnimalType animalTypes[] = 
    {
        // PREDATORS
        AnimalType.SNAKE,
        AnimalType.LION,
        AnimalType.HUMAN,
        // PREY
        AnimalType.SHEEP,
        AnimalType.BIRD,
        AnimalType.MOOSE,
    };

    // this method takes the current animal and an animal that the current animal is looking
    // to eat and returns whether this is valid. (if currentAnimal eats animalToEat)
    // @param currentAnimal - the animal that is finding food
    // @param animalToEat - the animal that the current animal is looking to eat
    // @returns boolean - whether currentAnimal can eat animalToEat
    public static Boolean canEat(AnimalType currentAnimal, AnimalType animalToEat) 
    {    
        switch (currentAnimal) {
            // snake can eat sheep
            case SNAKE: return (animalToEat == MOOSE || animalToEat == BIRD);
            // lion can eat either sheep or moose
            case LION:  return (animalToEat == SHEEP || animalToEat == MOOSE);
            // human can eat everything but other humans
            case HUMAN: return (animalToEat == SHEEP || animalToEat == BIRD);
            // the animal is prey so can't eat another animal
            default: return false;
        }
    }
    
    /**  
     * Returns whether an animal of a certain type is nocturnal or not.
     * @param animalType The type of the animal
     * @return true if the animal is nocturnal.
     */
    public static Boolean animalIsNocturnal(AnimalType animalType)
    {
        switch(animalType) {
            case SNAKE: case LION: return true;
            default : return false;
        }
    }

    // create a new animal based on a type given to this method
    // used in the birthing method and in the creation method (seen in the simulator)
    public static Animal createChild(AnimalType type, Boolean randomAge, Field field, Location location) 
    {
        switch (type) {
            // predators
            case HUMAN: return new Human(randomAge, field, location);
            case LION: return new Lion(randomAge, field, location);
            case SNAKE: return new Snake(randomAge, field, location);
            // prey
            case SHEEP: return new Sheep(randomAge, field, location);
            case BIRD: return new Bird(randomAge, field, location);
            case MOOSE: return new Moose(randomAge, field,location);
            // default return shee[ - this should not be called but we are 
            // adding it for safety
            default: return new Sheep(randomAge, field, location);
        }
    }
       
    // update the view color for each of the new animals
    public static void setAnimalViewColoursFor(SimulatorView view) 
    {
        view.setColor(Lion.class, new Color(255,21,0));
        view.setColor(Snake.class, new Color(204,17,0));
        view.setColor(Human.class, new Color(127,10,0));
        view.setColor(Sheep.class, new Color(7, 83, 127));
        view.setColor(Bird.class, new Color(14, 166, 255));
        view.setColor(Moose.class, new Color(11, 133, 204));
    }
    
}
