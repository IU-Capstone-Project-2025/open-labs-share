
/**
 * This class contains all of the attributes of a disease
 * this includes how the disease is spread and how it infects the animal.
 *
 * @version Version 1.0 19/02/2019
 */
public class Disease
{
    
    /**
     * This enumeration determines how the disease can be 
     * transmitted.
     * At the moment there are two types: by air (transmitted when the animals
     * are close together) and by birth (the animal passes passes a disease when it mates
     * and when an animal is born.
     */
    public enum TransmissionType 
    {
        BIRTH,
        AIR
    }
   
    /**
     * This property holds the strength of the disease
     * this value will be used when calculating how long the animal
     * has left to live
     */
    private Integer strength;
   
    /**
     * This property will determine how the disease is
     * transmitted amoungst other animals
     */ 
    private TransmissionType transmissionType;
    
    /**
     * Determines whether the disease can spread between animal speicies
     */
    private boolean isSpeciesDependant;
    
    public Disease(Integer strength, Boolean isSpeciesDependant, TransmissionType transmissionType) 
    {
        this.isSpeciesDependant = isSpeciesDependant;
        this.strength = strength;
        this.transmissionType = transmissionType;
    }
    
    /**
     * This method creates a random disease.
     * This will be used when the animal has a chance of randomly 
     * contracting a new type of disease
     * @return Disease - the new disease, randomly generated
     */
    public static Disease createRandomDisease() 
    {
        // create a disease with a random strength between 90 and 190
        Integer randStrength = Simulator.rand.nextInt(100) + 90;
        // decide if the disease can be spread between species
        // just use the value determined above for this - see if it is odd or even    
        return new Disease(randStrength, randStrength % 2 == 0, randomTransmissionType());
    }
    
    /**
     * Get whether the disease is species dependent
     */
    public Boolean getIsSpeciesDependent() 
    {
        return isSpeciesDependant;
    }
    
    /**
     * Get the strength of the disease
     */
    public Integer getStrength() 
    {
        return this.strength;
    }
    
    /**
     * Get the transmission type of the current disease
     */
    public TransmissionType getTransmissionType()
    {
        return this.transmissionType;
    }
    
    /**
     * Get a random transmission type for the disease
     */
    public static TransmissionType randomTransmissionType() {
        int randomNumber = Simulator.rand.nextInt(2);
        if (randomNumber % 2 == 0) {
            return TransmissionType.BIRTH;
        }
        return TransmissionType.AIR;
    }
    
}
