import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * Abstract class Predator 
 * This class will be responsible for holding the preditor templates
 * Included in this will be the foodsource of the animal and the implementaion 
 * of the act function. 
 *
 * @version 1.0
 */
public abstract class Predator extends Animal
{    
    
    /**
     * Create a new predator at location in field.
     * 
     * @param randomAge Check if we want a random age
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param type The type of the predator
     */
    public Predator(Boolean randomAge, Field field, Location location, AnimalType type)
    {
        super(field, location, type);
        if(randomAge) {
            age = Simulator.rand.nextInt(animalType.getMaxAge());
            foodLevel = Simulator.rand.nextInt(animalType.getPreyFoodValue());
        } else {
            age = 0;
            foodLevel = animalType.getPreyFoodValue();
        }
    }
    
    /**
     * This is what the predator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newPredators A list to return newly born predators.
     */
    public void act(List<Animal> newPredators, Weather currentWeather)
    {
        super.act(newPredators, currentWeather);
        // check that animal is alive
        if(isAlive()) {
            Location newLocation = null;
            // check if the animal can find prey
            if (shouldFindPrey(currentWeather)) {
                newLocation = findPrey();
            }
            // Move towards a source of food if found.
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                setDead();
            }
        }
    }
   
    /**
     * Determine if an animal should find food 
     * If the weather is foggy, then there can be a chance that the current
     * animal might not find food as they are unable to see
     */
    private Boolean shouldFindPrey(Weather currentWeather) 
    {
        // if the weather is foggy then there is a 70% chance that the animal 
        // can find food to eat.
        if (currentWeather == Weather.FOG) {
            int randInt = Simulator.rand.nextInt(100);
            return (randInt >= 70);
        }
        // default to true
        return true;
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findPrey()
    {        
        Field field = getField();
        List<Animal> nearbyAnimals = field.getNearbyAnimals(field, getLocation());
        for (Animal animal : nearbyAnimals) {
            if (animal.isAlive()) {
                // make the predator eat the animal if it can
                if (AnimalType.canEat(this.animalType, animal.animalType)) {
                    // save animal location before setting dead
                    Location preyLocation = animal.getLocation();
                    // eat the prey by setting it as dead 
                    // and incrementing the food value
                    animal.setDead();
                    foodLevel = animalType.getPreyFoodValue();
                    return animal.getLocation();
                }   
            }  
        }
        return null;
    }
     
}
