import java.util.List;

public interface Actor {
	
	/**
	* What an actor should do on each step.
	*/
	public List<? extends Organism> act();
	
}