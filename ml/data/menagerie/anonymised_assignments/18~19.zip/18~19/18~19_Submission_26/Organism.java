import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of organisms.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Organism implements Actor {
	// Whether the organism is alive or not.
    private boolean alive;
    // The organism's field
    protected Field field;
    // The organism's position in the field.
    protected Location location;
	//An organism's age in days
	protected int age;
	
	// Constants that probably won't need to be changed
	// The maximum temperature in Celsius an organism can survive
	protected static double MAX_TEMPERATURE = 30;
	// The minimum temperature in Celsius an organism can survive
	protected static double MIN_TEMPERATURE = -40;
	
    /**
     * Create a new organism at location in field.
     * 
     * @param field    The field currently occupied.
     * @param location The location within the field.
	 * @param randomAge True if spawned with random age.
     */
    public Organism(Field field, Location location, boolean randomAge) {
		age = 0;
		alive = true;
        this.field = field;
        setLocation(location);
		
		if (randomAge) {
			age = getRandomizer().nextInt(getMaxAge()+1);
		}
    }
	
	/**
     * Create a new organism at location in field.
     * 
     * @param field    The field currently occupied.
     * @param location The location within the field.
     */
	public Organism(Field field, Location location) {
		this(field, location, false);
    }
	
	// Abstract methods (mostly getters and setters)
	/**
	* Return a shared random number generator to control breeding.
	* @return a shared random number generator to control breeding.
	*/
	public abstract Random getRandomizer();
	
	/**
	* Return the maximum lifespan of an organism.
	* @return the maximum lifespan of an organism
	*/
	public abstract int getMaxAge();
	
	/**
	* Return viable spawn locations.
	* @return viable spawn locations.
	*/
	protected abstract List<Location> getSpawnLocations();
	
	/**
	* Return the total energy value of this organism
	* @return the total energy value of this organism
	*/
	public abstract double getEnergyValue();
	
	/**
	* Return the total energy expended in reproducing.
	* @return the total energy cost of reproducing
	*/
	public abstract double getReproductionEnergy();
	
	/**
	* Return the age at which this organism can breed.
	* @return the age at which this organism can breed
	*/
	public abstract int getBreedingAge();
	
	/**
	* Return the maximum offspring this organism can produce in one step.
	* @return the maximum offspring this organism can produce in one step
	*/
	public abstract int getMaxOffspringSize();
	
	/**
	* Return a measure of the organism's ability to breed.
	* @return a measure of the organism's ability to breed
	*/
	public abstract double getFertility();
	
	/**
	* Change an organism's current energy by a given amount.
	* @param energy amount by which to change current energy
	*/
	public abstract void changeEnergy(double energy);
	
	/**
	* Return true if this organism will die if it sustains a given energy loss
	* @param energyLoss the number of energy units to check could be lost
	* @return true if organism will die if given energy is lost
	*/
	public boolean willStarve(double energyLoss) {
		return getEnergyValue() - energyLoss <= 0;
	}
	
	/**
	* Return the maximum temperature (degrees Celsius) at which an organism can survive.
	* @return the maximum temperature at which an organism can survive
	*/
	protected double getMaxTemperature() {
		return MAX_TEMPERATURE;
	}
	
	/**
	* Return the minimum temperature (degrees Celsius) at which an organism can survive.
	* @return the minimum temperature at which an organism can survive
	*/
	protected double getMinTemperature() {
		return MIN_TEMPERATURE;
	}
	
	/**
	* Return true if given organism is of the same species.
	* @return true if organism is of the same species
	*/
	protected boolean isSameSpecies(Object org) {
		if (org.getClass().equals(this.getClass())) return true;
		return false;
	}
	
	/**
	* Return true if given organism is of the same species.
	* @return true if organism is of the same species
	*/
	protected boolean isSameSpecies(Class<? extends Object> org) {
		if (org.equals(this.getClass())) return true;
		return false;
	}
	
	/**
	* Return age at which birth occurs (time for egg to hatch or seed to germinate).
	* @return time for egg to hatch or seed to germinate
	*/
	protected abstract int getDormancyPeriod();
	
	/**
	* Return true if an organism is not ready to act. Dormant animals cannot
	* breed, move, or eat, and represent organisms that have not yet spawned. They 
	* may or may not be eaten, and they do occupy space.
	* @return true if an organism is not ready to act
	*/
	protected abstract boolean isDormant();
	
	//TODO
	protected boolean isWithinRadius(int squares) {
		return false;
	}

	//TODO
	protected boolean isSmallDistance() {
		return false;
	}
	
	//TODO
	protected boolean isMediumDistance() {
		return false;
	}
	
	/**
     * Increase the age.
     * This could result in the organism's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

	/**
     * Check whether the organism is alive or not.
     * 
     * @return true if the organism is still alive.
     */
    protected boolean isAlive() {
        return alive;
    }
	
    /**
     * Indicate that the organism is no longer alive. It is removed from the field.
     */
    protected void setDead() {
        alive = false;
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * 
     * @return The organism's location.
     */
    protected Location getLocation() {
        return location;
    }

	/**
	* Return current age.
	* @return current age
	*/
	protected int getAge() {
		return age;
	}

    /**
     * Place the organism at the new location in the given field.
     * 
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation) {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the organism's field.
     * 
     * @return The organism's field.
     */
    protected Field getField() {
		assert isAlive() : "Organism is dead.";
        return field;
    }

	/** Return true if the organism can survive at the given temperature.
	* @return true if the organism can survive at the given temperature
	*/
	protected boolean canSurviveTemperature() {
		if (!isAlive()) return false;
		double temp = getField().getWeather().getTemperature();
		return temp >= getMinTemperature() && temp <= getMaxTemperature(); 
	}
}
