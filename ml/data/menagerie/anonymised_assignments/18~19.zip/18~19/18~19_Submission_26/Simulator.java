import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;
import java.awt.Color;
import java.lang.reflect.*;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing arbitrary flora and fauna.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
	
	//Probabilities of each organism's spawning in populate()
	private static final Map<Class<? extends Organism>, Double> genesisProbabilities = 
		Map.of(Penguin.class, 0.02, Fish.class, 0.08, 
			Seal.class, 0.02, Krill.class, 0.06, Phytoplankton.class, 0.12);

    // List of organisms in the field.
    private List<Organism> organisms;
	// List of Tickable objects
	private List<Tickable> tickables;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The current delay between each step
    private int delayTime;
	// Default delay time. Modify to vary pause between each step.
	private static final int DEFAULT_DELAY = 30;
    // A graphical view of the simulation.
    private SimulatorView view;
	// A shared time benchmark
	private  Clock clockInstance;
	// weather instance
	private Weather weather;
	//synchronized simulation execution unit
	private Sink sink;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        organisms = new ArrayList<>();
		tickables = new ArrayList<>();
        weather = new Weather();
		clockInstance = Clock.newClock();
		field = new Field(depth, width, weather);
		
		// Tickables change state on each tick (at each step)
		tickables.add(clockInstance);
		tickables.add(weather);

		//Create a synchronized execution unit
		sink = new Sink();
		
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, sink);
        // view = new SimulatorView(depth, width);
        view.setColor(Fish.class, Color.ORANGE);
        view.setColor(Penguin.class, Color.BLUE);
		view.setColor(Seal.class, Color.RED);
		view.setColor(Krill.class, Color.YELLOW);
		view.setColor(Phytoplankton.class, Color.GREEN);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(1000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
			sink.step();
        }
	}

	// This nested class enables communication between SimulatorView and Simulator
	class Sink {
		public synchronized void step() {
			// Relinquishes main thread's lock on the sink object.
			// The simulation will not resume until view is unpaused and this object is notified.
			// The main thread will then regain a lock on the sink object and resume simulation by 
			// executing simulateOneStep in a loop as directed by the simulate method.
			while (view.isPaused()) {
				try {
					wait();
				}
				catch (InterruptedException ie) {
				}
			}
			if (view.isReset()) {
				reset();
				view.toggleReset(0);
			}
			delay(view.getDelayTime());
            simulateOneStep();
		}
	}

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * Tickable object.
     */
    public void simulateOneStep()
    {
        step++;
    
        // Tick Tickables.
        for(Iterator<Tickable> it = tickables.iterator(); it.hasNext(); ) {
            Tickable t = it.next();
            t.tick();
        }

		// Provide space for newborn organisms.
		List<Organism> newOrganisms = new ArrayList<>();
		//Act actors
		for (Iterator<Organism> it = organisms.iterator(); it.hasNext();) {
			Organism t = it.next();
            newOrganisms.addAll(t.act());
            if(! t.isAlive()) {
                it.remove();
            }
        }

        // Add organisms that are alive (not been eaten)
		for (Organism org : newOrganisms) {
            if (org.isAlive()) organisms.add(org);
        }

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        view.setDelayTime(DEFAULT_DELAY);
        organisms.clear();
		for (Tickable t : tickables) {
			t.reset();
		}
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with various organisms.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
				//Enumerate all classes in genesisProbabilities, which should eventually be replaced by all organisms
				//in a particular environment, and instantiate with probabilities given by genesisProbabilities value
				for (Class<? extends Organism> organismClass : genesisProbabilities.keySet()) {
					if (rand.nextDouble() <= Simulator.genesisProbabilities.get(organismClass)) {
						try {
							Location location = new Location(row, col);
							Organism organism = organismClass.
									getConstructor(Field.class, Location.class, boolean.class).
									newInstance(field, location, true);
							organisms.add(organism);
							break;
						} catch (NoSuchMethodException | InstantiationException | 
						IllegalAccessException | InvocationTargetException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}

    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
