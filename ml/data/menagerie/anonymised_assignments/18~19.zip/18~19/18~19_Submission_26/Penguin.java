import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a penguin.
 * Penguins age, move, eat, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Penguin extends Animal {
    // Characteristics shared by all penguins (class variables).
	
	// Parameters to change for different simulation outcomes
    // The age at which this animal can start to breed.
    private static final int BREEDING_AGE = 9;
    // The age to which this animal can live.
    private static final int MAX_AGE = 60;
    // The likelihood of breeding.
    private static final double FERTILITY = 0.50;
    // The maximum number of births.
    private static final int MAX_OFFSPRING_SIZE = 3;
	// Sleep needs per 24-hour period
	private static final int SLEEP_NEEDS = 8;
	// How much fat this animal can store
	private static final double MAX_FATNESS = 80;
	// Fullness beyond this point is converted to fatness
	private static final double MAX_FULLNESS = 60;
	// How many food units this animal needs each turn
	private static final double ENERGY_NEEDS = 0.8;
	// The fullness level below or equal to which an animal should eat
	private static final double FULLNESS_POINT = MAX_FULLNESS * 0.80;
	// Energy required to produce one offspring
	private static final double REPRODUCTION_ENERGY = 8;
	// Time for eggs to hatch; greater than 0 only if oviparous
	protected static final int DORMANCY_PERIOD = 2;
	
	// Constant characteristics of animal (should not be changed)
	// A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
	// If not diurnal, nocturnal
	private static final boolean DIURNAL = true;
	// Organisms this animal can eat
	private static final List<Class<? extends Organism>> PREY = List.of(Krill.class, Fish.class);

    /**
     * Create a penguin. A penguin can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the penguin will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Penguin(Field field, Location location, boolean randomAge) {
        super(field, location, randomAge);
    }

	//all set and get methods
	/** {@inheritDoc} */
	public int getBreedingAge() {
		return BREEDING_AGE;
	}
	/** {@inheritDoc} */
	public double getFertility() {
		return FERTILITY;
	}
	/** {@inheritDoc} */
	public double getReproductionEnergy() {
		return REPRODUCTION_ENERGY;
	}
	/** {@inheritDoc} */
	public int getMaxAge() {
		return MAX_AGE;
	}
	/** {@inheritDoc} */
	public int getSleepNeeds() {
		return SLEEP_NEEDS;
	}
	/** {@inheritDoc} */
	public int getMaxOffspringSize() {
		return MAX_OFFSPRING_SIZE;
	}
	/** {@inheritDoc} */
	public double getFullnessPoint() {
		return FULLNESS_POINT;
	}
	/** {@inheritDoc} */
	public double getMaxFatness() {
		return MAX_FATNESS;
	}
	/** {@inheritDoc} */
	public double getMaxFullness() {
		return MAX_FULLNESS;
	}
	/** {@inheritDoc} */
	public double getEnergyNeeds() {
		return ENERGY_NEEDS;
	}
	/** {@inheritDoc} */
	public boolean isDiurnal() {
		return DIURNAL;
	}
	/** {@inheritDoc} */
	protected int getDormancyPeriod() {
		return DORMANCY_PERIOD;
	}
	/** {@inheritDoc} */
	public List<Class<? extends Organism>> getPrey(){
		return PREY;
	}
	/** {@inheritDoc} */
	public Random getRandomizer() {
		return rand;
	}
	
	/**
	* Return an instance of this animal.
	* @return an instance of this animal.
	*/ 
	protected Animal makeAnimal(Field field, Location location, boolean randomAge) {
		return new Penguin(field, location, randomAge);
	}
}

