import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of animals.
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // Whether the animal is male or not.
    private boolean male;
    // The age an animal must reach before it can breed.
    private static int BREEDING_AGE;
    // The maximum age of an animal.
    private static int MAX_AGE;
    // The probability that an animal will breed.
    private static double BREEDING_PROBABILITY;
    // The maximum litter size of an animal (how many offspring it has).
    private static int MAX_LITTER_SIZE;
    // An animal's current age.
    private int age;
    // An animal's current food level.
    private int foodLevel;
    // A random variable.
    public static final Random rand = Randomizer.getRandom();
    // Whether or not an animal is infected.
    private boolean infected;

    /**
     * Create a new animal at location in field.
     * This constructor also assigns an animal's gender.
     * There is a 50% chance of the animal being male/female.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        male = rand.nextBoolean();
    }

    /**
     * A method to get the random variable value.
     * @ return rand
     */
    public Random getRand()
    {
        return rand;
    }

    /**
     * A method that sets the chance of an animal being infected.
     * Currently there is a 10% chance of an animal being infected.
     */
    public void setChanceOfInfection() 
    {
        if(rand.nextInt(10) == 0) {
            infected = true;
        }
    }

    /**
     * A method that returns whether or not an animal is infected.
     * @return true If the animal is infected.
     */
    public boolean isInfected() 
    {
        return infected;
    }

    /**
     * A method that sets an animal to be infected.
     */
    public void setInfected(boolean infection) 
    {
        this.infected = infection;
    }

    /**
     * Set the breeding age of an animal.
     * @param newBreedingAge
     */
    protected void setBreedingAge(int breedingAge)
    {
        BREEDING_AGE = breedingAge;
    }

    /**
     * Return the breeding age of an animal.
     * @return BREEDING_AGE
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * Set the max age of an animal.
     * @param newMaxAge
     */
    protected void setMaxAge(int maxAge)
    {
        MAX_AGE = maxAge;
    }

    /**
     * Return the max age of an animal.
     * @return MAX_AGE
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * Set the breeding probability of an animal
     * @param newBreedingProbability
     */
    protected void setBreedingProbability(double breedingProbability)
    {
        BREEDING_PROBABILITY = breedingProbability;
    }

    /**
     * Return the breeding probability of an animal.
     * @return the BREEDING_PROBABILITY
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * Set the max litter size of an animal
     * @param newMaxLitterSize
     */
    protected void setMaxLitterSize(int maxLitterSize)
    {
        MAX_LITTER_SIZE = maxLitterSize;
    }

    /**
     * Return the max litter size of an animal.
     * @return MAX_LITTER_SIZE
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * Set the age of an animal.
     * @param newAge
     */
    protected void setAge(int age)
    {
        this.age = age;
    }

    /**
     * Return the age of the animal.
     * @return age
     */
    protected int getAge()
    {
        return age;
    }

    /**
     * Set the foodLevel of an animal.
     * @param newFoodLevel
     */
    protected void setFoodLevel(int foodLevel)
    {
        this.foodLevel = foodLevel;
    }

    /**
     * Return the current food level of the animal.
     * @return foodLevel
     */
    protected int getFoodLevel(){
        return foodLevel;
    }

    /**
     * This is what the animal does most of the time: it looks for food. 
     * In the process, it might breed,die of hunger, or die of old age. 
     * If an animal is infected, and it breeds, then each of its offspring,
     * will also be infected. Animals may also die from overcrowding if there 
     * are no adjacent locations for it to move into.
     * 
     * @param field The field currently occupied.
     * @param newAnimals A list to return newly born animals.
     */
    protected void act(List<Animal> newAnimals)
    {
        incrementAge();
        incrementHunger();          
        if(isAlive()) {
            if(!infected) {
                giveBirth(newAnimals);
                // System.out.println("Animal gave birth.");
            }
            else {
                giveBirth(newAnimals);
                for(Iterator<Animal> it = newAnimals.iterator(); it.hasNext();) {
                    Animal animal = it.next();
                    animal.setInfected(true);
                }
                // System.out.println("Animal gave birth to infected animals.");
            }
            // Move towards a source of food if found
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
                // System.out.println("Animal dies from overcrowding.");
            }
        }
    }

    /**
     * An abstract method which allows animals to find the food which they desire.
     * @return Location The location of where the source of food was found.
     */
    abstract protected Location findFood();

    /**
     * An abstract method which allows animals to give birth to new animals.
     * @param newAnimals A list to return newly born animals.
     */
    abstract protected void giveBirth(List<Animal> newAnimals);

    /**
     * An animal can breed if it has reached it's breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed()
    {
        if(age >= BREEDING_AGE){
            List<Location> adjLocations = field.adjacentLocations(location);
            if(adjLocations.size() <= 0){
                return false;
            }
            else{
                for(Location next : adjLocations){
                    if(this.same(field.getObjectAt(next))){
                        Animal animal = (Animal) field.getObjectAt(next);
                        if(animal.isMale() != male){
                            return true;
                        }
                        else{
                            return false;
                        }
                    }
                }
                return false;
            }
        }
        else{
            return false;
        }
    }

    /**
     * A method used to compare if two objects are of the same class. 
     * In this case it is used to identify, whether two animals are of the 
     * same type (i.e. similar class).
     * 
     * @return true if they are of the same class.
     */
    private boolean same(Object obj)
    {
        if(obj == null){
            return false;   
        }
        else{
            return this.getClass() == obj.getClass();
        }
    }

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * A method designed to increase the age of an animal. If the animal is 
     * infected, then its max age will half. If the animal's age is greater 
     * than its max age, it will result in the animal's death.
     */
    protected void incrementAge()
    {
        age++;
        if(!infected) {
            if(age > MAX_AGE) {
                setDead();
            }
        }
        else {
            if(age > MAX_AGE/2) {
                setDead();
            }
        }
    }

    /**
     * This method increments an animal's hunger. If the animal is infected, 
     * it loses 2 food values instead of one.If an animal's food value drops 
     * below 0, then the animal dies. 
     */
    protected void incrementHunger()
    {
        if(!infected) { 
            foodLevel--;
            // System.out.println("Foodlevel decreased normally");
        }
        else {
            foodLevel -= 2;
            // System.out.println("Foodlevel did not decrease normally");
        }
        if(foodLevel < 0) {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * A method that returns whether or not an animal is male.
     * @return male
     */
    protected boolean isMale()
    {
        return male;
    }
}
