import java.util.List;
/**
 * A simple model of a vex (squirrel in the original simulation).
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class Vex extends Prey
{
    /**
     * Create a new vex. A vex may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the vex will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Vex(boolean randomAge, Field field, Location location) 
    {
        super(field, location);
        setBreedingAge(40);
        setMaxAge(150);
        setBreedingProbability(1);
        setMaxLitterSize(1);
        setAge(0);
        if(randomAge) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getPlantFoodValue() + 1));
        }
        else {
            setFoodLevel(getPlantFoodValue() + 1);
        }
    }

    /**
     * Check whether or not this vex is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newVexes A list to return newly born vexes.
     */
    protected void giveBirth(List<Animal> newVexes)
    {
        // New vexes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Vex young = new Vex(false, field, loc);
            newVexes.add(young);
        }
    }
}
