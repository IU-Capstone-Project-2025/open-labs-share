import java.util.List;
import java.util.Iterator;
/**
 * This class describes the shared characteristics of predator-type animals. 
 * These are animals which,are carnivores, and thus hunt/eat prey. This class is 
 * an extension of the Animal class,which describes the shared characteristics of 
 * all animals.
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public abstract class Predator extends Animal
{
    // The food value that a predator gets from eating a fallen.
    private static final int FALLEN_FOOD_VALUE = 8;
    // The food value that a predator gets from eating a cabal.
    private static final int CABAL_FOOD_VALUE = 13 ;
    // The food value that a predator gets from eating a vex.
    private static final int VEX_FOOD_VALUE = 15;

    /**
     * Constructor for objects of class Predator. This constructor makes a call to 
     * the superclass Animal.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Predator(Field field, Location location){
        super(field, location);
    }

    /**
     * A method that returns the fallen food value.
     * @return FALLEN_FOOD_VALUE
     */
    protected static int getFallenFoodValue() {
        return FALLEN_FOOD_VALUE;
    }

    /**
     * A method that returns the cabal food value.
     * @return CABAL_FOOD_VALUE
     */
    protected static int getCabalFoodValue() {
        return CABAL_FOOD_VALUE;
    }

    /**
     * A method that returns the vex food value.
     * @return VEX_FOOD_VALUE
     */
    protected static int getVexFoodValue() {
        return VEX_FOOD_VALUE;
    }
    
    /**
     * Look for prey adjacent to the current location.
     * Only the first live prey is eaten. If a predator eats another animal, 
     * which was infected, then the predator will become infected as well.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fallen) {
                Fallen fallen = (Fallen) animal;
                if(fallen.isAlive()) { 
                    fallen.setDead();
                    setFoodLevel(FALLEN_FOOD_VALUE);
                    if(fallen.isInfected()) {
                        setInfected(true);
                    }
                    return where;
                }
            }
            if(animal instanceof Cabal){
                Cabal cabal = (Cabal) animal;
                if(cabal.isAlive()){
                    cabal.setDead();
                    setFoodLevel(CABAL_FOOD_VALUE);
                    if(cabal.isInfected()) {
                        setInfected(true);
                    }
                    return where;
                }
            }
            if(animal instanceof Vex){
                Vex vex = (Vex) animal;
                if (vex.isAlive()) {
                    vex.setDead();
                    setFoodLevel(VEX_FOOD_VALUE);
                    if(vex.isInfected()) {
                        setInfected(true);
                    }
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * An abstract method which allows predator-animals to give birth to new animals.
     * @param newPredators A list to return newly born predators.
     */
    protected abstract void giveBirth(List<Animal> newPredators);
}