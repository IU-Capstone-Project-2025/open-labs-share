import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JColorChooser;
/**
 * A graphical view of the simulation grid. The view displays a colored
 * rectangle for each location representing its contents. It uses a default
 * background color. Colors for each type of species can be defined using the
 * setColor method. The color for infected animals is also implemented below.
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class SimulatorView extends JFrame {
    // Whether or not fog is enabled.
    private boolean fog = false;
    // Whether or not rain is enabled.
    private boolean rain = false;
    // Color used for where there are no objects
    private static final Color EMPTY_COLOR = Color.white;
    // Color used for objects that have no defined color.
    private static final Color UNKNOWN_COLOR = Color.gray;
    private final String STEP_PREFIX = "Step: ";
    private final String POPULATION_PREFIX = "Population: ";
    private JLabel stepLabel, population, infoLabel;
    private FieldView fieldView;
    // A statistics object computing and storing simulation information
    private FieldStats stats;
    // A map for storing colors for participants in the simulation
    private Map<Class, Color> colors = new LinkedHashMap<>();
    // Whether or not the user pressed the start button
    private boolean startPressed = false;
    // Whether or not the user pressed the reset button
    private boolean resetPressed = false;
    // Whether or not the user pressed the simulate one step button
    private boolean oneStepPressed = false;
    // Whether or not the user has selected rain to be included in the simulation
    private boolean selectedRain;
    // Whether or not the user has selected disease to be included in the simulation
    private boolean selectedDisease;
    // Whether or not the user has selected fog to be simulated.
    private boolean selectedFog;
    // a field identifying when the simulation is at a night or day state
    private boolean night = false;
    // Labels for colors of specific animals
    private JLabel takenColorLabel = new JLabel();
    private JLabel fallenColorLabel = new JLabel();
    private JLabel cabalColorLabel = new JLabel();
    private JLabel scornColorLabel = new JLabel();
    private JLabel vexColorLabel = new JLabel();
    private JLabel plantColorLabel = new JLabel();
    private JLabel infectedColorLabel = new JLabel();
    // Symbols to easily represent the actual color of each animal in the form of an
    // icon
    private JPanel takenColorSymbol;
    private JPanel fallenColorSymbol;
    private JPanel cabalColorSymbol;
    private JPanel scornColorSymbol;
    private JPanel vexColorSymbol;
    private JPanel plantColorSymbol;
    private JPanel infectedColorSymbol;
    // Check boxes to select depending on which components does the user desire to
    // be included in the simulation
    private JCheckBox rainCheckBox;
    private JCheckBox diseaseCheckBox;
    private JCheckBox fogCheckBox;
    // A color field in case the user wants to change how the infected animals look
    // (default: black)
    private Color infectedColorChange = Color.BLACK;

    /**
     * Create a view of the given width and height.
     * 
     * @param height The simulation's height.
     * @param width  The simulation's width.
     */
    public SimulatorView(int height, int width) 
    {
        stats = new FieldStats();

        setTitle("Simulation");
        stepLabel = new JLabel(STEP_PREFIX, JLabel.CENTER);
        infoLabel = new JLabel("  ", JLabel.CENTER);
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);

        setLocation(100, 50);

        // terminate the program if the user closes the window
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        fieldView = new FieldView(height, width);

        Container contents = getContentPane();

        // an information panel on the top of the screen for the step, day/night state,
        // fog state, and disease state
        JToolBar infoPane = new JToolBar();
        infoPane.setFloatable(false);
        infoPane.add(stepLabel, BorderLayout.WEST);
        infoPane.add(infoLabel, BorderLayout.CENTER);

        JToolBar controlBar = new JToolBar(); // create a control bar for the buttons
        controlBar.setLayout(new BoxLayout(controlBar, BoxLayout.Y_AXIS)); // create a vertical box structure in the tool bar

        // adds start, one step simulation, time, fog, and the change color buttons for
        // each animal
        JButton start = new JButton("Simulate 4000 steps");
        start.setAlignmentX(CENTER_ALIGNMENT);

        JButton oneStep = new JButton("Simulate one step");
        oneStep.setAlignmentX(CENTER_ALIGNMENT);

        JButton time = new JButton("Day/Night");
        time.setAlignmentX(CENTER_ALIGNMENT);

        JButton reset = new JButton("reset");
        reset.setAlignmentX(CENTER_ALIGNMENT);

        JButton exit = new JButton("exit");
        exit.setAlignmentX(CENTER_ALIGNMENT);

        // make the start, simulate one step, reset, and exit buttons do a
        // specific task upon activation
        start.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    startPressed = true;
                }
            });

        oneStep.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    oneStepPressed = true;
                }
            });

        reset.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    resetPressed = true;
                }
            });

        exit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    System.exit(0);
                }
            });

        JButton takenColor = new JButton("Change Color");// a button in case the user wants to change the color of taken

        // prompt the user to choose a replacement color for taken and change it to what
        // ever the user desires, and update the color icon
        takenColor.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    Color takenColorChange = JColorChooser.showDialog(null, "Choose a color", Color.RED);
                    if (takenColorChange != null) {
                        colors.put(Taken.class, takenColorChange);
                        updateColorSymbols();
                    }

                }
            });
        // drawn an icon representing the color of taken
        takenColorSymbol = new JPanel() {
            @Override
            public void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.setColor(colors.get(Taken.class));
                g.fillRect(0, 0, 10, 10);
            }
        };

        // insert the color label, symbol, and the taken switch color button in a panel
        // fitted in the vertical box structure on the right of the screen
        JPanel takencolorPanel = new JPanel();
        takencolorPanel.setLayout(new FlowLayout());
        takencolorPanel.add(takenColorLabel);
        takencolorPanel.add(takenColorSymbol);
        takencolorPanel.add(takenColor);

        JButton fallenColor = new JButton("Change color");// a button in case the user wants to change the color of
        // fallen

        // prompt the user to choose a replacement color for fallen and change it to
        // what ever the user desires, and update the color icon
        fallenColor.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    Color fallenColorChange = JColorChooser.showDialog(null, "Choose a color", Color.RED);
                    if (fallenColorChange != null) {
                        colors.put(Fallen.class, fallenColorChange);

                    }
                }
            }

        );

        // draw an icon representing the color of fallen
        fallenColorSymbol = new JPanel() {
            @Override
            public void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.setColor(colors.get(Fallen.class));
                g.fillRect(0, 0, 10, 10);
            }
        };

        // insert the color label, symbol, and the fallen switch color button in a panel
        // fitted in the vertical box structure on the right of the screen

        JPanel fallenColorPanel = new JPanel();
        fallenColorPanel.setLayout(new FlowLayout());
        fallenColorPanel.add(fallenColorLabel);
        fallenColorPanel.add(fallenColorSymbol);
        fallenColorPanel.add(fallenColor);

        JButton cabalColor = new JButton("Change color");// a button in case the user wants to change the color of Cabal

        // prompt the user to choose a replacement color for cabal and change it to what
        // ever the user desires, and update the color icon
        cabalColor.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    Color cabalColorChange = JColorChooser.showDialog(null, "Choose a color", Color.RED);
                    if (cabalColorChange != null) {
                        colors.put(Cabal.class, cabalColorChange);
                        updateColorSymbols();
                    }

                }
            }

        );

        // draw an icon representing the color of Cabal
        cabalColorSymbol = new JPanel() {
            @Override
            public void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.setColor(colors.get(Cabal.class));
                g.fillRect(0, 0, 10, 10);
            }
        };

        // insert the color label, symbol, and the Cabal switch color button in a panel
        // fitted in the vertical box structure on the right of the screen

        JPanel cabalColorPanel = new JPanel();
        cabalColorPanel.setLayout(new FlowLayout());
        cabalColorPanel.add(cabalColorLabel);
        cabalColorPanel.add(cabalColorSymbol);
        cabalColorPanel.add(cabalColor);

        JButton scornColor = new JButton("Change color");// a button in case the user wants to change the color of Scorn

        // prompt the user to choose a replacement color for scorn and change it to what
        // ever the user desires, and update the color icon
        scornColor.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    Color scornColorChange = JColorChooser.showDialog(null, "Choose a color", Color.RED);
                    if (scornColorChange != null) {
                        colors.put(Scorn.class, scornColorChange);
                        updateColorSymbols();
                    }
                }
            }

        );

        // draw an icon representing the color of Scorn
        scornColorSymbol = new JPanel() {
            @Override
            public void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.setColor(colors.get(Scorn.class));
                g.fillRect(0, 0, 10, 10);
            }
        };

        // insert the color label, symbol, and the Scorn switch color button in a panel
        // fitted in the vertical box structure on the right of the screen

        JPanel scornColorPanel = new JPanel();
        scornColorPanel.setLayout(new FlowLayout());
        scornColorPanel.add(scornColorLabel);
        scornColorPanel.add(scornColorSymbol);
        scornColorPanel.add(scornColor);

        // a button in case the user wants to change the color of Vex
        JButton vexColor = new JButton("Change color");

        // prompt the user to choose a replacement color for vex and change it to what
        // ever the user desires, and update the color icon
        vexColor.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    Color vexColorChange = JColorChooser.showDialog(null, "Choose a color", Color.RED);
                    if (vexColorChange != null) {
                        colors.put(Vex.class, vexColorChange);
                        updateColorSymbols();
                    }
                }
            }

        );

        // draw an icon representing the color of Scorn
        vexColorSymbol = new JPanel() {
            @Override
            public void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.setColor(colors.get(Vex.class));
                g.fillRect(0, 0, 10, 10);
            }
        };

        // insert the color label, symbol, and the Scorn switch color button in a panel
        // fitted in the vertical box structure on the right of the screen

        JPanel vexColorPanel = new JPanel();
        vexColorPanel.setLayout(new FlowLayout());
        vexColorPanel.add(vexColorLabel);
        vexColorPanel.add(vexColorSymbol);
        vexColorPanel.add(vexColor);

        // a button in case the user wants to change the color of Vex

        JButton plantColor = new JButton("Change color");

        // prompt the user to choose a replacement color for plants and change it to
        // what ever the user desires, and update the color icon
        plantColor.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    Color plantColorChange = JColorChooser.showDialog(null, "Choose a color", Color.RED);
                    if (plantColorChange != null) {
                        colors.put(Plant.class, plantColorChange);
                        updateColorSymbols();
                    }

                }
            });

        // draw an icon representing the color of Plants
        plantColorSymbol = new JPanel() {
            @Override
            public void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.setColor(colors.get(Plant.class));
                g.fillRect(0, 0, 10, 10);
            }
        };

        // insert the color label, symbol, and the plants switch color button in a panel
        // fitted in the vertical box structure on the right of the screen
        JPanel plantColorPanel = new JPanel();
        plantColorPanel.setLayout(new FlowLayout());
        plantColorPanel.add(plantColorLabel);
        plantColorPanel.add(plantColorSymbol);
        plantColorPanel.add(plantColor);

        // a button in case the user wants to change the color of Vex

        JButton infectedColor = new JButton("Change color");

        // prompt the user to choose a replacement color for infected animals and change
        // it to what ever the user desires, and update the color icon
        infectedColor.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    infectedColorChange = JColorChooser.showDialog(null, "Choose a color", Color.RED);
                    if (infectedColorChange != null) {
                        updateColorSymbols();
                    }
                }
            });

        // draw an icon representing the color of infected animals

        infectedColorSymbol = new JPanel() {
            @Override
            public void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.setColor(infectedColorChange);
                g.fillRect(0, 0, 10, 10);
            }
        };

        // insert the color label, symbol, and the infected animals switch color button
        // in a panel fitted in the vertical box structure on the right of the screen
        JPanel infectedColorPanel = new JPanel();
        infectedColorPanel.setLayout(new FlowLayout());
        infectedColorPanel.add(infectedColorLabel);
        infectedColorPanel.add(infectedColorSymbol);
        infectedColorPanel.add(infectedColor);

        // add the buttons to the control bar with specific spacing
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(start);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(oneStep);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(reset);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(exit);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(takencolorPanel);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(fallenColorPanel);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(cabalColorPanel);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(scornColorPanel);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(vexColorPanel);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(plantColorPanel);
        controlBar.add(Box.createRigidArea(new Dimension(0, 20)));
        controlBar.add(infectedColorPanel);
        controlBar.setFloatable(false);// not draggable

        JToolBar infoBar = new JToolBar();// create an information bar
        infoBar.setFloatable(false);// not draggable
        infoBar.setLayout(new GridBagLayout());// adds a grid structure

        GridBagConstraints c = new GridBagConstraints();
        // adds check boxes and population information to the grid structure with
        // specified constraints
        diseaseCheckBox = new JCheckBox("Disease");

        // makes the check boxes report whether they are selected or not
        diseaseCheckBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    AbstractButton abstractButton = (AbstractButton) e.getSource();
                    selectedDisease = abstractButton.getModel().isSelected();

                }
            });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = (double) 1 / 3;
        c.weighty = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        infoBar.add(diseaseCheckBox, c);

        rainCheckBox = new JCheckBox("Rain");

        rainCheckBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    AbstractButton abstractButton = (AbstractButton) e.getSource();
                    selectedRain = abstractButton.getModel().isSelected();

                }
            });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = (double) 1 / 3;
        c.weighty = 0.5;
        c.gridx = 2;
        c.gridy = 0;
        infoBar.add(rainCheckBox, c);

        fogCheckBox = new JCheckBox("Fog");

        fogCheckBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) 
                {
                    AbstractButton abstractButton = (AbstractButton) e.getSource();
                    selectedFog = abstractButton.getModel().isSelected();
                }
            });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = (double) 1 / 3;
        c.weighty = 0.5;
        c.gridx = 3;
        c.gridy = 0;
        infoBar.add(fogCheckBox, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 30;
        c.weightx = 0.0;
        c.weighty = 0.5;
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 1;
        infoBar.add(population, c);

        contents.add(infoPane, BorderLayout.NORTH); // adds the step information on the top of the screen
        contents.add(fieldView, BorderLayout.CENTER); // simulation in the center
        contents.add(infoBar, BorderLayout.SOUTH); // adds the information bar to the bottom of the screen
        contents.add(controlBar, BorderLayout.EAST); // adds the control bar to the right of the screen

        pack();
        setVisible(true);

    }

    // Set the color labels to the appropriate string to properly inform the user of
    // the animal and its color

    /**
     * Set the color labels to the appropriate string to properly inform the user of
     * the animal and its color
     */
    public void setColorLabels() 
    {
        takenColorLabel.setText("Taken Color: ");
        fallenColorLabel.setText("Fallen Color: ");
        cabalColorLabel.setText("Cabal color: ");
        scornColorLabel.setText("Scorn Color: ");
        vexColorLabel.setText("Vex color: ");
        plantColorLabel.setText("Plant color: ");
        infectedColorLabel.setText("Infected Color: ");
    }

    /**
     * if the user changes a color, update all the color icons to properly inform
     * the user of the change
     */
    public void updateColorSymbols() 
    {
        takenColorSymbol.repaint(0, 0, 10, 10);
        fallenColorSymbol.repaint(0, 0, 10, 10);
        cabalColorSymbol.repaint(0, 0, 10, 10);
        scornColorSymbol.repaint(0, 0, 10, 10);
        vexColorSymbol.repaint(0, 0, 10, 10);
        plantColorSymbol.repaint(0, 0, 10, 10);
        infectedColorSymbol.repaint(0, 0, 10, 10);
    }

    /**
     *  has the start button been pressed
     *  @return startPressed returns true if the start button has been pressed
     */
    public boolean isStartPressed() 
    {
        return startPressed;
    }

    /**
     * has the simulate one step button been pressed
     * @return oneStepPressed returns true if the simulate one step button has been pressed
     */
    public boolean isOneStepPressed() 
    {
        return oneStepPressed;
    }

    /**
     * has the reset button been pressed
     * @return resetPressed returns true if the reset button has been pressed
     */
    public boolean isResetPressed() 
    {
        return resetPressed;
    }

    /**
     * whether the fog check box is selected
     * @return selectedFog returns true if the fog check box is selected
     */
    public boolean isSelectedFog() 
    {
        return selectedFog;
    }

    /**
     *  whether the rain check box is selected
     *  @return selectedRain returns true if the rain check box is selected
     */
    public boolean isSelectedRain() 
    {
        return selectedRain;
    }

    /**
     * whether the disease check box is selected
     * @return selectedDisease returns true if the disease check box is selected
     */
    public boolean isSelectedDisease() 
    {
        return selectedDisease;
    }

    /**
     * change the notion that the start button has been pressed or not
     * @param startPressed whether we want the start (simulate 4000 steps) button to count as being pressed or not
     */
    public void setStartPressed(boolean startPressed) 
    {
        this.startPressed = startPressed;
    }

    /**
     * change the notion that the simulate one step button has been pressed or not
     * @param oneStepPressed whether we want the simulate one step button to count as being pressed or not
     */
    public void setOneStepPressed(boolean oneStepPressed) 
    {
        this.oneStepPressed = oneStepPressed;
    }

    /**
     * change the notion that the reset button has been pressed or not
     */
    public void setResetPressed(boolean resetPressed) 
    {
        this.resetPressed = resetPressed;
    }

    /**
     * @return a string whether its day or night time
     */
    private String getTimeOfDay() 
    {
        if (!isNight()) {
            return "Day";
        } else {
            return "Night";
        }
    }

    /**
     * switches the simulation to its opposite day/night state
     */
    public void switchTimeofDay() 
    {
        night = !night;
    }

    /**
     * switches the simulation to its default day time state
     */
    public void resetTimeOfDay() 
    {
        night = false;
    }

    /**
     * whether the simulation is in the night state or not
     */
    public boolean isNight() 
    {
        return night;
    }

    /**
     * switch the fog state to its opposite
     */
    public void switchFog() 
    {
        fog = !fog;
    }

    /**
     * switch the simulation to a specific fog state of desire
     */
    public void setFog(boolean fogActivity) 
    {
        fog = fogActivity;
    }

    /**
     * whether the simulation is in the fog state or not
     */
    public boolean isFog() 
    {
        return fog;
    }

    /**
     * switch the simulation to a specific day/night state of desire
     */
    public void switchTime() 
    {
        night = !night;
    }

    /**
     * switch the simulation to a specific rain state of desire
     */
    public void switchRain() 
    {
        rain = !rain;
    }

    /**
     * whether the simulation is in the rain state
     */
    public boolean isRain() 
    {
        return rain;
    }

    /**
     * switch the simulation to a specific rain state of desire
     */
    public void setRain(boolean rainActivity) 
    {
        rain = rainActivity;
    }

    /**
     * untick the rain check box and let the program know the user has not selected rain
     */ 
    public void resetRain() 
    {
        selectedRain = false;
        rainCheckBox.setSelected(false);
    }

    /**
     * untick the fog check box and let the program know the user has not selected fog
     */
    public void resetFog() 
    {
        selectedFog = false;
        fogCheckBox.setSelected(false);
    }

    /**
     * untick the disease check box and let the program know the user has not selected disease
     */
    public void resetDisease()
    {
        selectedDisease = false;
        diseaseCheckBox.setSelected(false);
    }

    /**
     * Define a color to be used for a given class of animal.
     * 
     * @param animalClass The animal's Class object.
     * @param color       The color to be used for the given class.
     */
    public void setColor(Class animalClass, Color color) 
    {
        colors.put(animalClass, color);
    }

    /**
     * Display a short information label at the top of the window.
     */
    public void setInfoText(String text) 
    {
        infoLabel.setText(text);
    }

    /**
     * @return The color to be used for a given class of animal.
     */
    private Color getColor(Class animalClass) 
    {
        Color col = colors.get(animalClass);
        if (col == null) {
            // no color defined for this class
            return UNKNOWN_COLOR;
        } else {
            return col;
        }
    }

    /**
     * Show the current status of the field.
     * 
     * @param step  Which iteration step it is.
     * @param field The field whose status is to be displayed.
     */
    public void showStatus(int step, Field field) 
    {
        if (!isVisible()) {
            setVisible(true);
        }
        stepLabel.setText(
            STEP_PREFIX + step + " Time of Day: " + getTimeOfDay() + " Fog: " + isFog() + " Rain: " + isRain());

        stats.reset();

        fieldView.preparePaint();

        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                Object obj = field.getObjectAt(row, col);
                if (obj != null) {
                    stats.incrementCount(obj.getClass());
                    if (obj instanceof Animal) {
                        Animal animal = (Animal) obj;
                        if ((animal.isInfected())) {// if an infected animal is encountered, draw it with the user
                            // specific infected animal color
                            fieldView.drawMark(col, row, infectedColorChange);
                        } else {
                            fieldView.drawMark(col, row, getColor(obj.getClass()));
                        }
                    } else {
                        fieldView.drawMark(col, row, getColor(obj.getClass()));
                    }
                } else {
                    fieldView.drawMark(col, row, EMPTY_COLOR);
                }
            }
        }

        stats.generateInfectedCount(field);
        stats.countFinished();

        population.setText(POPULATION_PREFIX + stats.getPopulationDetails(field));
        fieldView.repaint();
    }

    /**
     * Determine whether the simulation should continue to run.
     * 
     * @return true If there is more than one species alive.
     */
    public boolean isViable(Field field) 
    {
        return stats.isViable(field);
    }

    /**
     * Provide a graphical view of a rectangular field. This is a nested class (a
     * class defined inside a class) which defines a custom component for the user
     * interface. This component displays the field. This is rather advanced GUI
     * stuff - you can ignore this for your project if you like.
     */
    private class FieldView extends JPanel 
    {
        private final int GRID_VIEW_SCALING_FACTOR = 6;

        private int gridWidth, gridHeight;
        private int xScale, yScale;
        Dimension size;
        private Graphics g;
        private Image fieldImage;

        /**
         * Create a new FieldView component.
         */
        public FieldView(int height, int width) 
        {
            gridHeight = height;
            gridWidth = width;
            size = new Dimension(0, 0);
        }

        /**
         * Tell the GUI manager how big we would like to be.
         */
        public Dimension getPreferredSize() 
        {
            return new Dimension(gridWidth * GRID_VIEW_SCALING_FACTOR, gridHeight * GRID_VIEW_SCALING_FACTOR);
        }

        /**
         * Prepare for a new round of painting. Since the component may be resized,
         * compute the scaling factor again.
         */
        public void preparePaint() 
        {
            if (!size.equals(getSize())) { // if the size has changed...
                size = getSize();
                fieldImage = fieldView.createImage(size.width, size.height);
                g = fieldImage.getGraphics();

                xScale = size.width / gridWidth;
                if (xScale < 1) {
                    xScale = GRID_VIEW_SCALING_FACTOR;
                }
                yScale = size.height / gridHeight;
                if (yScale < 1) {
                    yScale = GRID_VIEW_SCALING_FACTOR;
                }
            }
        }

        /**
         * Paint on grid location on this field in a given color.
         */
        public void drawMark(int x, int y, Color color) 
        {
            g.setColor(color);
            g.fillRect(x * xScale, y * yScale, xScale - 1, yScale - 1);
        }

        /**
         * male) The field view component needs to be redisplayed. Copy the internal
         * image to screen.
         */
        public void paintComponent(Graphics g) 
        {
            if (fieldImage != null) {
                Dimension currentSize = getSize();
                if (size.equals(currentSize)) {
                    g.drawImage(fieldImage, 0, 0, null);
                } else {
                    // Rescale the previous image.
                    g.drawImage(fieldImage, 0, 0, currentSize.width, currentSize.height, null);
                }
            }
        }
    }
}
