import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A predator-prey simulator, based on a rectangular field
 * containing animals (fallen, taken, vexes, cabals, scorn).
 * The simulation also has more complicated aspects such as
 * disease, varying weather (fog, rain) and varying time of day.
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 100;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 120;
    // The probability that a taken will be created in any given grid position.
    private static final double TAKEN_CREATION_PROBABILITY = 0.01;
    // The probability that a fallen will be created in any given grid position.
    private static final double FALLEN_CREATION_PROBABILITY = 0.01;
    // The probability that a scorn will be created in any given grid position.
    private static final double SCORN_CREATION_PROBABILITY = 0.01;
    // The probability that a cabal will be created in any given grid position.
    private static final double CABAL_CREATION_PROBABILITY = 0.02;
    // The probability that a vex will be created in any given grid position.
    private static final double VEX_CREATION_PROBABILITY = 0.015;
    // The probability that a plant will be created in anay given grid position.
    private static final double PLANT_CREATION_PROBABILITY = 0.22;
    // List of animals in the field.
    private List<Animal> animals;
    // List of plants in the field.
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // Whether or not disease is simulated.
    private boolean infected;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        int width = DEFAULT_WIDTH;
        int depth = DEFAULT_DEPTH;
        initViewer(depth, width);
    }

    /**
     * Construct a simulation field with a specified size.
     * @param depth A specified depth.
     * @param width A specified width.
     */
    public Simulator(int depth, int width) 
    {
        initViewer(depth, width);
    }

     /**
     * Create a simulation field with the given size.
     * Set the initial colors of the animals. These may be changed at runtime
     * by the user.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public void initViewer(int depth, int width) 
    {
        view = new SimulatorView(depth, width);
        view.setColor(Fallen.class, Color.BLUE);
        view.setColor(Taken.class, Color.ORANGE);
        view.setColor(Scorn.class, Color.YELLOW);
        view.setColor(Cabal.class, Color.RED);
        view.setColor(Vex.class, Color.PINK);
        view.setColor(Plant.class, Color.GREEN);

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period, (4000
     * steps).
     */
    public void runLongSimulation() 
    {
        simulate(4000);
    }

    /**
     * A method that returns the current step of the simulation.
     * @return step The current number of steps.
     */
    public int getStep() 
    {
        return step;
    }

    /**
     * Run the simulation from its current state for the given number of steps. 
     * Stop before the given number of steps if it ceases to be viable. 
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) 
    {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and plant. Also check for special conditions, such as 
     * fog, rain and day. 
     * Special conditions:
     * 1. If fog is selected, then every 20 steps animals will not move for 20 steps,
     * but their age will increment.
     * 2. If rain is selected, then every 5 steps a plant will grow for 5 steps.
     * 3. If it is currently day, animals will move, but every 100 steps, the time
     * of day will change to night, and prey will be unable to move for 100 steps.
     * Predators however, may move and hunt during the night.
     * 
     * If an animal is no longer alive, it is removed from the simulation.
     * There is also a 60 millisecond delay implemented so that it is easier to 
     * follow along with the simulation.
     */
    public void simulateOneStep() 
    {
        step++;
        // Check special conditions.
        if (view.isSelectedFog() && step % 20 == 0) {
            view.switchFog();
        }
        if (!view.isSelectedFog()) {
            view.setFog(false);
        }
        if (!view.isSelectedRain()) {
            view.setRain(false);
        }
        if (step % 100 == 0) {
            view.switchTimeofDay();
        }
        if (view.isSelectedRain() && step % 5 == 0) {
            view.switchRain();
        }
        // Provide space for new plants.
        List<Plant> newPlants = new ArrayList<>();
        // Let all plants act.
        for (Iterator<Plant> it = plants.iterator(); it.hasNext();) {
            Plant plant = it.next();
            if (view.isRain()) {
                // Plants can act when it rains.
                plant.act(newPlants);
            }
            else {
                // Do nothing.
            }
            if (!plant.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born/grown plants to the main lists.
        plants.addAll(newPlants);
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        // Let all animals act.
        for (Iterator<Animal> it = animals.iterator(); it.hasNext();) {
            Animal animal = it.next();
            if (view.isFog() && !view.isNight()) {
                // No animals can act when it is foggy.
                animal.incrementAge();
            }
            if (view.isFog() && view.isNight()) {
                // No animals can act when it is foggy.
                animal.incrementAge();
            }
            if (!view.isFog() && !view.isNight()) {
                // All animals can act.
                animal.act(newAnimals);
            }
            if (!view.isFog() && view.isNight()) {
                // Only predators can act at night.
                if (animal instanceof Predator) {
                    animal.act(newAnimals);
                }
            }
            if (!animal.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);
        view.showStatus(step, field);
        delay(60);
    }

    /**
     * Reset the simulation to a starting position. This also
     * resets any special conditions to false, i.e. resets to 
     * the most basic type of simulation where there is no time
     * of day, no weather and no disease.
     */
    public void reset() 
    {
        step = 0;
        animals.clear();
        plants.clear();
        view.resetRain();
        view.setRain(false);
        view.resetFog();
        view.setFog(false);
        view.resetDisease();
        setInfected(false);
        view.resetTimeOfDay();
        Randomizer.reset();
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * A method that specifically resets the disease in the simulation.
     */
    public void resetDiseaseForGrid() 
    {
        step = 0;
        animals.clear();
        plants.clear();
        Randomizer.reset();
        populate();
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with animals and plants.
     * If the disease checkbox is ticked, then there are also 
     * infected animals populating the environment in the simulation.
     */
    private void populate() 
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= TAKEN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Taken taken = new Taken(true, field, location);
                    if (infected) {
                        // If this is a simulation where disease has been enabled
                        // there is a chance that taken will spawn with the 
                        // disease.
                        taken.setChanceOfInfection();
                    }
                    animals.add(taken);
                } else if (rand.nextDouble() <= FALLEN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Fallen fallen = new Fallen(true, field, location);
                    if (infected) {
                        // If this is a simulation where disease has been enabled
                        // there is a chance that fallen will spawn with the 
                        // disease.
                        fallen.setChanceOfInfection();
                    }
                    animals.add(fallen);
                } else if (rand.nextDouble() <= SCORN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Scorn scorn = new Scorn(true, field, location);
                    if (infected) {
                        // If this is a simulation where disease has been enabled
                        // there is a chance that scorn will spawn with the 
                        // disease.
                        scorn.setChanceOfInfection();
                    }
                    animals.add(scorn);
                }

                else if (rand.nextDouble() <= CABAL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cabal cabal = new Cabal(true, field, location);
                    if (infected) {
                        // If this is a simulation where disease has been enabled
                        // there is a chance that cabals will spawn with the 
                        // disease.
                        cabal.setChanceOfInfection();
                    }
                    animals.add(cabal);
                }

                else if (rand.nextDouble() <= VEX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Vex vex = new Vex(true, field, location);
                    if (infected) {
                        // If this is a simulation where disease has been enabled
                        // there is a chance that vexes will spawn with the 
                        // disease.
                        vex.setChanceOfInfection();
                    }
                    animals.add(vex);
                }

                else if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Plant plant = new Plant(true, field, location);
                    plants.add(plant);
                }
                // else leave the location empty.
            }
        }
    }

    /**
     * A method to return the current view of the simulation.
     * @return view The current view of the simulation.
     */
    public SimulatorView getView() 
    {
        return view;
    }

    /**
     * A method that sets the infected field to a boolean value, which affects
     * whether disease is simulated in the simulation.
     */
    public void setInfected(boolean infected) 
    {
        this.infected = infected;
    }

    /**
     * Pause for a given time.
     * 
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) 
    {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
