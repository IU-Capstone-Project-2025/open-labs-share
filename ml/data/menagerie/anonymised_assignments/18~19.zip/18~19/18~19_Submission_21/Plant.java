import java.util.Random;
import java.util.List;
/**
 * A simple model of a plant/grass.
 *
 * @version (2019.02.20)
 *
 * @version 2016.02.29 (2)
 */
public class Plant
{
    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    //The plant's current age.
    private int age;
    // The plant's maximum age.
    private static final int MAX_AGE = 300;
    // A random variable.
    private static final Random rand = Randomizer.getRandom();
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // The age a plant must reach, before it can grow/reproduce.
    private static final int GROW_AGE = 10;
     // The plant's growing probability.
    private static final double PLANT_GROW_PROBABILITY = 0.3;

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean randomAge, Field field, Location location){
        alive = true;
        this.field = field;
        this.location = location;
        setLocation(location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }

    /**
     * A method which increases the age of the plant. If the age of the plant
     * is greater than the specified max age of plants, the plant dies.
     */
    public void incrementAge()
    {
        age++;
        if (age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    public boolean isAlive(){
        return alive;
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    private void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * A method that implements a plant's behaviour.
     * @param newPlants A list to return newly born/grown plants.
     */
    public void act(List<Plant> newPlants){
        incrementAge();
        if(isAlive()){
         grow(newPlants);   
        }
    }
    
    /**
     * A method designed to make a plant grow/reproduce.
     * @param newPlants A list to return newly born animals.
     */
    private void grow(List<Plant> newPlants){
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc);
            newPlants.add(young);
        }
    }
    
    /**
     * Generate a number representing the number of births/growths,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= PLANT_GROW_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A method used to tell whether or not a plant can reproduce (i.e. has reached it's growing age).
     * @return true if the plant's age is greater than it's grow age.
     */
    private boolean canBreed(){
        return age>=GROW_AGE;
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    private Field getField()
    {
        return field;
    }
}
