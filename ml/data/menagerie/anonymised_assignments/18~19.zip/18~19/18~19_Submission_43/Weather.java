import java.util.Random;
import java.util.ArrayList; 

/**
 * The weather changes every so often and affects the way the simulation acts. 
 *
 */
public class Weather
{
    private ArrayList<String> weatherType;
    private Random randomGenerator;
    
    private SimulatorView view;
     
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        weatherType = new ArrayList<>();
        randomGenerator = new Random();
        fillWeatherType();
    }

    public String giveWeather() {
        return view.ReturnCurrentWeather();
    }
    
    /**
     * Build up a list of default responses from which we can pick one
     * if we don't know what else to say.
     */
    public void fillWeatherType()
    {
        weatherType.add("Raining");
        weatherType.add("Sunny");
        weatherType.add("Foggy");
        weatherType.add("Storm");
        weatherType.add("Hail");
    }
    
    public String pickRandomWeather()
    {
        // Pick a random number for the index in the type of weather list.
        // The number will be between 0 (inclusive) and the size of the list (exclusive).
        int index = randomGenerator.nextInt(weatherType.size());
        return weatherType.get(index);
    }
}
