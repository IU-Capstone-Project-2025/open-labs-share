import java.util.List;
import java.util.Random;

/**
 * A simple model of a grasshopper.
 * Grasshoppers age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Grass extends Animal
{
    // Characteristics shared by all grass (class variables).

    // The age at which grass can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which grass can live.
    private static final int MAX_AGE = 30;
    // The likelihood of grass growing.
    private static double BREEDING_PROBABILITY = 0.04;
    // The maximum growth of grass.
    private static final int MAX_LITTER_SIZE = 3;
    // A shared random number generator to control growth.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    
    // The grass's age.
    private int age;
  

    /**
     * Create new grass. Grass may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
    }
    
    /**
     * This is what the grass does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newGrass A list to return newly grown grass.
     */
    public void act(List<Animal> newGrass)
    {
        incrementAge();
        if(isAlive()) {
            giveBirth(newGrass);            
        }
    }

    /**
     * Increase the age.
     * This could result in the grass's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Check whether or not this grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newGrass A list to return newly born grass.
     */
    private void giveBirth(List<Animal> newGrass)
    {
        // New grass grows at adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
       
    /**
    * Changes the breeding probability
    */
    public static void changeBreedingProbability(double prob)
    {
       BREEDING_PROBABILITY = prob; 
    }
    
    /**
     * Generate a number representing the amount of growth,
     * if it can grow.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
         if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY){
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
           }
        
        return births;
    }

    /**
     * Grass can grow if it has reached the breeding age.
     * @return true if the grass can grow, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}