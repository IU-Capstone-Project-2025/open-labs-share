import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing a number of animals
 *
 * @version 2019.02.20
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a wild cat will be created in any given grid position.
    private static final double WILDCAT_CREATION_PROBABILITY = 0.04;
    // The probability that a badger will be created in any given grid position.
    private static final double BADGER_CREATION_PROBABILITY = 0.04; 
     // The probability that a snake will be created in any given grid position.
    private static final double SNAKE_CREATION_PROBABILITY = 0.03;
    // The probability that a lizard will be created in any given grid position.
    private static final double LIZARD_CREATION_PROBABILITY = 0.03; 
    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.03;
    // The probability that a grasshopper will be created in any given grid position.
    private static final double GRASSHOPPER_CREATION_PROBABILITY = 0.03;  
// The probability that grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.04;  
    
    // List of animals in the field.
    private List<Animal> animals;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    private Weather weather;
    private static final double DISEASE_PROBABILITY = 0.02;  
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        animals = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(WildCat.class, Color.BLUE);
        view.setColor(Badger.class, Color.BLACK);
        view.setColor(Mouse.class, Color.ORANGE);
        view.setColor(Grasshopper.class, Color.GREEN);
        view.setColor(Snake.class, Color.RED);
        view.setColor(Lizard.class, Color.YELLOW);
        view.setColor(Grass.class, Color.PINK);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
 /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
         
    }
    }
    
  
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal.
     */
    public void simulateOneStep()
    {
        step++;
          //The weather affects the animals
             if (view.ReturnCurrentWeather().equals("Foggy")){ 
            delay(200); // Visibility is worse in this weather hence animals move slower.
        }
        else {
            delay(120);   // uncomment this to run more slowly
        }
        Grass.changeBreedingProbability(0.04);
        if (view.ReturnCurrentWeather().equals("Sunny")){
            Grass.changeBreedingProbability(0.06);
        }
        if (view.ReturnCurrentWeather().equals("Snowing")||
        view.ReturnCurrentWeather().equals("Hail")){
            Grass.changeBreedingProbability(0.03);
        }
       
        //Some animals randomly become diseased
        diseaseChance();
        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            if (view.getDay() == true) 
            {animal.act(newAnimals);}
            if(! animal.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        view.showStatus(step, field);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        animals.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= WILDCAT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    WildCat wildcat = new WildCat(true, field, location);
                    animals.add(wildcat);
                }
                else if(rand.nextDouble() <= BADGER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Badger badger = new Badger(true, field, location);
                    animals.add(badger);
                }
                if(rand.nextDouble() <= SNAKE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Snake snake = new Snake(true, field, location);
                    animals.add(snake);
                }
                else if(rand.nextDouble() <= LIZARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lizard lizard = new Lizard(true, field, location);
                    animals.add(lizard);
                }
                if(rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Mouse mouse = new Mouse(true, field, location);
                    animals.add(mouse);
                }
                else if(rand.nextDouble() <= GRASSHOPPER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grasshopper grasshopper = new Grasshopper(true, field, location);
                    animals.add(grasshopper);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    animals.add(grass);
                }
                // else leave the location empty.
            }
        }
    }
    /**
     * When this method is called it will random choose a number of animals
     * The is a random chance that the animals are set to diseased 
     * The number chosen depends on the total number of animals
     *
     */
    private void diseaseChance() {
        Random randDouble = Randomizer.getRandom();
        Random randInt = Randomizer.getRandom();
        int count = 3;
        if (animals.size() > 2500)
        {
            count = count + 3;
        }
        if (animals.size() > 5000)
        {
            count = count + 3;
        }
        
        for(int i = 0; i<count; i++) {
            if(randDouble.nextDouble() <= DISEASE_PROBABILITY) {
                int size = animals.size() - 1;
                int number = randInt.nextInt(size);
                Animal diseased = animals.get(number);
                diseased.setDiseased();
            }
        }
         
     }
    
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}