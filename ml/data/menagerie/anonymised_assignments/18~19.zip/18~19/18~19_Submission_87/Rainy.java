/**
 * A class representing rainy weather.
 *
 * @version 2016.02.20
 */
public class Rainy extends Weather
{
    // The rate at which the growth rate of the plant is reduced.
	private static final double LOWER_PLANT_GROWTH_RATE = 0.8;
    
    /**
     * Constructor for objects of class Rainy
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Rainy(Field field, Location location)
    {
    	super(field, location);
    }
    
    // Getters

    /**
     * @return the plant growth rate modifier.
     */
    public double getPlantGrowthRateMultiplier()
    {
    	return LOWER_PLANT_GROWTH_RATE;
    }
}