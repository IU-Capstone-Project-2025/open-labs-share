import java.util.List;
import java.util.Random;

/**
 * A model of Prey.
 * Prey can age, move, breed, eat plants and die.
 *
 * @version 2019.02.20 
 */
public abstract class Prey extends Animal
{
    // Characteristics shared by all prey (class variables).
    // A shared pseudo random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The max distance for which 2 prey can meet and breed.
    private static final int BREEDING_DISTANCE = 3;

    // The probability that an infected prey has to die at each step.
    private static final double DIE_OF_INFECTION_PROBABILITY = 0.35;

    /**
     * Create a new Prey. A Prey may be created with age
     * zero (a new born) and his food value or with a random age and a random food value. 
     * 
     * @param isRandom If true, the Prey will have a random age and a random food value.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Prey(boolean isRandom, Field field, Location location)
    {
        super(field, location);
        setAge(0);
        if (isRandom) {
            setAge(rand.nextInt(getMaxAge()));
            setFoodLevel(rand.nextInt(getFoodValue()));
        }
        else {
            setAge(0);
            setFoodLevel(getFoodValue());
        }
    }

    // Getters 

    /**
     * @return Return the breeding distance.
     */
    public int getBreedingDistance()
    {
        return BREEDING_DISTANCE;
    }

    /**
     * @return Return the probability to die of infection (when infected).
     */
    public double getDieOfInfectionProbability()
    {
        return DIE_OF_INFECTION_PROBABILITY;
    }
    
    /**
     * This is what the Prey does most of the time - 
     * Sometimes it will breed, sometimes it will eat plants, sometimes it will die of infection or hunger or old age.
     * @param newPrey A list to return newly born Prey.
     * @param dayTime Boolean truth value representing day time, and false representing night time.
     * @param changeWeather Boolean truth value representing a change of the weather.
     */
    public void act(List<Actor> newPrey, boolean dayTime, boolean changeWeather)
    {
        // Probabilistically kill the Prey if it is infected
        if (getInfected()) {
            dieOfInfection();
        }
        
        incrementAge();
        incrementHunger();
        
        /* If it is nighttime, the prey sleep
           Else the Prey act */
        if(isAlive() && dayTime) {
            findPlant();
            giveBirth(newPrey);        
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Try to find a plant at the same location.
     * If a plant is found and is ripe, eat it (also set the plant to dead) and reset food value to its default.
     */
    public void findPlant()
    {
        if ((getField().getObjectAt(getLocation().getRow(), getLocation().getCol(), 1) != null) && (getField().getObjectAt(getLocation().getRow(), getLocation().getCol(), 1) instanceof Plant)) {
            Plant plant = (Plant) getField().getObjectAt(getLocation().getRow(), getLocation().getCol(), 1);
            if (plant.isRipe()) {
                plant.setDead();
                setFoodLevel(getFoodValue());
            }
        }
    }
}
