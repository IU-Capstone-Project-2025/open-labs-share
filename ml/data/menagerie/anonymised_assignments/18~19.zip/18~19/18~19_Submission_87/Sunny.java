/**
 * A class representing sunny weather.
 *
 * @version 2016.02.20
 */
public class Sunny extends Weather
{
    // The rate at which the growth rate of the plant is increased.
    private static final double UPPER_PLANT_GROWTH_RATE = 1.2;

    /**
     * Constructor for objects of class Sunny
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Sunny(Field field, Location location)
    {
        super(field, location);
    }


    // Getters

    /**
     * @return the plant growth rate modifier.
     */
    public double getPlantGrowthRateMultiplier()
    {
        return UPPER_PLANT_GROWTH_RATE;
    }
}