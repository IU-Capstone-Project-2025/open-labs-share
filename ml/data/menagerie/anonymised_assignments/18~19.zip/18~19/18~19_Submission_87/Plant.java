import java.util.List;
import java.util.Random;

/**
 * A class representing a Plant.
 * Plant grow following a growth rate, and can die if they are eaten.
 * When they die, a new one is created at the same location.
 *
 * @version 2019.02.20
 */
public class Plant implements Actor
{
    // Characteristics shared by all plants (class variables).
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The rate at which the plant can grow at each step.
    private static final double PLANT_GROWTH_RATE = 0.5;
    // The original state of a plant.
    private static final double PLANT_ORIGINAL_STATE = 0.2;
    // The state of the plant, from 0.2 to 1 (1 means ripe)
    private double state;
    // Truth value representing whether the Plant is ripe or not
    private boolean ripe;   
    // Truth value representing whether the Plant is alive or not
    private boolean alive;
    // The Plant position in the field.
    private Location location;
    // The plant's field.
    private Field field; 

    /**
     * Creates a new Plant at a location in the field. 
     * A Plant can be created with a random state (from 0.2 to 1) 
     * or as a new born plant where the state equals the original state.
     * @param randomState Boolean truth value to represent whether the state is random or constant.
     * @param field The field currently occupied by the plant.
     * @param location The location within the field of the plant.
     */
    public Plant(boolean randomState, Field field, Location location)
    {
        alive = true;
        this.field = field;
        if(randomState) {
            state = rand.nextDouble() + PLANT_ORIGINAL_STATE;
        }
        else {
            state = PLANT_ORIGINAL_STATE;
        }


        if (state >= 1) {
            ripe = true;
        }
        else {
            ripe = false;
        }

        setLocation(location);
    }

    //Getters

    /**
     * Getter for plant's location.
     * @return The plant's location.
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * Return the plant's field.
     * @return the plant's field.
     */
    private Field getField()
    {
        return field;
    }

    /**
     * Check whether the plant is alive or not.
     * @return True if the plant is still alive, false otherwise.
     */
    public boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether the plant is ripe or not.
     * @return True if the plant is ripe, false otherwise.
     */
    public boolean isRipe()
    {
        updateRipe();
        return ripe;
    }


    //Setters

    /**
     * Update the ripe boolean, setting to true if 
     * the state of the plant is superior or equal 1.
     */
    private void updateRipe()
    {
        if (state >= 1) {
            ripe = true;
        }
        else {
            ripe = false;
        }
    }

    /**
     * Update the state of the Plant depending on the growth rate
     * of the plant and the weather of the plant's location.
     */
    private void updateState()
    {
        // Check if there is a weather object at the plant's location
        Object object = getField().getObjectAt(getLocation().getRow(), getLocation().getCol(), 2);
        Weather weather = null;
        if ((object != null) && (object instanceof Weather)) {
            weather = (Weather) getField().getObjectAt(getLocation().getRow(), getLocation().getCol(), 2);
            // Update the state with given plant growth rate and the weather multiplier.
            state = state + state*(PLANT_GROWTH_RATE*(weather.getPlantGrowthRateMultiplier()));
        }
        else {
            state = state + state*(PLANT_GROWTH_RATE);
        }
    }

    /**
     * Indicate that the plant is no longer alive.
     */
    public void setDead()
    {
        alive = false;
    }
    
    /**
     * Remove the plant from the field.
     */
    private void clearLocation()
    {
        if (location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    private void setLocation(Location newLocation)
    {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;

        field.place(this, newLocation);
    }

    /**
     * This is what the Plant does most of the time - 
     * Plants grow and can die if they are eaten.
     * @param newPlants A list to return a new plant at the same location (if this one is dead)
     * @param dayTime Boolean truth value representing day time, and false representing night time.
     * @param changeWeather Boolean truth value representing a change of the weather.
     */
    public void act(List <Actor> newPlants, boolean dayTime, boolean changeWeather)
    {
        /* The plant can grow only if it is day time
            and if it's state is under 1. */
        if (dayTime && state < 1) {
            updateState();
            updateRipe();
        }

        /* If the plant is dead create a new one
            at the same location in the field. */
        if (!isAlive()) {
            Location tmpLocation = location;
            Field tmpField = field;
            clearLocation();
            newPlants.add(new Plant(false, tmpField, tmpLocation));
        }

    }
}
