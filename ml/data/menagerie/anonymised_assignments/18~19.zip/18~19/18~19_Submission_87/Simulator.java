
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A Savanna predator-prey simulator, based on a rectangular field
 * containing species found in the Savanna.
 *
 * @version 2019.02.20
 */
public class Simulator
{
    // A shared pseudo random number generator.
    private static final Random rand = Randomizer.getRandom();
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // The probability that a Lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.04;
    // The probability that a Giraffe will be created in any given grid position.
    private static final double GIRAFFE_CREATION_PROBABILITY = 0.08;
    // The probability that a Zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.10;
    // The probability that a Crocodile will be created in any given grid position.
    private static final double CROCODILE_CREATION_PROBABILITY = 0.05;
    // The probability that a Bird will be created in any given grid position.
    private static final double BIRD_CREATION_PROBABILITY = 0.08;        
    // The probability of being infected at the creation of the grid.
    private static final double INFECTION_PROBABILITY = 0.05;
    // The probability that a grid position contains a plant.
    private static final double PLANT_CREATION_PROBABILITY = 0.75;
    // The probability that the weather change at each step.
    private static final double WEATHER_CHANGE_CHANCE = 0.1;

    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    
    // Keep the number of the last step at each simulation.
    private int lastStep;
    // A graphical view of the simulation.
    private SimulatorView view;
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Giraffe.class, Color.YELLOW);
        view.setColor(Lion.class, Color.RED);
        view.setColor(Zebra.class, Color.BLACK);
        view.setColor(Crocodile.class, Color.GREEN);
        view.setColor(Bird.class, Color.BLUE);

        // Setup a valid starting point.
        lastStep = 0;
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        int countStep = 0;
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep(step + lastStep);
            countStep++;
            //delay(100);   // uncomment this to run more slowly
        }
        // If we make multiple calls to simulate method we keep track of the time of the day with the lastStep field
        // During the next call we add lastStep to each step in order to reach the good time of the day.
        lastStep = countStep;
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actors.
     */
    public void simulateOneStep()
    {
        simulateOneStep(0);
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each actors.
     * @param stepTIme keep track of the last simulation time.
     */
    private void simulateOneStep(int stepTime)
    {
        this.step++;
        boolean dayTime = false;
        // If true then it is day time, else if false it is night time
        if (stepTime % 2 == 1) {
            dayTime = true; 
        }
        // If true then the weather of the field change, otherwise it will
        // at the same state.
        boolean changeWeather = false;
        if (rand.nextDouble() <= WEATHER_CHANGE_CHANCE) {
            changeWeather = true;
        }
        // Provide space for new actors.
        List<Actor> newActors = new ArrayList<>();        
        // Let all animals act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            actor.act(newActors, dayTime, changeWeather);
            if(! actor.isAlive()) {
                it.remove();
            }
        }
               
        // Add the newly actors to the main lists.
        actors.addAll(newActors);
        view.showStatus(this.step, field); 
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        actors.clear();
        populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field);
    }
    
    /**
     * Randomly populate the field with Animals, Plants and weather.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();

        /* 50% probability of the weather of the field being sunny at the beginning
         and 50% probability of the weather of the field being rainy at the beginning*/ 
        boolean sunny;
        if (rand.nextBoolean()) {
            sunny = true;
        }
        else {
            sunny = false;
        }

        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                // Create a weather object for each position of the grid
                // depending on the sunny boolean.
                Location weatherLocation = new Location(row, col, 2);
                Weather newWeather = null;
                if (sunny) {
                    newWeather = new Sunny(field, weatherLocation);
                }
                else {
                    newWeather = new Rainy(field, weatherLocation);
                }
                actors.add(newWeather);
                // For each position probabilty to add a new animal of each species.
                Animal newAnimal = null;
                if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 0);
                    newAnimal = new Zebra(true, field, location);
                    actors.add(newAnimal);
                }
                else if(rand.nextDouble() <= BIRD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 0);
                    newAnimal = new Bird(true, field, location);
                    actors.add(newAnimal);
                }
                else if(rand.nextDouble() <= GIRAFFE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 0);
                    newAnimal = new Giraffe(true, field, location);
                    actors.add(newAnimal);
                }
                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 0);
                    newAnimal = new Lion(true, field, location);
                    actors.add(newAnimal);
                }
                else if(rand.nextDouble() <= CROCODILE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 0);
                    newAnimal = new Crocodile(true, field, location);
                    actors.add(newAnimal);
                }
                // else leave the animal location empty.
                if ((newAnimal != null) && rand.nextDouble() <= INFECTION_PROBABILITY) {
                    newAnimal.setInfected();
                }
                // For each position try to place a plant. 
                if (rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 1);
                    Plant newPlant = new Plant(true, field, location);
                    actors.add(newPlant);
                }
            }
        }
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}
